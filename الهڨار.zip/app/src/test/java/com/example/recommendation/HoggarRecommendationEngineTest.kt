package com.example.recommendation

import com.example.model.CreatorModel
import com.example.model.VideoItem
import com.example.model.VideoStats
import com.example.recommendation.engine.HoggarRecommendationEngine
import com.example.recommendation.engine.InteractionSignal
import com.example.recommendation.model.FeedItemReason
import com.example.recommendation.model.FeedRequest
import com.example.recommendation.model.RecommendationContext
import com.example.recommendation.model.WatchEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class HoggarRecommendationEngineTest {

  private lateinit var engine: HoggarRecommendationEngine
  private lateinit var sampleVideos: List<VideoItem>

  @Before
  fun setUp() {
    engine = HoggarRecommendationEngine()

    val creator1 = CreatorModel(id = "c1", username = "tuareg_master", displayName = "أصيل التوارق", avatarUrl = "https://example.com/a1.jpg", followersCount = 120_000L, isVerified = true)
    val creator2 = CreatorModel(id = "c2", username = "sahara_camels", displayName = "جمال الصحراء", avatarUrl = "https://example.com/a2.jpg", followersCount = 20_000L, isVerified = false)
    val creator3 = CreatorModel(id = "c3", username = "hoggar_silver", displayName = "فضيات الهڨار", avatarUrl = "https://example.com/a3.jpg", followersCount = 5_000L, isVerified = false)

    sampleVideos = listOf(
      VideoItem(
        id = "v1",
        title = "غروب أسكرام",
        description = "مشهد مهيب لغروب الشمس من قمة أسكرام",
        videoUrl = "https://example.com/v1.mp4",
        thumbnailUrl = "https://example.com/t1.jpg",
        tags = listOf("#الهڨار", "#أسكرام"),
        soundTitle = "ألحان تينيري",
        creator = creator1,
        stats = VideoStats(viewsCount = 50_000L, likesCount = 4_500L, sharesCount = 800L, commentsCount = 300L),
      ),
      VideoItem(
        id = "v2",
        title = "قافلة الإبل في تمنراست",
        description = "مسير الإبل بين الكثبان الرملية الذهبية",
        videoUrl = "https://example.com/v2.mp4",
        thumbnailUrl = "https://example.com/t2.jpg",
        tags = listOf("#تمنراست", "#شاي_صحراوي"),
        soundTitle = "موسيقى الطيندي",
        creator = creator2,
        stats = VideoStats(viewsCount = 15_000L, likesCount = 1_200L, sharesCount = 150L, commentsCount = 90L),
      ),
      VideoItem(
        id = "v3",
        title = "صياغة خاتم تارقي أصيل",
        description = "نقش الفضة اليدوي بمهارة الأجداد",
        videoUrl = "https://example.com/v3.mp4",
        thumbnailUrl = "https://example.com/t3.jpg",
        tags = listOf("#صناعة_الفضة", "#تراث_تارقي"),
        soundTitle = "نقرات الفضة",
        creator = creator3,
        stats = VideoStats(viewsCount = 2_000L, likesCount = 350L, sharesCount = 80L, commentsCount = 40L),
      ),
    )
  }

  @Test
  fun testRankingProducesValidResults() {
    val request = FeedRequest(
      userId = "test_user",
      pageSize = 5,
      context = RecommendationContext(),
    )
    val result = engine.rankForYouFeed(sampleVideos, request)
    assertEquals(3, result.items.size)
    assertTrue(result.items.first().score > 0)
  }

  @Test
  fun testReplaySignificantlyBoostsTopicAffinity() {
    val request = FeedRequest(
      userId = "test_user",
      pageSize = 5,
      context = RecommendationContext(),
    )

    // Initially rank
    val initialResult = engine.rankForYouFeed(sampleVideos, request)
    assertNotNull(initialResult)

    // User replays video 3 (Silver crafting) twice
    engine.processWatchEvent(
      WatchEvent(
        videoId = "v3",
        watchDurationMs = 60_000L,
        completionRate = 2.0f,
        isSkippedQuickly = false,
        isReplayed = true,
        videoTags = listOf("#صناعة_الفضة", "#تراث_تارقي"),
        creatorId = "c3",
      ),
      sampleVideos[2],
    )

    val profile = engine.getUserProfileSnapshot()
    assertTrue((profile.topicAffinities["#صناعة_الفضة"] ?: 0f) > 3.0f)
  }

  @Test
  fun testFastSkipPenalizesUnwantedContent() {
    // User quickly skips camel video
    engine.processWatchEvent(
      WatchEvent(
        videoId = "v2",
        watchDurationMs = 800L,
        completionRate = 0.05f,
        isSkippedQuickly = true,
        isReplayed = false,
        videoTags = listOf("#شاي_صحراوي"),
        creatorId = "c2",
      ),
      sampleVideos[1],
    )

    val profile = engine.getUserProfileSnapshot()
    assertTrue((profile.topicAffinities["#شاي_صحراوي"] ?: 0f) < 1.0f)
  }

  @Test
  fun testFollowingCreatorBoostsPriority() {
    val request = FeedRequest(
      userId = "test_user",
      pageSize = 5,
      context = RecommendationContext(followingCreatorIds = setOf("c2")),
    )

    val result = engine.rankForYouFeed(sampleVideos, request)
    // The followed creator's video (v2) should have FollowedCreator reason and high rank
    val itemForC2 = result.items.firstOrNull { it.video.creator.id == "c2" }
    assertNotNull(itemForC2)
    assertEquals(FeedItemReason.FollowedCreator, itemForC2?.reason)
  }

  @Test
  fun testRelatedVideosUsesCosineSimilarity() {
    val target = sampleVideos[0] // #الهڨار, #أسكرام
    val related = engine.computeRelatedVideos(target, sampleVideos)
    assertNotNull(related)
    assertEquals("v1", related.targetVideoId)
  }

  @Test
  fun testSuggestedCreatorsGeneratesPersonalizedReasons() {
    val suggestions = engine.getSuggestedCreators(sampleVideos, "test_user")
    assertEquals(3, suggestions.size)
    assertTrue(suggestions.all { it.reasonAr.isNotEmpty() })
  }

  @Test
  fun testTrendingSoundsRanking() {
    val sounds = engine.getTrendingSounds(sampleVideos)
    assertEquals(3, sounds.size)
    assertTrue(sounds.first().usageCount > 0)
  }
}
