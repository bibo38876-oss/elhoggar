package com.example.production

import com.example.model.CreatorModel
import com.example.model.VideoItem
import com.example.model.VideoStats
import com.example.production.analytics.HoggarAnalyticsTracker
import com.example.production.api.ApiResponse
import com.example.production.api.HoggarApiClient
import com.example.production.backup.DisasterRecoveryService
import com.example.production.cache.MultiLevelCacheManager
import com.example.production.featureflag.FeatureFlagManager
import com.example.production.feed.ScalableFeedService
import com.example.production.pipeline.PipelineStage
import com.example.production.pipeline.VideoProcessingPipeline
import com.example.production.upload.ResumableUploadManager
import com.example.production.upload.UploadSessionStatus
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProductionArchitectureTest {

  @Test
  fun testApiClientAuthorizationAndRateLimiting() {
    val client = HoggarApiClient()

    // Unauthorized call to protected endpoint
    val unauthResponse = client.executeRequest<String>(
      endpoint = "/videos/upload",
      authToken = null,
      userId = "guest",
    ) { "uploaded" }

    assertTrue(unauthResponse is ApiResponse.Error)
    val error = unauthResponse as ApiResponse.Error
    assertEquals("UNAUTHORIZED", error.code)
    assertEquals(401, error.httpStatus)

    // Authorized call
    val authResponse = client.executeRequest<String>(
      endpoint = "/videos/upload",
      authToken = "valid_bearer_token",
      userId = "user_123",
    ) { "uploaded_successfully" }

    assertTrue(authResponse is ApiResponse.Success)
    val success = authResponse as ApiResponse.Success
    assertEquals("uploaded_successfully", success.data)
  }

  @Test
  fun testResumableUploadManagerResumeAfterNetworkDrop() = runBlocking {
    val uploadManager = ResumableUploadManager(defaultChunkSize = 1000)
    val session = uploadManager.createSession(fileName = "hoggar_tahat.mp4", totalBytes = 4000)

    assertEquals(4, session.totalChunks)
    assertEquals(0, session.uploadedChunks)

    // 1. First attempt with network drop halfway (chunk 2 of 4)
    val firstAttemptEvents = uploadManager.startOrResumeUpload(session.sessionId, simulateNetworkDrop = true).toList()
    assertEquals(UploadSessionStatus.Paused, session.status)
    assertEquals(2, session.uploadedChunks)
    assertEquals(50, (session.progress * 100).toInt())

    // 2. Resume session: It must NOT start from chunk 0, but complete the remaining chunks
    val secondAttemptEvents = uploadManager.startOrResumeUpload(session.sessionId, simulateNetworkDrop = false).toList()
    assertEquals(UploadSessionStatus.Completed, session.status)
    assertEquals(4, session.uploadedChunks)
    assertEquals(100, (session.progress * 100).toInt())
  }

  @Test
  fun testVideoProcessingPipelineCompleteFlow() = runBlocking {
    val pipeline = VideoProcessingPipeline()
    val states = pipeline.executePipeline("raw_source.mp4", durationSeconds = 45).toList()

    assertTrue(states.isNotEmpty())
    val finalState = states.last()

    assertEquals(PipelineStage.Publish, finalState.currentStage)
    assertTrue(finalState.isComplete)
    assertNotNull(finalState.variantSet)
    assertEquals(45, finalState.variantSet?.durationSeconds)
  }

  @Test
  fun testMultiLevelCacheManagerTtlAndEviction() {
    val cache = MultiLevelCacheManager(maxEntries = 3)

    // Put item with 100ms TTL
    cache.put("key1", "value1", ttlMs = 100L)
    assertEquals("value1", cache.get<String>("key1"))

    // Wait for expiration
    Thread.sleep(150L)
    assertNull(cache.get<String>("key1"))

    // Test LRU capacity eviction
    cache.put("item1", "val1", ttlMs = 50000L)
    cache.put("item2", "val2", ttlMs = 50000L)
    cache.put("item3", "val3", ttlMs = 50000L)
    cache.put("item4", "val4", ttlMs = 50000L) // exceeds maxEntries (3)

    assertEquals(3, cache.getEstimatedSizeEntries())
  }

  @Test
  fun testScalableFeedServiceCursorPagination() {
    val feedService = ScalableFeedService(MultiLevelCacheManager(100))
    val sampleVideos = (1..25).map { index ->
      VideoItem(
        id = "vid_$index",
        videoUrl = "https://cdn.elhoggar.dz/videos/$index.mp4",
        thumbnailUrl = "https://cdn.elhoggar.dz/thumbnails/$index.jpg",
        title = "فيديو رقم $index",
        description = "وصف فيديو رقم $index",
        creator = CreatorModel("c1", "creator", "مبدع الهڨار", "", true),
        ownerId = "c1",
        stats = VideoStats(),
      )
    }

    feedService.seedPrecomputedPool(sampleVideos)

    // Page 1 (first 10 items)
    val page1 = feedService.getFeedPage(userId = "user_test", cursor = null, pageSize = 10)
    assertEquals(10, page1.items.size)
    assertEquals("vid_1", page1.items.first().id)
    assertEquals("vid_10", page1.nextCursor)
    assertTrue(page1.hasMore)

    // Page 2 (items 11-20 via nextCursor)
    val page2 = feedService.getFeedPage(userId = "user_test", cursor = page1.nextCursor, pageSize = 10)
    assertEquals(10, page2.items.size)
    assertEquals("vid_11", page2.items.first().id)
    assertEquals("vid_20", page2.nextCursor)
    assertTrue(page2.hasMore)

    // Page 3 (remaining 5 items)
    val page3 = feedService.getFeedPage(userId = "user_test", cursor = page2.nextCursor, pageSize = 10)
    assertEquals(5, page3.items.size)
    assertEquals("vid_21", page3.items.first().id)
    assertNull(page3.nextCursor)
    assertFalse(page3.hasMore)
  }

  @Test
  fun testFeatureFlagToggles() {
    val flagManager = FeatureFlagManager()
    assertTrue(flagManager.flags.value.enableHlsStreaming)

    flagManager.setHlsStreaming(false)
    assertFalse(flagManager.flags.value.enableHlsStreaming)

    flagManager.setResumableUpload(true)
    assertTrue(flagManager.flags.value.enableResumableUpload)
  }

  @Test
  fun testTelemetryMetricsTracking() {
    val tracker = HoggarAnalyticsTracker()
    tracker.trackAppOpen()
    tracker.trackAppOpen()
    tracker.trackVideoStart("vid_hoggar_01")
    tracker.trackWatchSession("vid_hoggar_01", durationSecs = 35, isCompleted = true)
    tracker.trackUploadResult(isSuccess = true, latencyMs = 1200)

    val metrics = tracker.getSnapshot()
    assertEquals(2, metrics.appOpensCount)
    assertEquals(1, metrics.videoStartsCount)
    assertEquals(35, metrics.totalWatchDurationSecs)
    assertEquals(1, metrics.completedVideosCount)
    assertEquals(1, metrics.uploadSuccessCount)
  }

  @Test
  fun testDisasterRecoverySnapshot() {
    val drService = DisasterRecoveryService()
    val snapshot = drService.triggerAutomatedBackup(recordCount = 15000L)

    assertNotNull(snapshot)
    assertEquals(15000L, snapshot.recordCount)
    assertTrue(snapshot.isCrossRegionReplicated)
    assertEquals(snapshot, drService.getLatestSnapshot())
  }
}
