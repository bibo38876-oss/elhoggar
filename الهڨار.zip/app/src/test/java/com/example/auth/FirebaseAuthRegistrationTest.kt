package com.example.auth

import com.example.user.User
import com.example.user.UserRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FirebaseAuthRegistrationTest {

  @Test
  fun validateRegistrationUsername() {
    assertTrue(SecurityUtils.validateUsername("hoggar_star").isSuccess)
    assertTrue(SecurityUtils.validateUsername("tassili2026").isSuccess)

    // Invalid usernames
    assertTrue(SecurityUtils.validateUsername("a").isFailure) // too short
    assertTrue(SecurityUtils.validateUsername("invalid spaces").isFailure)
    assertTrue(SecurityUtils.validateUsername("invalid#chars!").isFailure)
  }

  @Test
  fun validateRegistrationEmail() {
    assertTrue(SecurityUtils.validateEmail("user@example.com"))
    assertTrue(SecurityUtils.validateEmail("adel@elhoggar.dz"))

    assertFalse(SecurityUtils.validateEmail("invalid-email"))
    assertFalse(SecurityUtils.validateEmail("@nodomain.com"))
    assertFalse(SecurityUtils.validateEmail("missing@domain"))
  }

  @Test
  fun userModelHoldsFirebaseAuthUID() {
    val firebaseAuthUid = "firebase_auth_uid_xyz123"
    val user = User(
      id = firebaseAuthUid,
      username = "algeria_creator",
      displayName = "مبدع الجزائر",
      email = "creator@elhoggar.dz",
      avatarUrl = "https://example.com/avatar.jpg",
      bio = "صانع محتوى في الهڨار",
      role = UserRole.Standard,
      isVerified = false,
      isPrivate = false,
      createdAtMs = 1700000000000L,
    )

    assertEquals(firebaseAuthUid, user.id)
    assertEquals("algeria_creator", user.username)
    assertEquals("مبدع الجزائر", user.displayName)
    assertEquals("creator@elhoggar.dz", user.email)
    assertFalse(user.isPrivate)
  }

  @Test
  fun firestoreUsersCollectionSchemaFields() {
    val uid = "test_fb_uid_456"
    val email = "test@elhoggar.dz"
    val username = "hoggar_user"
    val displayName = "مستخدم تجريبي"
    val photoURL = "https://example.com/p.jpg"

    val profileDoc = hashMapOf<String, Any>(
      "uid" to uid,
      "email" to email,
      "displayName" to displayName,
      "username" to username,
      "photoURL" to photoURL,
      "createdAt" to System.currentTimeMillis(),
      "updatedAt" to System.currentTimeMillis(),
      "bio" to "",
      "isPrivate" to false,
      "followersCount" to 0L,
      "followingCount" to 0L,
      "videosCount" to 0L,
      "likesCount" to 0L,
    )

    assertEquals(uid, profileDoc["uid"])
    assertEquals(0L, profileDoc["followersCount"])
    assertEquals(0L, profileDoc["followingCount"])
    assertEquals(0L, profileDoc["videosCount"])
    assertEquals(0L, profileDoc["likesCount"])
    assertEquals(false, profileDoc["isPrivate"])
    assertNotNull(profileDoc["createdAt"])
    assertNotNull(profileDoc["updatedAt"])
  }
}
