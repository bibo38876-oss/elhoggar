package com.example.localization

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String, val layoutDirection: LayoutDirection) {
  Arabic("ar", "العربية", "العربية", LayoutDirection.Rtl),
  English("en", "English", "English", LayoutDirection.Ltr);

  companion object {
    fun fromCode(code: String): AppLanguage {
      return entries.find { it.code.equals(code, ignoreCase = true) } ?: Arabic
    }
  }
}

/**
 * Clean, centralized strings dictionary for both Arabic and English.
 * Guarantees zero mixing of languages, strict RTL/LTR compliance, and instantaneous runtime switching.
 */
object HoggarStrings {
  private val stringsAr = mapOf(
    "app_name" to "الهڨار",
    "tagline" to "منصة الفيديوهات القصيرة حتى 60 ثانية",
    "onboarding_title" to "مرحباً بك في الهڨار",
    "onboarding_desc" to "استكشف وشارك لحظاتك الثقافية والإبداعية في مقاطع فيديو عمودية سريعة بحد أقصى دقيقة واحدة.",
    "start_browsing_guest" to "تصفح كزائر",
    "login_or_signup" to "تسجيل الدخول / إنشاء حساب",
    "nav_home" to "الرئيسية",
    "nav_discover" to "استكشاف",
    "nav_create" to "إنشاء",
    "nav_activity" to "النشاط",
    "nav_profile" to "ملفي",
    "settings" to "الإعدادات",
    "login" to "تسجيل الدخول",
    "signup" to "إنشاء حساب",
    "logout" to "تسجيل الخروج",
    "follow" to "متابعة",
    "following" to "تتابعه",
    "followers" to "متابعون",
    "like" to "إعجاب",
    "comment" to "تعليق",
    "share" to "مشاركة",
    "save" to "حفظ",
    "report" to "إبلاغ",
    "delete" to "حذف",
    "edit" to "تعديل",
    "publish" to "نشر",
    "cancel" to "إلغاء",
    "retry" to "إعادة المحاولة",
    "loading" to "جارٍ التحميل...",
    "no_internet" to "لا يوجد اتصال بالإنترنت",
    "no_internet_desc" to "يرجى التحقق من اتصالك بالشبكة ثم إعادة المحاولة.",
    "something_went_wrong" to "حدث خطأ غير متوقع",
    "video_unavailable" to "هذا الفيديو غير متوفر حالياً",
    "private_video" to "هذا الفيديو خاص بالمنشئ ومتابعيه",
    "account" to "الحساب",
    "privacy" to "الخصوصية",
    "privacy_policy" to "سياسة الخصوصية",
    "terms_of_service" to "شروط الخدمة",
    "community_guidelines" to "إرشادات المجتمع",
    "about" to "حول التطبيق",
    "support" to "الدعم الفني",
    "language" to "اللغة",
    "select_language" to "اختر اللغة",
    "account_deletion" to "حذف الحساب",
    "account_deletion_warning" to "تحذير: سيتم حذف جميع فيديوهاتك وبياناتك ولا يمكن التراجع بعد تأكيد الحذف.",
    "account_deletion_confirm" to "نعم، احذف حسابي نهائياً",
    "private_account" to "حساب خاص",
    "private_account_desc" to "فقط المتابعون الذين توافق عليهم يمكنهم مشاهدة فيديوهاتك.",
    "notifications" to "الإشعارات",
    "push_notifications" to "إشعارات الهاتف",
    "data_saver" to "توفير استهلاك البيانات",
    "data_saver_desc" to "تقليل جودة البث عند استخدام بيانات الهاتف الجوال.",
    "max_duration_hint" to "الحد الأقصى لكل فيديو هو 60 ثانية",
    "duration_seconds" to "ثانية",
    "views" to "مشاهدة",
    "likes" to "إعجاب",
    "comments" to "تعليقات",
    "report_submitted" to "شكراً لك، تم إرسال البلاغ لفريق الإشراف للمراجعة.",
    "support_submitted" to "تم استلام رسالتك وسيتم الرد عليك في أقرب وقت.",
    "version" to "الإصدار",
    "for_you" to "لك",
    "search_hint" to "ابحث عن منشئين، وسوم، ومقاطع...",
    "change_password" to "تغيير كلمة المرور",
    "blocked_accounts" to "الحسابات المحظورة",
    "no_blocked_accounts" to "لا توجد حسابات محظورة حالياً.",
    "comments_permission" to "من يمكنه التعليق",
    "comments_everyone" to "الجميع",
    "comments_followers" to "المتابعون فقط",
    "comments_off" to "إيقاف التعليقات",
    "session_expired" to "انتهت الجلسة، يرجى تسجيل الدخول مرة أخرى.",
    "permission_camera_title" to "إذن الكاميرا والميكروفون",
    "permission_camera_desc" to "يحتاج تطبيق الهڨار إلى إذن الكاميرا لتسجيل الفيديوهات مباشرة.",
    "permission_grant" to "منح الإذن",
    "permission_denied" to "تم رفض الإذن. يمكنك منحه من إعدادات الهاتف إذا أردت استخدام الكاميرا.",
  )

  private val stringsEn = mapOf(
    "app_name" to "El Hoggar",
    "tagline" to "Vertical Short Video Platform (60s Max)",
    "onboarding_title" to "Welcome to El Hoggar",
    "onboarding_desc" to "Discover and share authentic cultural and creative moments in rapid vertical videos up to 60 seconds.",
    "start_browsing_guest" to "Browse as Guest",
    "login_or_signup" to "Sign In / Create Account",
    "nav_home" to "Home",
    "nav_discover" to "Discover",
    "nav_create" to "Create",
    "nav_activity" to "Activity",
    "nav_profile" to "Profile",
    "settings" to "Settings",
    "login" to "Log In",
    "signup" to "Sign Up",
    "logout" to "Log Out",
    "follow" to "Follow",
    "following" to "Following",
    "followers" to "Followers",
    "like" to "Like",
    "comment" to "Comment",
    "share" to "Share",
    "save" to "Save",
    "report" to "Report",
    "delete" to "Delete",
    "edit" to "Edit",
    "publish" to "Publish",
    "cancel" to "Cancel",
    "retry" to "Retry",
    "loading" to "Loading...",
    "no_internet" to "No Internet Connection",
    "no_internet_desc" to "Please check your network connection and try again.",
    "something_went_wrong" to "Something went wrong",
    "video_unavailable" to "This video is currently unavailable",
    "private_video" to "This video is private to creator and followers",
    "account" to "Account",
    "privacy" to "Privacy",
    "privacy_policy" to "Privacy Policy",
    "terms_of_service" to "Terms of Service",
    "community_guidelines" to "Community Guidelines",
    "about" to "About",
    "support" to "Support & Feedback",
    "language" to "Language",
    "select_language" to "Select Language",
    "account_deletion" to "Delete Account",
    "account_deletion_warning" to "Warning: All your videos and data will be permanently removed. This action cannot be undone.",
    "account_deletion_confirm" to "Yes, delete my account permanently",
    "private_account" to "Private Account",
    "private_account_desc" to "Only approved followers can view your uploaded videos.",
    "notifications" to "Notifications",
    "push_notifications" to "Push Notifications",
    "data_saver" to "Data Saver",
    "data_saver_desc" to "Lower playback quality when connected via mobile cellular data.",
    "max_duration_hint" to "Maximum video duration is 60 seconds",
    "duration_seconds" to "s",
    "views" to "views",
    "likes" to "likes",
    "comments" to "comments",
    "report_submitted" to "Thank you. Your report has been submitted for moderation review.",
    "support_submitted" to "Your message has been received. Our team will review it shortly.",
    "version" to "Version",
    "for_you" to "For You",
    "search_hint" to "Search creators, hashtags, and moments...",
    "change_password" to "Change Password",
    "blocked_accounts" to "Blocked Accounts",
    "no_blocked_accounts" to "No blocked accounts at this time.",
    "comments_permission" to "Who Can Comment",
    "comments_everyone" to "Everyone",
    "comments_followers" to "Followers only",
    "comments_off" to "Off",
    "session_expired" to "Session expired. Please sign in again.",
    "permission_camera_title" to "Camera & Microphone Permission",
    "permission_camera_desc" to "El Hoggar requires camera permission to capture videos directly.",
    "permission_grant" to "Grant Permission",
    "permission_denied" to "Permission denied. You can enable it in device settings if you wish to record.",
  )

  fun get(key: String, language: AppLanguage): String {
    return when (language) {
      AppLanguage.Arabic -> stringsAr[key] ?: stringsEn[key] ?: key
      AppLanguage.English -> stringsEn[key] ?: stringsAr[key] ?: key
    }
  }
}

class LocalizationState(initialLanguage: AppLanguage = AppLanguage.Arabic) {
  var currentLanguage by mutableStateOf(initialLanguage)
    private set

  fun setLanguage(context: Context, language: AppLanguage) {
    currentLanguage = language
    val prefs = context.getSharedPreferences("elhoggar_settings", Context.MODE_PRIVATE)
    prefs.edit().putString("app_language", language.code).apply()
  }

  companion object {
    fun loadInitial(context: Context): LocalizationState {
      val prefs = context.getSharedPreferences("elhoggar_settings", Context.MODE_PRIVATE)
      val savedCode = prefs.getString("app_language", "ar") ?: "ar"
      return LocalizationState(AppLanguage.fromCode(savedCode))
    }
  }
}

val LocalLocalization = compositionLocalOf<LocalizationState> {
  error("No LocalizationState provided")
}

@Composable
@ReadOnlyComposable
fun hoggarString(key: String): String {
  val loc = LocalLocalization.current
  return HoggarStrings.get(key, loc.currentLanguage)
}
