package com.example.user

import com.example.model.VideoItem
import kotlinx.coroutines.flow.Flow

interface UserRepository {
  fun getUserById(userId: String, currentUserId: String? = null): Flow<UserProfile?>
  fun getUserByUsername(username: String, currentUserId: String? = null): Flow<UserProfile?>
  suspend fun updateProfile(userId: String, displayName: String, bio: String, avatarUrl: String): Result<UserProfile>
  fun isUsernameAvailable(username: String, currentUserId: String? = null): Boolean
  fun getUserVideos(userId: String): Flow<List<VideoItem>>
  suspend fun deleteUser(userId: String): Result<Boolean>
}
