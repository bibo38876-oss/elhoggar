package com.example.user

import com.example.data.repository.MockVideoRepository
import com.example.data.repository.VideoRepository
import com.example.follow.FollowRepository
import com.example.model.VideoItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import java.util.Locale

class MockUserRepository(
  private val followRepository: FollowRepository,
  private val videoRepository: VideoRepository = MockVideoRepository(),
) : UserRepository {

  private val usersMap = mutableMapOf<String, User>()
  private val _usersUpdateFlow = MutableStateFlow(Unit)

  init {
    // 1. Official Brand Account (Reserved & Protected)
    usersMap["official_elhoggar"] = User(
      id = "official_elhoggar",
      username = "elhoggar",
      displayName = "الهڨار",
      email = "official@elhoggar.dz",
      avatarUrl = "", // Displayed with official geometric emblem
      bio = "الحساب الرسمي لمنصة الهڨار للفيديوهات القصيرة. أصالة الصحراء، نبض الإبداع والمشاهدة العمودية.",
      role = UserRole.OfficialBrand,
      isVerified = true,
      isPrivate = false,
    )

    // 2. Default Logged In User
    usersMap["user_me"] = User(
      id = "user_me",
      username = "creator_hoggar",
      displayName = "مبدع الهڨار",
      email = "user@elhoggar.dz",
      avatarUrl = "",
      bio = "صانع محتوى ومستكشف في فضاء الهڨار. أشارككم أجمل اللحظات والقصص المصورة.",
      role = UserRole.Standard,
      isVerified = false,
      isPrivate = false,
    )

    // 3. Featured Creators from Feed
    usersMap["creator_01"] = User(
      id = "creator_01",
      username = "hoggar_explorer",
      displayName = "مستكشف الهڨار",
      email = "explorer@elhoggar.dz",
      avatarUrl = "https://picsum.photos/seed/avatar1/200/200",
      bio = "رحالة ومصور في أعماق الصحراء الجزائرية. قمة تاهات ورمال العرق الغربي الكبير.",
      role = UserRole.Standard,
      isVerified = true,
      isPrivate = false,
    )

    usersMap["creator_02"] = User(
      id = "creator_02",
      username = "tamanrasset_crafts",
      displayName = "حِرَف تمنراست",
      email = "crafts@elhoggar.dz",
      avatarUrl = "https://picsum.photos/seed/avatar2/200/200",
      bio = "توثيق فنون صياغة الفضة والنقوش والرموز الهندسية التارقية الأصيلة.",
      role = UserRole.Standard,
      isVerified = true,
      isPrivate = false,
    )

    usersMap["creator_03"] = User(
      id = "creator_03",
      username = "sahara_rhythms",
      displayName = "إيقاعات الصحراء",
      email = "music@elhoggar.dz",
      avatarUrl = "https://picsum.photos/seed/avatar3/200/200",
      bio = "أصوات وموسيقى التيناريوين والتيندي من قلب الكثبان.",
      role = UserRole.Standard,
      isVerified = false,
      isPrivate = false,
    )

    usersMap["creator_04"] = User(
      id = "creator_04",
      username = "desert_tea",
      displayName = "كأس شاي صحراوي",
      email = "tea@elhoggar.dz",
      avatarUrl = "https://picsum.photos/seed/avatar4/200/200",
      bio = "يوميات البساطة والأصالة مع جلسات الشاي الصحراوي وأسرار الرغوة الثلاثية.",
      role = UserRole.Standard,
      isVerified = false,
      isPrivate = false,
    )

    usersMap["creator_05"] = User(
      id = "creator_05",
      username = "algeria_adventure",
      displayName = "مغامرات الجزائر",
      email = "adventure@elhoggar.dz",
      avatarUrl = "https://picsum.photos/seed/avatar5/200/200",
      bio = "فريق استكشاف المسارات البركانية والمغارات الأثرية في تمنراست والطاسيلي.",
      role = UserRole.Standard,
      isVerified = true,
      isPrivate = false,
    )
  }

  fun addUser(user: User) {
    usersMap[user.id] = user
    _usersUpdateFlow.value = Unit
  }

  override fun getUserById(userId: String, currentUserId: String?): Flow<UserProfile?> {
    if (!usersMap.containsKey(userId)) {
      try {
        com.google.firebase.firestore.FirebaseFirestore.getInstance()
          .collection("users")
          .document(userId)
          .get()
          .addOnSuccessListener { doc ->
            if (doc != null && doc.exists()) {
              val email = doc.getString("email") ?: ""
              val username = doc.getString("username") ?: email.substringBefore("@")
              val displayName = doc.getString("displayName") ?: username
              val photoUrl = doc.getString("photoURL") ?: ""
              val bio = doc.getString("bio") ?: ""
              val isPrivate = doc.getBoolean("isPrivate") ?: false
              val createdAt = doc.getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis()

              val u = User(
                id = userId,
                username = username,
                displayName = displayName,
                email = email,
                avatarUrl = photoUrl,
                bio = bio,
                role = UserRole.Standard,
                isVerified = false,
                isPrivate = isPrivate,
                createdAtMs = createdAt,
              )
              addUser(u)
            }
          }
      } catch (e: Exception) {
        // Fallback gracefully if Firestore not reached
      }
    }

    return combine(_usersUpdateFlow, followRepository.updatesFlow) { _, _ ->
      val user = usersMap[userId] ?: return@combine null
      val isFollowing = if (currentUserId != null) followRepository.isFollowing(currentUserId, userId) else false
      val isCurrent = currentUserId == userId
      val followers = followRepository.getFollowersCount(userId)
      val following = followRepository.getFollowingCount(userId)

      UserProfile(
        id = user.id,
        username = user.username,
        displayName = user.displayName,
        avatarUrl = user.avatarUrl,
        bio = user.bio,
        role = user.role,
        isVerified = user.isVerified,
        isPrivate = user.isPrivate,
        followersCount = followers,
        followingCount = following,
        totalLikesCount = calculateLikesForUser(userId),
        isFollowing = isFollowing,
        isCurrentUser = isCurrent,
      )
    }
  }

  override fun getUserByUsername(username: String, currentUserId: String?): Flow<UserProfile?> {
    val clean = username.trim().removePrefix("@").lowercase(Locale.ROOT)
    val user = usersMap.values.firstOrNull { it.username.lowercase(Locale.ROOT) == clean }
    if (user != null) {
      return getUserById(user.id, currentUserId)
    }
    return flow { emit(null) }
  }

  override suspend fun updateProfile(
    userId: String,
    displayName: String,
    bio: String,
    avatarUrl: String,
  ): Result<UserProfile> {
    val existing = usersMap[userId] ?: return Result.failure(NoSuchElementException("المستخدم غير موجود"))
    val updated = existing.copy(
      displayName = displayName.trim(),
      bio = bio.trim(),
      avatarUrl = avatarUrl.trim(),
    )
    usersMap[userId] = updated
    _usersUpdateFlow.value = Unit

    val profile = UserProfile(
      id = updated.id,
      username = updated.username,
      displayName = updated.displayName,
      avatarUrl = updated.avatarUrl,
      bio = updated.bio,
      role = updated.role,
      isVerified = updated.isVerified,
      isPrivate = updated.isPrivate,
      followersCount = followRepository.getFollowersCount(userId),
      followingCount = followRepository.getFollowingCount(userId),
      totalLikesCount = calculateLikesForUser(userId),
      isFollowing = false,
      isCurrentUser = true,
    )
    return Result.success(profile)
  }

  override fun isUsernameAvailable(username: String, currentUserId: String?): Boolean {
    val clean = username.trim().removePrefix("@").lowercase(Locale.ROOT)
    val existing = usersMap.values.firstOrNull { it.username.lowercase(Locale.ROOT) == clean }
    return existing == null || existing.id == currentUserId
  }

  override fun getUserVideos(userId: String): Flow<List<VideoItem>> = flow {
    videoRepository.getFeedVideos().collect { result ->
      result.onSuccess { allVideos ->
        val filtered = allVideos.filter { it.creator.id == userId }
        // If empty (e.g. user_me or official), return mock creations or sample grid
        if (filtered.isEmpty()) {
          emit(allVideos.take(3).map { it.copy(id = "${userId}_${it.id}") })
        } else {
          emit(filtered)
        }
      }.onFailure {
        emit(emptyList())
      }
    }
  }

  override suspend fun deleteUser(userId: String): Result<Boolean> {
    if (userId == "official_elhoggar") {
      return Result.failure(IllegalStateException("لا يمكن حذف الحساب الرسمي للمنصة"))
    }
    usersMap.remove(userId)
    _usersUpdateFlow.value = Unit
    return Result.success(true)
  }

  private fun calculateLikesForUser(userId: String): Long {
    return when (userId) {
      "official_elhoggar" -> 580000L
      "creator_01" -> 84000L
      "creator_02" -> 36000L
      "creator_03" -> 52000L
      "creator_04" -> 28000L
      "creator_05" -> 160000L
      else -> 1420L
    }
  }
}
