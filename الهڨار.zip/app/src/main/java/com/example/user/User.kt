package com.example.user

enum class UserRole {
  Standard,
  OfficialBrand,
  Admin
}

/**
 * Core User Entity
 */
data class User(
  val id: String,
  val username: String,
  val displayName: String,
  val email: String,
  val avatarUrl: String = "",
  val bio: String = "",
  val role: UserRole = UserRole.Standard,
  val isVerified: Boolean = false,
  val isPrivate: Boolean = false,
  val passwordHash: String = "",
  val salt: String = "",
  val createdAtMs: Long = System.currentTimeMillis(),
  val followersCount: Long = 0L,
  val followingCount: Long = 0L,
  val videosCount: Long = 0L,
  val likesCount: Long = 0L,
)

/**
 * Public Profile Representation
 */
data class UserProfile(
  val id: String,
  val username: String,
  val displayName: String,
  val avatarUrl: String,
  val bio: String,
  val role: UserRole = UserRole.Standard,
  val isVerified: Boolean = false,
  val isPrivate: Boolean = false,
  val followersCount: Long = 0L,
  val followingCount: Long = 0L,
  val totalLikesCount: Long = 0L,
  val isFollowing: Boolean = false,
  val isCurrentUser: Boolean = false,
)
