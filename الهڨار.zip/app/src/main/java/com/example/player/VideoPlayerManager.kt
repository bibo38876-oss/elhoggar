package com.example.player

import android.content.Context
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import android.os.Build
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.mediacodec.MediaCodecInfo
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Manages a single shared ExoPlayer instance for the vertical video feed.
 * Using a single dedicated player prevents multiple concurrent MediaCodec decoders,
 * eliminating Codec2 resource exhaustion ("Failed to query component interface for required system resources: 6")
 * and ensuring smooth 60fps scrolling and instant video transitions.
 */
@OptIn(UnstableApi::class)
class VideoPlayerManager(
  private val context: Context,
) {
  private val playerScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
  private var progressJob: Job? = null

  // Active playing video ID and current loaded URL
  private val _activeVideoId = MutableStateFlow<String?>(null)
  val activeVideoId: StateFlow<String?> = _activeVideoId.asStateFlow()
  private var currentLoadedUrl: String? = null

  // Global mute toggle
  private val _isMuted = MutableStateFlow(false)
  val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

  private val _playbackSpeed = MutableStateFlow(1.0f)
  val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

  // Track playback progress & time
  private val _playbackProgress = MutableStateFlow(0f)
  val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

  private val _currentPositionMs = MutableStateFlow(0L)
  val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

  private val _durationMs = MutableStateFlow(0L)
  val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

  // Resilient DataSourceFactory
  private val mediaSourceFactory: DefaultMediaSourceFactory by lazy {
    val httpDataSourceFactory = DefaultHttpDataSource.Factory()
      .setUserAgent("HoggarVideoApp/1.0 (Android; Mobile)")
      .setAllowCrossProtocolRedirects(true)
      .setConnectTimeoutMs(15000)
      .setReadTimeoutMs(15000)
    val dataSourceFactory = DefaultDataSource.Factory(context, httpDataSourceFactory)
    DefaultMediaSourceFactory(dataSourceFactory)
  }

  private fun isRunningOnEmulator(): Boolean {
    val fingerprint = Build.FINGERPRINT ?: ""
    val model = Build.MODEL ?: ""
    val hardware = Build.HARDWARE ?: ""
    val product = Build.PRODUCT ?: ""
    return (fingerprint.startsWith("generic")
        || fingerprint.startsWith("unknown")
        || model.contains("google_sdk")
        || model.contains("Emulator")
        || model.contains("Android SDK built for")
        || hardware.contains("goldfish")
        || hardware.contains("ranchu")
        || product.contains("sdk")
        || product.contains("emulator"))
  }

  // Single shared player instance with graceful software fallback if hardware decoders are constrained
  private val renderersFactory: DefaultRenderersFactory by lazy {
    val mediaCodecSelector = MediaCodecSelector { mimeType, requiresSecure, requiresTunneling ->
      val decoders = MediaCodecSelector.DEFAULT.getDecoderInfos(mimeType, requiresSecure, requiresTunneling)
      if (isRunningOnEmulator()) {
        // 1. If classic OpenMAX decoders exist (e.g. OMX.google.*), use them to bypass C2Store completely
        val omxDecoders = decoders.filter { it.name.startsWith("OMX.google.") }
        if (omxDecoders.isNotEmpty()) {
          omxDecoders
        } else {
          // 2. Filter out goldfish/ranchu virtual C2 components that fail C2 system resource queries:
          // "Failed to query component interface for required system resources: 6"
          val nonGoldfishDecoders = decoders.filterNot {
            it.name.contains("goldfish", ignoreCase = true) || it.name.contains("ranchu", ignoreCase = true)
          }
          if (nonGoldfishDecoders.isNotEmpty()) {
            nonGoldfishDecoders
          } else {
            decoders
          }
        }
      } else {
        decoders
      }
    }

    DefaultRenderersFactory(context).apply {
      setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
      setEnableDecoderFallback(true) // Enables software decoding fallback if Codec2 hardware decoder fails
      setMediaCodecSelector(mediaCodecSelector)
    }
  }

  val primaryPlayer: ExoPlayer by lazy {
    ExoPlayer.Builder(context, renderersFactory)
      .setMediaSourceFactory(mediaSourceFactory)
      .build()
      .apply {
        repeatMode = Player.REPEAT_MODE_ONE
        volume = if (_isMuted.value) 0f else 1f
        playWhenReady = true

        addListener(object : Player.Listener {
          override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_READY && duration > 0) {
              _currentPositionMs.value = currentPosition
              _durationMs.value = duration
              _playbackProgress.value = (currentPosition.toFloat() / duration).coerceIn(0f, 1f)
            }
          }

          override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
              startProgressTracking()
            } else {
              stopProgressTracking()
            }
          }

          override fun onPlayerError(error: PlaybackException) {
            Log.w("VideoPlayerManager", "Playback error: ${error.message}. Recovering with fallback asset.")
            try {
              val fallbackUri = "asset:///videos/hoggar_1.mp4"
              setMediaItem(MediaItem.fromUri(fallbackUri))
              prepare()
              playWhenReady = true
            } catch (e: Exception) {
              Log.e("VideoPlayerManager", "Fallback recovery failed", e)
            }
          }
        })
      }
  }

  private fun startProgressTracking() {
    progressJob?.cancel()
    progressJob = playerScope.launch {
      while (isActive) {
        if (primaryPlayer.playbackState == Player.STATE_READY && primaryPlayer.duration > 0) {
          val pos = primaryPlayer.currentPosition
          val dur = primaryPlayer.duration
          _currentPositionMs.value = pos
          _durationMs.value = dur
          _playbackProgress.value = (pos.toFloat() / dur).coerceIn(0f, 1f)
        }
        delay(120)
      }
    }
  }

  private fun stopProgressTracking() {
    progressJob?.cancel()
    progressJob = null
  }

  /**
   * Seeks to a normalized progress fraction (0.0 to 1.0)
   */
  fun seekTo(progressFraction: Float) {
    if (primaryPlayer.playbackState == Player.STATE_READY && primaryPlayer.duration > 0) {
      val targetMs = (progressFraction.coerceIn(0f, 1f) * primaryPlayer.duration).toLong()
      primaryPlayer.seekTo(targetMs)
      _currentPositionMs.value = targetMs
      _playbackProgress.value = progressFraction.coerceIn(0f, 1f)
    }
  }

  /**
   * Returns the shared player.
   */
  fun getOrCreatePlayer(videoId: String, videoUrl: String): ExoPlayer {
    return primaryPlayer
  }

  /**
   * Activates playback for target video.
   */
  fun playVideo(videoId: String, videoUrl: String) {
    if (_activeVideoId.value == videoId && currentLoadedUrl == videoUrl) {
      if (!primaryPlayer.isPlaying) {
        primaryPlayer.playWhenReady = true
      }
      return
    }

    _activeVideoId.value = videoId
    currentLoadedUrl = videoUrl
    resetPlaybackSpeed()

    val safeUrl = if (videoUrl.contains("commondatastorage.googleapis.com")) {
      "asset:///videos/hoggar_1.mp4"
    } else {
      videoUrl
    }

    try {
      primaryPlayer.setMediaItem(MediaItem.fromUri(safeUrl))
      primaryPlayer.volume = if (_isMuted.value) 0f else 1f
      primaryPlayer.prepare()
      primaryPlayer.playWhenReady = true
    } catch (e: Exception) {
      Log.e("VideoPlayerManager", "Failed to play video $videoId", e)
    }
  }

  fun pauseActiveVideo() {
    primaryPlayer.playWhenReady = false
  }

  fun resumeActiveVideo() {
    primaryPlayer.playWhenReady = true
  }

  fun togglePlayPause(): Boolean {
    val willPlay = !primaryPlayer.playWhenReady
    primaryPlayer.playWhenReady = willPlay
    return willPlay
  }

  fun toggleMute(): Boolean {
    val newMute = !_isMuted.value
    _isMuted.value = newMute
    primaryPlayer.volume = if (newMute) 0f else 1f
    return newMute
  }

  fun setPlaybackSpeed(speed: Float) {
    _playbackSpeed.value = speed
    primaryPlayer.setPlaybackSpeed(speed)
  }

  fun resetPlaybackSpeed() {
    if (_playbackSpeed.value != 1.0f) {
      _playbackSpeed.value = 1.0f
      primaryPlayer.setPlaybackSpeed(1.0f)
    }
  }

  fun preloadVideo(videoId: String, videoUrl: String) {
    // Lightweight no-op: We intentionally do not spin up extra hardware decoders for preloading,
    // protecting system resources and avoiding C2_NO_MEMORY errors in the emulator.
  }

  fun releaseAll() {
    stopProgressTracking()
    try {
      primaryPlayer.stop()
      primaryPlayer.release()
    } catch (e: Exception) {
      Log.e("VideoPlayerManager", "Error releasing player", e)
    }
    _activeVideoId.value = null
    currentLoadedUrl = null
  }
}
