package com.example.player

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.model.VideoItem
import com.example.ui.components.HoggarLoadingIndicator
import com.example.ui.theme.HoggarColorTokens
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun HoggarPlayerView(
  videoItem: VideoItem,
  player: ExoPlayer,
  isActive: Boolean,
  onDoubleTapLike: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var isBuffering by remember { mutableStateOf(false) }
  var isPausedManually by remember { mutableStateOf(false) }
  var showHeartBurst by remember { mutableStateOf(false) }
  var isSpeedBoostActive by remember { mutableStateOf(false) }

  // Listen to ExoPlayer playback state only when this item is active
  DisposableEffect(player, isActive) {
    if (!isActive) {
      return@DisposableEffect onDispose {}
    }

    val listener = object : Player.Listener {
      override fun onPlaybackStateChanged(playbackState: Int) {
        isBuffering = playbackState == Player.STATE_BUFFERING
      }

      override fun onIsPlayingChanged(isPlaying: Boolean) {
        if (isActive) {
          isPausedManually = !player.playWhenReady
        }
      }
    }
    player.addListener(listener)
    onDispose {
      player.removeListener(listener)
      if (isSpeedBoostActive) {
        isSpeedBoostActive = false
        player.setPlaybackSpeed(1.0f)
      }
    }
  }

  // Hide heart burst animation after delay
  LaunchedEffect(showHeartBurst) {
    if (showHeartBurst) {
      delay(800)
      showHeartBurst = false
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .pointerInput(isActive) {
        detectTapGestures(
          onTap = {
            if (isActive && !isSpeedBoostActive) {
              val willPlay = !player.playWhenReady
              player.playWhenReady = willPlay
              isPausedManually = !willPlay
            }
          },
          onDoubleTap = {
            onDoubleTapLike()
            showHeartBurst = true
          },
          onPress = {
            val boostJob = scope.launch {
              delay(320)
              if (isActive && player.playWhenReady) {
                isSpeedBoostActive = true
                player.setPlaybackSpeed(2.0f)
              }
            }
            try {
              tryAwaitRelease()
            } finally {
              boostJob.cancel()
              if (isSpeedBoostActive) {
                isSpeedBoostActive = false
                player.setPlaybackSpeed(1.0f)
              }
            }
          },
        )
      }
      .testTag("hoggar_player_view_${videoItem.id}"),
    contentAlignment = Alignment.Center,
  ) {
    // 1. Base High-Resolution Thumbnail: Always rendered so transitions are immediate with zero flicker
    AsyncImage(
      model = videoItem.thumbnailUrl,
      contentDescription = videoItem.title,
      modifier = Modifier.fillMaxSize(),
      contentScale = ContentScale.Crop,
    )

    // 2. AndroidView wrapping Media3 PlayerView ONLY when active
    // Uses TextureView to eliminate C2_NO_MEMORY ("Failed to query component interface for required system resources: 6")
    // and prevent BLASTBufferQueue surface conflicts during compose transitions.
    if (isActive) {
      AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
          (android.view.LayoutInflater.from(ctx).inflate(
            com.example.R.layout.view_hoggar_player,
            null,
            false,
          ) as PlayerView).apply {
            this.player = player
          }
        },
        update = { playerView ->
          if (playerView.player != player) {
            playerView.player = player
          }
        },
        onReset = { playerView ->
          playerView.player = null
        },
        onRelease = { playerView ->
          playerView.player = null
        },
      )
    }

    // 3. Custom Geometric Loading State when Buffering
    if (isBuffering && isActive) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color(0x33000000)),
        contentAlignment = Alignment.Center,
      ) {
        HoggarLoadingIndicator(size = 56.dp)
      }
    }

    // 4. Paused Indicator Icon Overlay
    AnimatedVisibility(
      visible = isPausedManually && isActive,
      enter = fadeIn(tween(200)) + scaleIn(tween(200), initialScale = 0.8f),
      exit = fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 0.8f),
    ) {
      Box(
        modifier = Modifier
          .size(72.dp)
          .clip(CircleShape)
          .background(Color(0x77000000)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.PlayArrow,
          contentDescription = "Paused",
          tint = HoggarColorTokens.TextPrimary,
          modifier = Modifier.size(44.dp),
        )
      }
    }

    // 5. Double-Tap Floating Heart Burst with Hoggar Radiant Glow
    AnimatedVisibility(
      visible = showHeartBurst,
      enter = fadeIn(tween(120)) + scaleIn(tween(200), initialScale = 0.3f),
      exit = fadeOut(tween(350)) + scaleOut(tween(350), targetScale = 1.4f),
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = Icons.Filled.Favorite,
          contentDescription = null,
          tint = HoggarColorTokens.CopperPrimary.copy(alpha = 0.45f),
          modifier = Modifier.size(116.dp),
        )
        Icon(
          imageVector = Icons.Filled.Favorite,
          contentDescription = "Liked",
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(92.dp),
        )
      }
    }

    // 6. 2X Speed Boost Indicator Overlay
    AnimatedVisibility(
      visible = isSpeedBoostActive && isActive,
      enter = fadeIn(tween(150)) + scaleIn(tween(150), initialScale = 0.9f),
      exit = fadeOut(tween(150)) + scaleOut(tween(150), targetScale = 0.9f),
      modifier = Modifier
        .align(Alignment.TopCenter)
        .padding(top = 64.dp),
    ) {
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(Color(0xDD0D0F12))
          .border(1.dp, HoggarColorTokens.InteractiveAmber, RoundedCornerShape(20.dp))
          .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.FastForward,
          contentDescription = null,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(16.dp),
        )
        Text(
          text = "2X تسريع التشغيل",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
        )
      }
    }
  }
}
