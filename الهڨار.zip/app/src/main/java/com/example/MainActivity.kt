package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import com.example.localization.LocalLocalization
import com.example.localization.LocalizationState
import com.example.ui.MainAppContainer
import com.example.ui.screens.FirstRunScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.ElHoggarTheme

sealed interface AppScreenState {
  data object Splash : AppScreenState
  data object FirstRun : AppScreenState
  data class Main(val startOnAuth: Boolean = false) : AppScreenState
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      val context = LocalContext.current
      val localizationState = remember { LocalizationState.loadInitial(context) }

      CompositionLocalProvider(
        LocalLocalization provides localizationState,
        LocalLayoutDirection provides localizationState.currentLanguage.layoutDirection,
      ) {
        ElHoggarTheme {
          var currentScreen by remember { mutableStateOf<AppScreenState>(AppScreenState.Splash) }

          Crossfade(
            targetState = currentScreen,
            animationSpec = tween(400),
            modifier = Modifier.fillMaxSize(),
            label = "screen_crossfade",
          ) { screen ->
            when (screen) {
              is AppScreenState.Splash -> {
                SplashScreen(
                  onFinish = {
                    val prefs = context.getSharedPreferences("elhoggar_settings", Context.MODE_PRIVATE)
                    val hasCompletedFirstRun = prefs.getBoolean("has_completed_first_run", false)
                    if (!hasCompletedFirstRun) {
                      currentScreen = AppScreenState.FirstRun
                    } else {
                      currentScreen = AppScreenState.Main(startOnAuth = false)
                    }
                  },
                )
              }
              is AppScreenState.FirstRun -> {
                FirstRunScreen(
                  onContinueAsGuest = {
                    currentScreen = AppScreenState.Main(startOnAuth = false)
                  },
                  onGoToAuth = {
                    currentScreen = AppScreenState.Main(startOnAuth = true)
                  },
                )
              }
              is AppScreenState.Main -> {
                MainAppContainer(
                  initialGoToAuth = screen.startOnAuth,
                  onReplaySplash = { currentScreen = AppScreenState.Splash },
                )
              }
            }
          }
        }
      }
    }
  }
}
