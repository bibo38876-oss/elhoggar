package com.example.data.repository

import com.example.model.CreatorModel
import com.example.model.PostItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import java.util.UUID

interface PostRepository {
  fun getAllPosts(): Flow<List<PostItem>>
  fun getPostsByAuthor(authorId: String): Flow<List<PostItem>>
  fun getPostsByTag(tag: String): Flow<List<PostItem>>
  suspend fun createPost(
    author: CreatorModel,
    text: String,
    imageUrls: List<String> = emptyList(),
    tags: List<String> = emptyList(),
  ): Result<PostItem>
  suspend fun toggleLike(postId: String): Result<Boolean>
  suspend fun toggleRepost(postId: String): Result<Boolean>
  suspend fun toggleBookmark(postId: String): Result<Boolean>
  suspend fun deletePost(postId: String, currentUserId: String): Result<Boolean>
}

class InMemoryPostRepository : PostRepository {
  private val _posts = MutableStateFlow<List<PostItem>>(initialPosts())

  override fun getAllPosts(): Flow<List<PostItem>> = _posts.asStateFlow()

  override fun getPostsByAuthor(authorId: String): Flow<List<PostItem>> =
    _posts.map { list -> list.filter { it.author.id == authorId } }

  override fun getPostsByTag(tag: String): Flow<List<PostItem>> =
    _posts.map { list ->
      val cleanTag = if (tag.startsWith("#")) tag else "#$tag"
      list.filter { it.tags.any { t -> t.equals(cleanTag, ignoreCase = true) } || it.contentText.contains(cleanTag) }
    }

  override suspend fun createPost(
    author: CreatorModel,
    text: String,
    imageUrls: List<String>,
    tags: List<String>,
  ): Result<PostItem> {
    // Extract hashtags from text if tags list is empty
    val extractedTags = if (tags.isEmpty()) {
      Regex("#[\\w\\u0600-\\u06FF]+").findAll(text).map { it.value }.toList()
    } else {
      tags
    }

    val newPost = PostItem(
      id = "post_${UUID.randomUUID().toString().take(8)}",
      author = author,
      contentText = text,
      imageUrls = imageUrls,
      tags = extractedTags,
      timestampMs = System.currentTimeMillis(),
      likesCount = 0L,
      repostsCount = 0L,
      repliesCount = 0L,
      viewsCount = 1L,
      isLiked = false,
      isReposted = false,
      isBookmarked = false,
    )

    val current = _posts.value.toMutableList()
    current.add(0, newPost)
    _posts.value = current
    return Result.success(newPost)
  }

  override suspend fun toggleLike(postId: String): Result<Boolean> {
    val current = _posts.value.toMutableList()
    val index = current.indexOfFirst { it.id == postId }
    if (index != -1) {
      val item = current[index]
      val newLiked = !item.isLiked
      val newLikes = if (newLiked) item.likesCount + 1 else (item.likesCount - 1).coerceAtLeast(0)
      current[index] = item.copy(isLiked = newLiked, likesCount = newLikes)
      _posts.value = current
      return Result.success(newLiked)
    }
    return Result.failure(NoSuchElementException("Post not found"))
  }

  override suspend fun toggleRepost(postId: String): Result<Boolean> {
    val current = _posts.value.toMutableList()
    val index = current.indexOfFirst { it.id == postId }
    if (index != -1) {
      val item = current[index]
      val newReposted = !item.isReposted
      val newReposts = if (newReposted) item.repostsCount + 1 else (item.repostsCount - 1).coerceAtLeast(0)
      current[index] = item.copy(isReposted = newReposted, repostsCount = newReposts)
      _posts.value = current
      return Result.success(newReposted)
    }
    return Result.failure(NoSuchElementException("Post not found"))
  }

  override suspend fun toggleBookmark(postId: String): Result<Boolean> {
    val current = _posts.value.toMutableList()
    val index = current.indexOfFirst { it.id == postId }
    if (index != -1) {
      val item = current[index]
      val newBookmarked = !item.isBookmarked
      current[index] = item.copy(isBookmarked = newBookmarked)
      _posts.value = current
      return Result.success(newBookmarked)
    }
    return Result.failure(NoSuchElementException("Post not found"))
  }

  override suspend fun deletePost(postId: String, currentUserId: String): Result<Boolean> {
    val current = _posts.value.toMutableList()
    val index = current.indexOfFirst { it.id == postId }
    if (index != -1) {
      val item = current[index]
      if (item.author.id != currentUserId && currentUserId != "admin") {
        return Result.failure(IllegalAccessException("غير مصرح لك بحذف هذا المنشور"))
      }
      current.removeAt(index)
      _posts.value = current
      return Result.success(true)
    }
    return Result.failure(NoSuchElementException("Post not found"))
  }

  companion object {
    private fun initialPosts(): List<PostItem> {
      return listOf(
        PostItem(
          id = "post_001",
          author = CreatorModel(
            id = "creator_01",
            username = "tassili_explorer",
            displayName = "مستكشف الطاسيلي",
            avatarUrl = "https://picsum.photos/seed/avatar1/200/200",
            isVerified = true,
            bio = "رحالة ومصور في صحراء الهڨار",
          ),
          contentText = "من قمة أسكرام، حيث قال الأب فوكو: «هنا تشعر أنك بين الأرض والسماء». شروق الشمس اليوم كان من أجمل ما رأيت في حياتي! 🌅✨ هل جربتم التخييم في هذا الارتفاع البارد ليلاً؟ #الهڨار #أسكرام #سياحة_الجزائر",
          imageUrls = listOf(
            "https://picsum.photos/seed/askram_dawn1/800/600",
            "https://picsum.photos/seed/askram_dawn2/800/600",
          ),
          tags = listOf("#الهڨار", "#أسكرام", "#سياحة_الجزائر"),
          timestampMs = System.currentTimeMillis() - 1000 * 60 * 35, // 35 mins ago
          likesCount = 342L,
          repostsCount = 48L,
          repliesCount = 29L,
          viewsCount = 4200L,
        ),
        PostItem(
          id = "post_002",
          author = CreatorModel(
            id = "creator_03",
            username = "hoggar_tunes",
            displayName = "ألحان الطيندي",
            avatarUrl = "https://picsum.photos/seed/avatar3/200/200",
            isVerified = true,
            bio = "صوت التارقي وإيقاعات الجنوب الأصيل",
          ),
          contentText = "موسيقى الطيندي ليست مجرد إيقاع على جلد مشدود، بل هي لغة توارثتها أمهاتنا عبر آلاف السنين لتسرد قصص الحب، الشجاعة، والارتحال في عمق الصحراء الكبرى. ما هي أغنيتكم التارقية المفضلة؟ 🎶🪘 #تيناريوين #موسيقى #ثقافة_صحراوية",
          imageUrls = emptyList(),
          tags = listOf("#تيناريوين", "#موسيقى", "#ثقافة_صحراوية"),
          timestampMs = System.currentTimeMillis() - 1000 * 60 * 120, // 2 hours ago
          likesCount = 512L,
          repostsCount = 84L,
          repliesCount = 63L,
          viewsCount = 7800L,
        ),
        PostItem(
          id = "post_003",
          author = CreatorModel(
            id = "creator_02",
            username = "tuareg_crafts",
            displayName = "حرفيو تمنراست",
            avatarUrl = "https://picsum.photos/seed/avatar2/200/200",
            isVerified = true,
            bio = "حفظ التراث والصناعات التقليدية",
          ),
          contentText = "تم الانتهاء بحمد الله من صياغة صليب الجنوب (صليب أكاديز وتمنراست) من الفضة الخالصة عيار 925، مع ترصيع حجر العقيق الصحراوي. كل زاوية فيه ترمز إلى اتجاه من اتجاهات القوافل 🧭✨ #صناعة_الفضة #تمنراست #حرف_يدوية",
          imageUrls = listOf(
            "https://picsum.photos/seed/silver_cross1/800/600",
            "https://picsum.photos/seed/silver_cross2/800/600",
            "https://picsum.photos/seed/silver_cross3/800/600",
          ),
          tags = listOf("#صناعة_الفضة", "#تمنراست", "#حرف_يدوية"),
          timestampMs = System.currentTimeMillis() - 1000 * 60 * 360, // 6 hours ago
          likesCount = 890L,
          repostsCount = 132L,
          repliesCount = 77L,
          viewsCount = 12400L,
        ),
        PostItem(
          id = "post_004",
          author = CreatorModel(
            id = "creator_04",
            username = "desert_tea",
            displayName = "مجلس الشاي الصحراوي",
            avatarUrl = "https://picsum.photos/seed/avatar4/200/200",
            isVerified = false,
            bio = "الشاي على الجمر وأحاديث البادية",
          ),
          contentText = "قاعدة الشاي التارقي الثلاثية: الكأس الأول مرّ كالحياة، والثاني قوي كالحب، والثالث حلو كالموت. مساؤكم معطر بالنعناع والسكينة من عمق الهڨار ☕️🪵 #شاي_صحراوي #جلسات_طيبة",
          imageUrls = listOf(
            "https://picsum.photos/seed/desert_tea_fire/800/600",
          ),
          tags = listOf("#شاي_صحراوي", "#جلسات_طيبة"),
          timestampMs = System.currentTimeMillis() - 1000 * 60 * 720, // 12 hours ago
          likesCount = 1240L,
          repostsCount = 210L,
          repliesCount = 115L,
          viewsCount = 18900L,
        ),
      )
    }
  }
}
