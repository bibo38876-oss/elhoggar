package com.example.data.repository

import com.example.model.VideoItem
import com.example.model.VideoProcessingStatus
import kotlinx.coroutines.flow.Flow

data class VideoUploadProgress(
  val status: VideoProcessingStatus,
  val progressFraction: Float = 0f,
  val stageDescription: String = "",
  val video: VideoItem? = null,
  val errorMessage: String? = null,
)

/**
 * Repository interface for video feed, upload pipeline, and social interactions.
 * Swappable with cloud backend (e.g. Firebase, REST API, Cloud Functions) without altering UI layer.
 */
interface VideoRepository {
  /**
   * Fetches vertical video feed items.
   * @param page Page index for progressive pagination.
   * @param pageSize Number of items per batch.
   */
  fun getFeedVideos(page: Int = 0, pageSize: Int = 10): Flow<Result<List<VideoItem>>>

  /**
   * Fetches videos created by a specific user/creator.
   */
  fun getVideosByOwner(ownerId: String): Flow<List<VideoItem>>

  /**
   * Publishes a new video through the backend processing pipeline:
   * Upload -> Validation -> Transcoding -> Thumbnail -> Moderation -> Published
   */
  fun publishVideo(video: VideoItem): Flow<VideoUploadProgress>

  /**
   * Deletes a video owned by the current user.
   */
  suspend fun deleteVideo(videoId: String, currentUserId: String): Result<Boolean>

  /**
   * Updates visibility of a video (Public/Private/Unlisted).
   */
  suspend fun updateVideoVisibility(videoId: String, currentUserId: String, visibility: com.example.model.VideoVisibility): Result<Boolean>

  /**
   * Toggles like state on a video.
   */
  suspend fun toggleLike(videoId: String): Result<Boolean>

  /**
   * Toggles bookmark state on a video.
   */
  suspend fun toggleBookmark(videoId: String): Result<Boolean>

  /**
   * Toggles follow status for a creator.
   */
  suspend fun toggleFollow(creatorId: String): Result<Boolean>
}
