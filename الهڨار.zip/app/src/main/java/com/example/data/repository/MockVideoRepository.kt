package com.example.data.repository

import com.example.model.CreatorModel
import com.example.model.VideoItem
import com.example.model.VideoProcessingStatus
import com.example.model.VideoStats
import com.example.model.VideoVisibility
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import java.util.UUID

class MockVideoRepository : VideoRepository {

  // In-memory mutable video store
  private val videos = mutableListOf(
    VideoItem(
      id = "hoggar_001",
      videoUrl = "asset:///videos/hoggar_1.mp4",
      thumbnailUrl = "https://picsum.photos/seed/hoggar1/720/1280",
      title = "غروب الشمس فوق قمم الهڨار الشامخة",
      description = "اللحظات الذهبية عند أعلى قمة في الجزائر (تاهات - 2908م). هدوء الصحراء الساحر والضوء النحاسي يملأ الأفق #الهڨار #تاهات #الجزائر #سياحة",
      tags = listOf("#الهڨار", "#تاهات", "#الجزائر", "#سياحة", "#صحراء"),
      durationSeconds = 45,
      creator = CreatorModel(
        id = "creator_01",
        username = "hoggar_explorer",
        displayName = "مستكشف الهڨار",
        avatarUrl = "https://picsum.photos/seed/avatar1/200/200",
        isVerified = true,
        bio = "رحالة ومصور في أعماق الصحراء الجزائرية",
        followersCount = 42800,
      ),
      ownerId = "creator_01",
      stats = VideoStats(
        likesCount = 38400,
        commentsCount = 1240,
        sharesCount = 3120,
        viewsCount = 184000,
      ),
      soundTitle = "الصوت الأصلي - رياح أسكرام",
      soundAuthor = "@hoggar_explorer",
      visibility = VideoVisibility.Public,
      processingStatus = VideoProcessingStatus.Published,
      isLiked = false,
      isBookmarked = false,
      isFollowing = false,
    ),
    VideoItem(
      id = "hoggar_002",
      videoUrl = "asset:///videos/hoggar_2.mp4",
      thumbnailUrl = "https://picsum.photos/seed/hoggar2/720/1280",
      title = "حرف الفضة والنقوش الهندسية الأمازيغية",
      description = "صناعة قلادة الهڨار بالفضة النقية والنار الهادئة. دقة متناهية وإرث أجداد يتوارثه جيل بعد جيل في تمنراست #حرف_يدوية #فضة #تمنراست #أمازيغ",
      tags = listOf("#حرف_يدوية", "#فضة", "#تمنراست", "#أمازيغ", "#فن"),
      durationSeconds = 38,
      creator = CreatorModel(
        id = "creator_02",
        username = "tamanrasset_crafts",
        displayName = "حِرَف تمنراست",
        avatarUrl = "https://picsum.photos/seed/avatar2/200/200",
        isVerified = true,
        bio = "توثيق فنون الصياغة والزخرفة الصحراوية",
        followersCount = 19500,
      ),
      ownerId = "creator_02",
      stats = VideoStats(
        likesCount = 15800,
        commentsCount = 490,
        sharesCount = 890,
        viewsCount = 76000,
      ),
      soundTitle = "طرقات الفضة والأنفاس - تمنراست",
      soundAuthor = "@tamanrasset_crafts",
      visibility = VideoVisibility.Public,
      processingStatus = VideoProcessingStatus.Published,
      isLiked = true,
      isBookmarked = false,
      isFollowing = true,
    ),
    VideoItem(
      id = "hoggar_003",
      videoUrl = "asset:///videos/hoggar_3.mp4",
      thumbnailUrl = "https://picsum.photos/seed/hoggar3/720/1280",
      title = "موسيقى التيناريوين ورياح الطاسيلي",
      description = "إيقاع التيندي والجيتار الصحراوي تحت سماء ملأى بالنجوم. النقاء الصوتي في قلب السكون #طاسيلي #تيناريوين #موسيقى #الهڨار",
      tags = listOf("#طاسيلي", "#تيناريوين", "#موسيقى", "#الهڨار"),
      durationSeconds = 58,
      creator = CreatorModel(
        id = "creator_03",
        username = "sahara_rhythms",
        displayName = "إيقاعات الصحراء",
        avatarUrl = "https://picsum.photos/seed/avatar3/200/200",
        isVerified = false,
        bio = "أصوات وموسيقى من قلب الرمال",
        followersCount = 28900,
      ),
      ownerId = "creator_03",
      stats = VideoStats(
        likesCount = 27600,
        commentsCount = 840,
        sharesCount = 2410,
        viewsCount = 135000,
      ),
      soundTitle = "ألحان الطيندي الأصيلة",
      soundAuthor = "@sahara_rhythms",
      visibility = VideoVisibility.Public,
      processingStatus = VideoProcessingStatus.Published,
      isLiked = false,
      isBookmarked = true,
      isFollowing = false,
    ),
    VideoItem(
      id = "hoggar_004",
      videoUrl = "asset:///videos/hoggar_4.mp4",
      thumbnailUrl = "https://picsum.photos/seed/hoggar4/720/1280",
      title = "شاي الصحراء ذو الرغوة الثلاثية",
      description = "طقوس إعداد الشاي الصحراوي بالنعناع ورغوة الجمر في أسكرام. الجلسة التي لا تنتهي حكاياتها #شاي_صحراوي #أسكرام #تقاليد #الجزائر",
      tags = listOf("#شاي_صحراوي", "#أسكرام", "#تقاليد", "#الجزائر"),
      durationSeconds = 30,
      creator = CreatorModel(
        id = "creator_04",
        username = "desert_tea",
        displayName = "كأس شاي صحراوي",
        avatarUrl = "https://picsum.photos/seed/avatar4/200/200",
        isVerified = false,
        bio = "يوميات البساطة والأصالة",
        followersCount = 14300,
      ),
      ownerId = "creator_04",
      stats = VideoStats(
        likesCount = 19200,
        commentsCount = 612,
        sharesCount = 1105,
        viewsCount = 92000,
      ),
      soundTitle = "خرير الشاي وضحكات الأصدقاء",
      soundAuthor = "@desert_tea",
      visibility = VideoVisibility.Public,
      processingStatus = VideoProcessingStatus.Published,
      isLiked = false,
      isBookmarked = false,
      isFollowing = false,
    ),
    VideoItem(
      id = "hoggar_005",
      videoUrl = "asset:///videos/hoggar_5.mp4",
      thumbnailUrl = "https://picsum.photos/seed/hoggar5/720/1280",
      title = "رحلة العبور بين أعمدة الغرانيت",
      description = "المسارات الوعرة والتكوينات الصخرية الفريدة التي نحتتها الرياح عبر ملايين السنين. هل زرت تمنراست من قبل؟ #سفاري #مغامرة #الهڨار",
      tags = listOf("#سفاري", "#مغامرة", "#الهڨار", "#طبيعة"),
      durationSeconds = 50,
      creator = CreatorModel(
        id = "creator_05",
        username = "algeria_adventure",
        displayName = "مغامرات الجزائر",
        avatarUrl = "https://picsum.photos/seed/avatar5/200/200",
        isVerified = true,
        bio = "نكتشف أجمل بقع الجزائر بعدساتنا",
        followersCount = 89400,
      ),
      ownerId = "creator_05",
      stats = VideoStats(
        likesCount = 49100,
        commentsCount = 1920,
        sharesCount = 6700,
        viewsCount = 280000,
      ),
      soundTitle = "الصوت الأصلي - هبوب الشمال",
      soundAuthor = "@algeria_adventure",
      visibility = VideoVisibility.Public,
      processingStatus = VideoProcessingStatus.Published,
      isLiked = true,
      isBookmarked = true,
      isFollowing = true,
    ),
  )

  private val _videosUpdate = MutableStateFlow(Unit)

  override fun getFeedVideos(page: Int, pageSize: Int): Flow<Result<List<VideoItem>>> = flow {
    delay(100)
    // Only return Public videos in feed
    val publicVideos = videos.filter { it.visibility == VideoVisibility.Public && it.processingStatus == VideoProcessingStatus.Published }
    emit(Result.success(publicVideos))
  }

  override fun getVideosByOwner(ownerId: String): Flow<List<VideoItem>> = flow {
    val ownerVideos = videos.filter { it.ownerId == ownerId }
    emit(ownerVideos)
  }

  override fun publishVideo(video: VideoItem): Flow<VideoUploadProgress> = flow {
    // 1. Strict 60-Second Validation
    val duration = video.trimEndSeconds - video.trimStartSeconds
    if (duration > 60) {
      emit(
        VideoUploadProgress(
          status = VideoProcessingStatus.Failed,
          progressFraction = 0f,
          errorMessage = "الحد الأقصى المسموح به للفيديو هو 60 ثانية فقط",
        ),
      )
      return@flow
    }

    // Pipeline: Upload -> Validation -> Transcoding -> Thumbnail -> Moderation -> Published
    emit(VideoUploadProgress(VideoProcessingStatus.Uploading, 0.20f, "جارٍ رفع الفيديو إلى خوادم الهڨار..."))
    delay(400)

    emit(VideoUploadProgress(VideoProcessingStatus.Validating, 0.40f, "التحقق من سلامة الترميز والملف..."))
    delay(300)

    emit(VideoUploadProgress(VideoProcessingStatus.Transcoding, 0.65f, "معالجة الفيديو وتحسين الأبعاد العمودية (9:16)..."))
    delay(400)

    emit(VideoUploadProgress(VideoProcessingStatus.GeneratingThumbnail, 0.85f, "توليد صورة الغلاف بدقة عالية..."))
    delay(300)

    emit(VideoUploadProgress(VideoProcessingStatus.Moderating, 0.95f, "فحص المحتوى والالتزام بسياسة النشر..."))
    delay(300)

    val finalVideo = video.copy(
      id = "hoggar_${UUID.randomUUID().toString().take(8)}",
      durationSeconds = duration,
      processingStatus = VideoProcessingStatus.Published,
      timestampMs = System.currentTimeMillis(),
    )

    // Insert at beginning of feed
    videos.add(0, finalVideo)
    _videosUpdate.value = Unit

    emit(
      VideoUploadProgress(
        status = VideoProcessingStatus.Published,
        progressFraction = 1.0f,
        stageDescription = "تم نشر الفيديو بنجاح!",
        video = finalVideo,
      ),
    )
  }

  override suspend fun deleteVideo(videoId: String, currentUserId: String): Result<Boolean> {
    val index = videos.indexOfFirst { it.id == videoId }
    if (index == -1) {
      return Result.failure(NoSuchElementException("الفيديو غير موجود"))
    }
    val video = videos[index]
    if (video.ownerId != currentUserId) {
      return Result.failure(IllegalAccessException("غير مصرح لك بحذف هذا الفيديو"))
    }
    videos.removeAt(index)
    _videosUpdate.value = Unit
    return Result.success(true)
  }

  override suspend fun updateVideoVisibility(
    videoId: String,
    currentUserId: String,
    visibility: VideoVisibility,
  ): Result<Boolean> {
    val index = videos.indexOfFirst { it.id == videoId }
    if (index == -1) {
      return Result.failure(NoSuchElementException("الفيديو غير موجود"))
    }
    val video = videos[index]
    if (video.ownerId != currentUserId) {
      return Result.failure(IllegalAccessException("غير مصرح لك بتعديل هذا الفيديو"))
    }
    videos[index] = video.copy(visibility = visibility)
    _videosUpdate.value = Unit
    return Result.success(true)
  }

  override suspend fun toggleLike(videoId: String): Result<Boolean> {
    val index = videos.indexOfFirst { it.id == videoId }
    if (index != -1) {
      val item = videos[index]
      val newLiked = !item.isLiked
      val newCount = if (newLiked) item.stats.likesCount + 1 else item.stats.likesCount - 1
      videos[index] = item.copy(
        isLiked = newLiked,
        stats = item.stats.copy(likesCount = newCount),
      )
      return Result.success(newLiked)
    }
    return Result.failure(NoSuchElementException("Video not found"))
  }

  override suspend fun toggleBookmark(videoId: String): Result<Boolean> {
    val index = videos.indexOfFirst { it.id == videoId }
    if (index != -1) {
      val item = videos[index]
      val newBookmarked = !item.isBookmarked
      videos[index] = item.copy(isBookmarked = newBookmarked)
      return Result.success(newBookmarked)
    }
    return Result.failure(NoSuchElementException("Video not found"))
  }

  override suspend fun toggleFollow(creatorId: String): Result<Boolean> {
    var newState = false
    for (i in videos.indices) {
      if (videos[i].creator.id == creatorId) {
        newState = !videos[i].isFollowing
        videos[i] = videos[i].copy(isFollowing = newState)
      }
    }
    return Result.success(newState)
  }
}
