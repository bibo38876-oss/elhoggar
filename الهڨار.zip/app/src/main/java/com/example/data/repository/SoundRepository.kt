package com.example.data.repository

import com.example.model.SoundItem
import com.example.model.VideoItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import java.util.UUID

interface SoundRepository {
  fun getAllSounds(): Flow<List<SoundItem>>
  fun getTrendingSounds(): Flow<List<SoundItem>>
  fun searchSounds(query: String): Flow<List<SoundItem>>
  fun getSoundById(soundId: String): SoundItem?
  fun findSoundByTitle(title: String): SoundItem?
  fun extractAndRegisterSoundFromVideo(video: VideoItem): SoundItem
  fun incrementUsage(soundId: String)
}

class InMemorySoundRepository : SoundRepository {

  private val _sounds = MutableStateFlow<List<SoundItem>>(
    listOf(
      SoundItem(
        id = "snd_hoggar_001",
        title = "رياح أسكرام وأنفاس الصحراء",
        authorName = "مستكشف الهڨار",
        authorUsername = "hoggar_explorer",
        soundUrl = "asset:///videos/hoggar_1.mp4",
        coverUrl = "https://picsum.photos/seed/hoggar1/720/1280",
        durationSeconds = 45,
        originalVideoId = "hoggar_001",
        usageCount = 3840L,
        isTrending = true,
        isExtractedFromVideo = true,
      ),
      SoundItem(
        id = "snd_hoggar_002",
        title = "طرقات الفضة والأنفاس - تمنراست",
        authorName = "حِرَف تمنراست",
        authorUsername = "tamanrasset_crafts",
        soundUrl = "asset:///videos/hoggar_2.mp4",
        coverUrl = "https://picsum.photos/seed/hoggar2/720/1280",
        durationSeconds = 38,
        originalVideoId = "hoggar_002",
        usageCount = 1420L,
        isTrending = true,
        isExtractedFromVideo = true,
      ),
      SoundItem(
        id = "snd_hoggar_003",
        title = "موسيقى التيناريوين ورياح الطاسيلي",
        authorName = "إيقاعات الصحراء",
        authorUsername = "sahara_rhythms",
        soundUrl = "asset:///videos/hoggar_3.mp4",
        coverUrl = "https://picsum.photos/seed/hoggar3/720/1280",
        durationSeconds = 58,
        originalVideoId = "hoggar_003",
        usageCount = 6890L,
        isTrending = true,
        isExtractedFromVideo = true,
      ),
      SoundItem(
        id = "snd_hoggar_004",
        title = "إيقاعات الطيندي تحت نجوم الصحراء",
        authorName = "فرقة تمنراست التراثية",
        authorUsername = "hoggar_heritage",
        soundUrl = "asset:///videos/hoggar_1.mp4",
        coverUrl = "https://picsum.photos/seed/hoggar4/720/1280",
        durationSeconds = 50,
        originalVideoId = "hoggar_004",
        usageCount = 2150L,
        isTrending = true,
        isExtractedFromVideo = true,
      ),
      SoundItem(
        id = "snd_hoggar_005",
        title = "همس رمال العرق الغربي الكبير",
        authorName = "رحالة الجزائر",
        authorUsername = "dz_voyager",
        soundUrl = "asset:///videos/hoggar_2.mp4",
        coverUrl = "https://picsum.photos/seed/hoggar5/720/1280",
        durationSeconds = 42,
        originalVideoId = "hoggar_005",
        usageCount = 940L,
        isTrending = false,
        isExtractedFromVideo = true,
      ),
    )
  )

  override fun getAllSounds(): Flow<List<SoundItem>> = _sounds.asStateFlow()

  override fun getTrendingSounds(): Flow<List<SoundItem>> {
    return _sounds.map { list ->
      list.sortedByDescending { it.usageCount }
    }
  }

  override fun searchSounds(query: String): Flow<List<SoundItem>> {
    val clean = query.trim().lowercase()
    return _sounds.map { list ->
      if (clean.isEmpty()) {
        list
      } else {
        list.filter { sound ->
          sound.title.lowercase().contains(clean) ||
            sound.authorName.lowercase().contains(clean) ||
            sound.authorUsername.lowercase().contains(clean)
        }
      }
    }
  }

  override fun getSoundById(soundId: String): SoundItem? {
    return _sounds.value.find { it.id == soundId }
  }

  override fun findSoundByTitle(title: String): SoundItem? {
    val clean = title.trim()
    return _sounds.value.find {
      it.title.equals(clean, ignoreCase = true) ||
        it.title.contains(clean, ignoreCase = true) ||
        clean.contains(it.title, ignoreCase = true)
    }
  }

  /**
   * Automatically extracts the audio profile of any newly published video
   * and registers it in the shared Hoggar Sound Vault for any user to use.
   */
  override fun extractAndRegisterSoundFromVideo(video: VideoItem): SoundItem {
    val soundId = "snd_${video.id}"

    // Check if this video's sound is already indexed
    val existing = _sounds.value.find { it.originalVideoId == video.id || it.id == soundId }
    if (existing != null) {
      return existing
    }

    val extractedTitle = if (video.soundTitle.isNotBlank() && video.soundTitle != "الصوت الأصلي") {
      video.soundTitle
    } else {
      "صوت أصلي - @${video.creator.username}"
    }

    val newSound = SoundItem(
      id = soundId,
      title = extractedTitle,
      authorName = video.creator.displayName,
      authorUsername = video.creator.username,
      soundUrl = video.videoUrl,
      coverUrl = video.thumbnailUrl.ifEmpty { video.creator.avatarUrl },
      durationSeconds = video.durationSeconds,
      originalVideoId = video.id,
      usageCount = 1L,
      isTrending = false,
      isExtractedFromVideo = true,
      timestampMs = System.currentTimeMillis(),
    )

    // Prepend new extracted sound so it appears immediately in the community library
    val updated = listOf(newSound) + _sounds.value
    _sounds.value = updated

    return newSound
  }

  override fun incrementUsage(soundId: String) {
    val updated = _sounds.value.map { sound ->
      if (sound.id == soundId) {
        sound.copy(usageCount = sound.usageCount + 1L)
      } else {
        sound
      }
    }
    _sounds.value = updated
  }
}
