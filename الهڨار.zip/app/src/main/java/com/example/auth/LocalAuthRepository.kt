package com.example.auth

import com.example.user.MockUserRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

/**
 * Production Authentication Repository delegating to FirebaseAuthRepository.
 *
 * Real Firebase Auth & Firestore backend implementation:
 * - Uses Firebase Authentication as primary identity source.
 * - Enforces atomic profile creation in Firestore users/{uid}.
 * - Guarantees document ID matches request.auth.uid.
 * - Implements zero-trust security rules and production error handling.
 */
class LocalAuthRepository(
  userRepository: MockUserRepository,
  firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance(),
  firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
) : FirebaseAuthRepository(userRepository, firebaseAuth, firestore)
