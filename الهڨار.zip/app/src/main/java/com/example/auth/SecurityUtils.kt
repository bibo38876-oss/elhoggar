package com.example.auth

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale

object SecurityUtils {

  // Reserved official and system usernames
  private val ReservedUsernames = setOf(
    "elhoggar",
    "hoggar",
    "alhoggar",
    "الهڨار",
    "admin",
    "administrator",
    "official",
    "support",
    "system",
    "moderator",
    "security",
    "verified",
    "explore",
  )

  /**
   * Hashes a password with SHA-256 and a cryptographically secure salt.
   */
  fun hashPassword(password: String, salt: String): String {
    val md = MessageDigest.getInstance("SHA-256")
    md.update(salt.toByteArray(Charsets.UTF_8))
    val digest = md.digest(password.toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { "%02x".format(it) }
  }

  /**
   * Generates a 16-byte random salt.
   */
  fun generateSalt(): String {
    val random = SecureRandom()
    val saltBytes = ByteArray(16)
    random.nextBytes(saltBytes)
    return saltBytes.joinToString("") { "%02x".format(it) }
  }

  /**
   * Validates username against syntax and reserved name policy.
   */
  fun validateUsername(username: String): Result<String> {
    val clean = username.trim().removePrefix("@").lowercase(Locale.ROOT)
    if (clean.length < 3) {
      return Result.failure(IllegalArgumentException("اسم المستخدم يجب أن يتكون من 3 أحرف على الأقل"))
    }
    if (clean.length > 20) {
      return Result.failure(IllegalArgumentException("اسم المستخدم يجب ألا يتجاوز 20 حرفًا"))
    }
    val regex = Regex("^[a-zA-Z0-9_]+$")
    if (!regex.matches(clean)) {
      return Result.failure(IllegalArgumentException("يسمح بالحروف الإنجليزية، الأرقام، والشرطة السفلية (_) فقط"))
    }
    if (ReservedUsernames.contains(clean)) {
      return Result.failure(IllegalArgumentException("اسم المستخدم هذا محجوز للعلامة الرسمية والنظام"))
    }
    return Result.success(clean)
  }

  /**
   * Basic email format verification.
   */
  fun validateEmail(email: String): Boolean {
    val pattern = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\$")
    return pattern.matches(email.trim())
  }
}
