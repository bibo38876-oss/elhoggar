package com.example.auth

import android.content.Context
import com.example.user.User
import kotlinx.coroutines.flow.StateFlow

data class AuthState(
  val currentUser: User? = null,
  val isAuthenticated: Boolean = currentUser != null,
  val isLoading: Boolean = false,
  val errorMessage: String? = null,
)

interface AuthRepository {
  val authState: StateFlow<AuthState>

  suspend fun register(
    username: String,
    displayName: String,
    email: String,
    password: String,
    avatarUrl: String = "",
  ): Result<User>

  suspend fun login(
    identifier: String, // email or @username
    password: String,
  ): Result<User>

  suspend fun loginWithGoogle(context: Context): Result<User>

  suspend fun loginWithGoogleDirect(
    email: String,
    displayName: String,
    avatarUrl: String = "",
  ): Result<User>

  suspend fun logout()

  suspend fun recoverPassword(email: String): Result<String>

  suspend fun deleteAccount(userId: String): Result<Boolean>

  suspend fun updateCurrentUser(updatedUser: User)
}
