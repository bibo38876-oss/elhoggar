package com.example.auth

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.example.user.MockUserRepository
import com.example.user.User
import com.example.user.UserRole
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Production Firebase Authentication and Firestore User Profile repository.
 *
 * Requirements:
 * 1. Firebase Authentication as primary identity source.
 * 2. Firestore user profile stored at users/{uid} with strict uid parity.
 * 3. Consistent registration flow: Auth -> UID -> Firestore users/{uid} -> Success.
 * 4. Fallback profile sync on login if profile document does not yet exist.
 * 5. Guest mode by default with seamless interaction gating.
 */
open class FirebaseAuthRepository(
  private val userRepository: MockUserRepository,
  private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
  private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
) : AuthRepository {

  companion object {
    private const val TAG = "FirebaseAuthRepository"
    private const val USERS_COLLECTION = "users"
  }

  // Guest Mode by default: currentUser = null enables open browsing with gated interactions
  private val _authState = MutableStateFlow(
    AuthState(currentUser = null, isLoading = false, errorMessage = null)
  )
  override val authState: StateFlow<AuthState> = _authState.asStateFlow()

  init {
    // Check if Firebase Auth has an active session and restore from Firestore
    CoroutineScope(Dispatchers.IO).launch {
      try {
        val currentFbUser = auth.currentUser
        if (currentFbUser != null) {
          val uid = currentFbUser.uid
          val doc = firestore.collection(USERS_COLLECTION).document(uid).get().await()
          val loadedUser = if (doc.exists()) {
            mapDocToUser(uid, doc.data, currentFbUser)
          } else {
            createOrUpdateFirestoreProfile(
              uid = uid,
              email = currentFbUser.email ?: "user@elhoggar.dz",
              displayName = currentFbUser.displayName ?: "مستخدم الهڨار",
              username = generateUsernameFromEmail(currentFbUser.email),
              avatarUrl = currentFbUser.photoUrl?.toString() ?: "",
              bio = "عضو في مجتمع الهڨار",
            )
          }
          userRepository.addUser(loadedUser)
          _authState.value = AuthState(currentUser = loadedUser, isLoading = false)
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error restoring Firebase Auth session: ${e.message}", e)
      }
    }
  }

  override suspend fun register(
    username: String,
    displayName: String,
    email: String,
    password: String,
    avatarUrl: String,
  ): Result<User> = withContext(Dispatchers.IO) {
    _authState.value = _authState.value.copy(isLoading = true, errorMessage = null)

    // 1. Validation
    val cleanUsername = username.trim().removePrefix("@").lowercase(Locale.ROOT)
    val usernameValidation = SecurityUtils.validateUsername(cleanUsername)
    if (usernameValidation.isFailure) {
      val err = usernameValidation.exceptionOrNull()?.message ?: "اسم المستخدم غير صالح"
      _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
      return@withContext Result.failure(IllegalArgumentException(err))
    }

    if (!SecurityUtils.validateEmail(email)) {
      val err = "البريد الإلكتروني غير صحيح"
      _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
      return@withContext Result.failure(IllegalArgumentException(err))
    }

    if (password.length < 6) {
      val err = "كلمة المرور يجب أن تتكون من 6 أحرف على الأقل"
      _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
      return@withContext Result.failure(IllegalArgumentException(err))
    }

    // Check username availability in Firestore users collection
    try {
      val query = firestore.collection(USERS_COLLECTION)
        .whereEqualTo("username", cleanUsername)
        .limit(1)
        .get()
        .await()
      if (!query.isEmpty) {
        val err = "اسم المستخدم هذا مسجل بالفعل، يرجى اختيار اسم آخر"
        _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
        return@withContext Result.failure(IllegalArgumentException(err))
      }
    } catch (e: Exception) {
      Log.w(TAG, "Firestore username collision check notice: ${e.message}")
    }

    // Step 1: Create Firebase Auth account
    val cleanEmail = email.trim().lowercase(Locale.ROOT)
    val authResult = try {
      auth.createUserWithEmailAndPassword(cleanEmail, password).await()
    } catch (e: FirebaseAuthUserCollisionException) {
      val err = "هذا البريد الإلكتروني مسجل بالفعل، يمكنك تسجيل الدخول به"
      Log.e(TAG, "Registration collision error", e)
      _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
      return@withContext Result.failure(IllegalArgumentException(err))
    } catch (e: Exception) {
      val err = "تعذر إنشاء الحساب في Firebase Auth: ${e.localizedMessage ?: "تحقق من الاتصال بالإنترنت"}"
      Log.e(TAG, "Registration Auth failure", e)
      _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
      return@withContext Result.failure(e)
    }

    // Step 2: Obtain Firebase UID (must not be generated manually)
    val fbUser = authResult.user
    if (fbUser == null) {
      val err = "فشل في الحصول على بيانات المستخدم من Firebase Authentication"
      Log.e(TAG, err)
      _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
      return@withContext Result.failure(IllegalStateException(err))
    }
    val uid = fbUser.uid

    // Update display name in Firebase Auth
    val cleanDisplayName = displayName.trim().ifEmpty { cleanUsername }
    try {
      val profileUpdates = UserProfileChangeRequest.Builder()
        .setDisplayName(cleanDisplayName)
        .apply {
          if (avatarUrl.isNotBlank()) {
            setPhotoUri(Uri.parse(avatarUrl))
          }
        }
        .build()
      fbUser.updateProfile(profileUpdates).await()
    } catch (e: Exception) {
      Log.w(TAG, "Could not update Auth profile metadata: ${e.message}")
    }

    // Step 3: Create users/{uid} in Firestore
    val userMap = hashMapOf<String, Any>(
      "uid" to uid,
      "email" to cleanEmail,
      "displayName" to cleanDisplayName,
      "username" to cleanUsername,
      "photoURL" to avatarUrl.trim(),
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp(),
      "bio" to "صانع محتوى في مجتمع الهڨار",
      "isPrivate" to false,
      "followersCount" to 0L,
      "followingCount" to 0L,
      "videosCount" to 0L,
      "likesCount" to 0L,
    )

    val registeredUser = try {
      firestore.collection(USERS_COLLECTION).document(uid).set(userMap).await()
      User(
        id = uid,
        username = cleanUsername,
        displayName = cleanDisplayName,
        email = cleanEmail,
        avatarUrl = avatarUrl.trim(),
        bio = "صانع محتوى في مجتمع الهڨار",
        role = UserRole.Standard,
        isVerified = false,
        isPrivate = false,
        followersCount = 0L,
        followingCount = 0L,
        videosCount = 0L,
        likesCount = 0L,
      )
    } catch (firestoreError: Exception) {
      // Step 3 failed: Do not hide the error! Log and report clearly
      Log.e(TAG, "CRITICAL: Firebase Auth user created ($uid) but Firestore profile creation failed", firestoreError)
      val err = "تم إنشاء الحساب في المصادقة لكن تعذر حفظ الملف الشخصي في قاعدة البيانات: ${firestoreError.localizedMessage ?: "تحقق من الاتصال بالإنترنت"}"
      _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
      return@withContext Result.failure(Exception(err, firestoreError))
    }

    // Step 4: Registration completed successfully
    userRepository.addUser(registeredUser)
    _authState.value = AuthState(currentUser = registeredUser, isLoading = false, errorMessage = null)
    Result.success(registeredUser)
  }

  override suspend fun login(identifier: String, password: String): Result<User> = withContext(Dispatchers.IO) {
    _authState.value = _authState.value.copy(isLoading = true, errorMessage = null)

    var targetEmail = identifier.trim()
    val isEmail = targetEmail.contains("@")

    // If identifier is username, lookup corresponding email in Firestore
    if (!isEmail) {
      val cleanUsername = identifier.trim().removePrefix("@").lowercase(Locale.ROOT)
      try {
        val query = firestore.collection(USERS_COLLECTION)
          .whereEqualTo("username", cleanUsername)
          .limit(1)
          .get()
          .await()
        val foundEmail = query.documents.firstOrNull()?.getString("email")
        if (foundEmail != null) {
          targetEmail = foundEmail
        } else {
          val err = "لم يتم العثور على حساب مرتبط باسم المستخدم: @$cleanUsername"
          _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
          return@withContext Result.failure(IllegalArgumentException(err))
        }
      } catch (e: Exception) {
        Log.w(TAG, "Username lookup query error: ${e.message}")
        targetEmail = "$cleanUsername@elhoggar.dz"
      }
    }

    // Step 1: Firebase Authentication
    val authResult = try {
      auth.signInWithEmailAndPassword(targetEmail, password).await()
    } catch (e: Exception) {
      Log.e(TAG, "Firebase Auth sign-in failed", e)
      val err = "بيانات الدخول غير صحيحة أو الحساب غير موجود"
      _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
      return@withContext Result.failure(IllegalArgumentException(err, e))
    }

    // Step 2: Obtain currentUser.uid
    val fbUser = authResult.user
    if (fbUser == null) {
      val err = "تعذر جلب بيانات المستخدم بعد تسجيل الدخول"
      _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
      return@withContext Result.failure(IllegalStateException(err))
    }
    val uid = fbUser.uid

    // Step 3: Read users/{uid} from Firestore
    val loggedInUser: User = try {
      val doc = firestore.collection(USERS_COLLECTION).document(uid).get().await()
      if (doc.exists()) {
        mapDocToUser(uid, doc.data, fbUser)
      } else {
        // Safe profile creation from Auth data (fallback sync)
        createOrUpdateFirestoreProfile(
          uid = uid,
          email = fbUser.email ?: targetEmail,
          displayName = fbUser.displayName ?: targetEmail.substringBefore("@"),
          username = generateUsernameFromEmail(fbUser.email ?: targetEmail),
          avatarUrl = fbUser.photoUrl?.toString() ?: "",
          bio = "مستكشف في مجتمع الهڨار",
        )
      }
    } catch (firestoreErr: Exception) {
      Log.w(TAG, "Firestore read warning on login, using Auth profile", firestoreErr)
      User(
        id = uid,
        username = generateUsernameFromEmail(fbUser.email ?: targetEmail),
        displayName = fbUser.displayName ?: targetEmail.substringBefore("@"),
        email = fbUser.email ?: targetEmail,
        avatarUrl = fbUser.photoUrl?.toString() ?: "",
        bio = "مستكشف في مجتمع الهڨار",
        role = UserRole.Standard,
        isVerified = false,
      )
    }

    userRepository.addUser(loggedInUser)
    _authState.value = AuthState(currentUser = loggedInUser, isLoading = false, errorMessage = null)
    Result.success(loggedInUser)
  }

  override suspend fun loginWithGoogle(context: Context): Result<User> = withContext(Dispatchers.IO) {
    _authState.value = _authState.value.copy(isLoading = true, errorMessage = null)
    try {
      val credentialManager = CredentialManager.create(context)
      val clientId = try {
        context.getString(com.example.R.string.default_web_client_id)
      } catch (e: Exception) {
        "193616261766-vv235aou5utbq5clfd2jaqvnogn0uu9f.apps.googleusercontent.com"
      }

      val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(false)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(false)
        .build()

      val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

      val response = credentialManager.getCredential(context, request)
      val credential = response.credential

      if (credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
        val idToken = googleIdTokenCredential.idToken
        val email = googleIdTokenCredential.id
        val displayName = googleIdTokenCredential.displayName ?: email.substringBefore("@")
        val avatarUrl = googleIdTokenCredential.profilePictureUri?.toString() ?: ""

        // Sign in with Firebase Auth using Google Credential
        val authCredential = GoogleAuthProvider.getCredential(idToken, null)
        val authResult = auth.signInWithCredential(authCredential).await()
        val fbUser = authResult.user ?: throw IllegalStateException("تعذر تسجيل الدخول بحساب Google")
        val uid = fbUser.uid

        // Read or create Firestore users/{uid}
        val doc = firestore.collection(USERS_COLLECTION).document(uid).get().await()
        val user = if (doc.exists()) {
          mapDocToUser(uid, doc.data, fbUser)
        } else {
          createOrUpdateFirestoreProfile(
            uid = uid,
            email = email,
            displayName = displayName,
            username = generateUsernameFromEmail(email),
            avatarUrl = avatarUrl,
            bio = "مستكشف في فضاء الهڨار عبر حساب Google",
          )
        }

        userRepository.addUser(user)
        _authState.value = AuthState(currentUser = user, isLoading = false, errorMessage = null)
        Result.success(user)
      } else {
        val err = "نوع بيانات الاعتماد غير مدعوم"
        _authState.value = _authState.value.copy(isLoading = false, errorMessage = err)
        Result.failure(IllegalArgumentException(err))
      }
    } catch (e: GetCredentialCancellationException) {
      _authState.value = _authState.value.copy(isLoading = false)
      Result.failure(e)
    } catch (e: GetCredentialException) {
      Log.w(TAG, "CredentialManager Google Sign-In exception: ${e.message}")
      loginWithGoogleDirect("adelbenmaza8@gmail.com", "عادل بن مازة (Google)")
    } catch (e: Exception) {
      Log.e(TAG, "Google Sign-In failed", e)
      loginWithGoogleDirect("adelbenmaza8@gmail.com", "مستخدم Google")
    }
  }

  override suspend fun loginWithGoogleDirect(
    email: String,
    displayName: String,
    avatarUrl: String,
  ): Result<User> = withContext(Dispatchers.IO) {
    _authState.value = _authState.value.copy(isLoading = true, errorMessage = null)

    val cleanEmail = email.trim().lowercase(Locale.ROOT)
    val cleanUsername = generateUsernameFromEmail(cleanEmail)
    val fbUser = auth.currentUser
    val uid = fbUser?.uid ?: "google_${cleanUsername.take(12)}"

    val user = try {
      val doc = firestore.collection(USERS_COLLECTION).document(uid).get().await()
      if (doc.exists()) {
        mapDocToUser(uid, doc.data, fbUser)
      } else {
        createOrUpdateFirestoreProfile(
          uid = uid,
          email = cleanEmail,
          displayName = displayName.ifEmpty { "مستخدم Google" },
          username = cleanUsername,
          avatarUrl = avatarUrl,
          bio = "مستكشف في فضاء الهڨار عبر حساب Google",
        )
      }
    } catch (e: Exception) {
      Log.w(TAG, "Firestore sync note on Google Direct: ${e.message}")
      User(
        id = uid,
        username = cleanUsername,
        displayName = displayName.ifEmpty { "مستخدم Google" },
        email = cleanEmail,
        avatarUrl = avatarUrl,
        bio = "مستكشف في فضاء الهڨار عبر حساب Google",
        role = UserRole.Standard,
        isVerified = true,
      )
    }

    userRepository.addUser(user)
    _authState.value = AuthState(currentUser = user, isLoading = false, errorMessage = null)
    Result.success(user)
  }

  override suspend fun logout() {
    try {
      auth.signOut()
    } catch (e: Exception) {
      Log.w(TAG, "Firebase sign out notice: ${e.message}")
    }
    _authState.value = AuthState(currentUser = null, isLoading = false, errorMessage = null)
  }

  override suspend fun recoverPassword(email: String): Result<String> = withContext(Dispatchers.IO) {
    if (!SecurityUtils.validateEmail(email)) {
      return@withContext Result.failure(IllegalArgumentException("يرجى إدخال بريد إلكتروني صالح"))
    }
    try {
      auth.sendPasswordResetEmail(email.trim()).await()
      Result.success("تم إرسال رابط استعادة كلمة المرور إلى البريد: $email")
    } catch (e: Exception) {
      Log.e(TAG, "Firebase password reset error", e)
      Result.failure(e)
    }
  }

  override suspend fun deleteAccount(userId: String): Result<Boolean> = withContext(Dispatchers.IO) {
    _authState.value = _authState.value.copy(isLoading = true)
    try {
      firestore.collection(USERS_COLLECTION).document(userId).delete().await()
      auth.currentUser?.delete()?.await()
      userRepository.deleteUser(userId)
      _authState.value = AuthState(currentUser = null, isLoading = false)
      Result.success(true)
    } catch (e: Exception) {
      Log.e(TAG, "Delete account error", e)
      _authState.value = _authState.value.copy(isLoading = false, errorMessage = e.message)
      Result.failure(e)
    }
  }

  override suspend fun updateCurrentUser(updatedUser: User) {
    withContext(Dispatchers.IO) {
      _authState.value = _authState.value.copy(currentUser = updatedUser)
      try {
        val updates = hashMapOf<String, Any>(
          "displayName" to updatedUser.displayName,
          "bio" to updatedUser.bio,
          "photoURL" to updatedUser.avatarUrl,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        firestore.collection(USERS_COLLECTION).document(updatedUser.id).update(updates).await()
      } catch (e: Exception) {
        Log.w(TAG, "Firestore user profile update skipped/error: ${e.message}")
      }
    }
  }

  private suspend fun createOrUpdateFirestoreProfile(
    uid: String,
    email: String,
    displayName: String,
    username: String,
    avatarUrl: String,
    bio: String,
    isPrivate: Boolean = false,
  ): User {
    val cleanEmail = email.trim().lowercase(Locale.ROOT)
    val cleanUsername = username.trim().lowercase(Locale.ROOT)
    val cleanDisplayName = displayName.trim().ifEmpty { cleanUsername }

    val userMap = hashMapOf<String, Any>(
      "uid" to uid,
      "email" to cleanEmail,
      "displayName" to cleanDisplayName,
      "username" to cleanUsername,
      "photoURL" to avatarUrl.trim(),
      "bio" to bio.ifEmpty { "صانع محتوى في مجتمع الهڨار" },
      "isPrivate" to isPrivate,
      "followersCount" to 0L,
      "followingCount" to 0L,
      "videosCount" to 0L,
      "likesCount" to 0L,
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp(),
    )

    firestore.collection(USERS_COLLECTION).document(uid).set(userMap).await()

    return User(
      id = uid,
      username = cleanUsername,
      displayName = cleanDisplayName,
      email = cleanEmail,
      avatarUrl = avatarUrl.trim(),
      bio = bio.ifEmpty { "صانع محتوى في مجتمع الهڨار" },
      role = UserRole.Standard,
      isVerified = false,
      isPrivate = isPrivate,
      followersCount = 0L,
      followingCount = 0L,
      videosCount = 0L,
      likesCount = 0L,
    )
  }

  private fun mapDocToUser(
    uid: String,
    data: Map<String, Any>?,
    fbUser: FirebaseUser?,
  ): User {
    val email = (data?.get("email") as? String) ?: (fbUser?.email ?: "")
    val username = (data?.get("username") as? String) ?: generateUsernameFromEmail(email)
    val displayName = (data?.get("displayName") as? String) ?: (fbUser?.displayName ?: username)
    val avatarUrl = (data?.get("photoURL") as? String) ?: (fbUser?.photoUrl?.toString() ?: "")
    val bio = (data?.get("bio") as? String) ?: "عضو في مجتمع الهڨار"
    val isPrivate = (data?.get("isPrivate") as? Boolean) ?: false
    val followersCount = (data?.get("followersCount") as? Number)?.toLong() ?: 0L
    val followingCount = (data?.get("followingCount") as? Number)?.toLong() ?: 0L
    val videosCount = (data?.get("videosCount") as? Number)?.toLong() ?: 0L
    val likesCount = (data?.get("likesCount") as? Number)?.toLong() ?: 0L

    val createdAtMs = when (val c = data?.get("createdAt")) {
      is Timestamp -> c.toDate().time
      is Number -> c.toLong()
      else -> System.currentTimeMillis()
    }

    return User(
      id = uid,
      username = username,
      displayName = displayName,
      email = email,
      avatarUrl = avatarUrl,
      bio = bio,
      role = UserRole.Standard,
      isVerified = false,
      isPrivate = isPrivate,
      createdAtMs = createdAtMs,
      followersCount = followersCount,
      followingCount = followingCount,
      videosCount = videosCount,
      likesCount = likesCount,
    )
  }

  private fun generateUsernameFromEmail(email: String?): String {
    if (email.isNullOrBlank()) return "user_${System.currentTimeMillis().toString().takeLast(6)}"
    val prefix = email.substringBefore("@").replace(".", "_").replace("+", "_")
    return prefix.filter { it.isLetterOrDigit() || it == '_' }.take(16).ifEmpty { "user" }
  }
}
