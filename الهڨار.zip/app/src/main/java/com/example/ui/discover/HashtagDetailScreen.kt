package com.example.ui.discover

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.VideoItem
import com.example.recommendation.model.HashtagDetail
import com.example.recommendation.repository.RecommendationRepository
import com.example.ui.components.HoggarCard
import com.example.ui.components.HoggarDurationBadge
import com.example.ui.components.HoggarEmptyState
import com.example.ui.theme.HoggarColorTokens

@Composable
fun HashtagDetailScreen(
  tag: String,
  repository: RecommendationRepository,
  onBack: () -> Unit,
  onVideoClick: (VideoItem) -> Unit,
  modifier: Modifier = Modifier,
) {
  val detail by repository.getHashtagDetail(tag).collectAsState(
    initial = HashtagDetail(tag = tag, count = 0L, totalViews = 0L, description = "", videos = emptyList()),
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("hashtag_detail_screen"),
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Back",
          tint = HoggarColorTokens.TextPrimary,
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = detail.tag,
        color = HoggarColorTokens.TextPrimary,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
      )
    }

    LazyVerticalGrid(
      columns = GridCells.Fixed(3),
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(4.dp),
      horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      // Hero Header Item
      item(span = { GridItemSpan(3) }) {
        HoggarCard(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(HoggarColorTokens.SlateContainer),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.Tag,
                contentDescription = null,
                tint = HoggarColorTokens.InteractiveAmber,
                modifier = Modifier.size(32.dp),
              )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column {
              Text(
                text = detail.tag,
                color = HoggarColorTokens.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "${formatNumber(detail.count)} فيديوهات  •  ${formatNumber(detail.totalViews)} مشاهدة",
                color = HoggarColorTokens.InteractiveAmber,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
              )
            }
          }

          if (detail.description.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = detail.description,
              color = HoggarColorTokens.TextSecondary,
              fontSize = 12.sp,
              lineHeight = 18.sp,
            )
          }
        }
      }

      if (detail.videos.isEmpty()) {
        item(span = { GridItemSpan(3) }) {
          HoggarEmptyState(
            title = "لا توجد فيديوهات بهذا الوسم",
            description = "كن أول من ينشر فيديو يحمل هذا الوسم في منصة الهڨار.",
          )
        }
      } else {
        items(detail.videos, key = { it.id }) { video ->
          HashtagVideoThumbnail(
            video = video,
            onClick = { onVideoClick(video) },
          )
        }
      }
    }
  }
}

@Composable
private fun HashtagVideoThumbnail(
  video: VideoItem,
  onClick: () -> Unit,
) {
  Box(
    modifier = Modifier
      .aspectRatio(9f / 14f)
      .clip(RoundedCornerShape(4.dp))
      .background(HoggarColorTokens.BasaltSurface)
      .clickable(onClick = onClick),
  ) {
    AsyncImage(
      model = video.thumbnailUrl,
      contentDescription = video.title,
      modifier = Modifier.fillMaxSize(),
    )

    // Gradient Scrim
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(44.dp)
        .align(Alignment.BottomCenter)
        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))),
    )

    HoggarDurationBadge(
      durationText = "${video.durationSeconds}s",
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(4.dp),
    )

    // Views Count
    Row(
      modifier = Modifier
        .align(Alignment.BottomStart)
        .padding(6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Filled.PlayArrow,
        contentDescription = null,
        tint = HoggarColorTokens.TextPrimary,
        modifier = Modifier.size(13.dp),
      )
      Spacer(modifier = Modifier.width(3.dp))
      Text(
        text = formatNumber(video.stats.viewsCount),
        color = HoggarColorTokens.TextPrimary,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
      )
    }
  }
}

private fun formatNumber(count: Long): String {
  return when {
    count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
    count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
    else -> count.toString()
  }
}
