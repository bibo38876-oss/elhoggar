package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.auth.FirebaseAuthRepository
import com.example.data.repository.InMemorySoundRepository
import com.example.data.repository.InMemoryPostRepository
import com.example.data.repository.MockVideoRepository
import com.example.follow.InMemoryFollowRepository
import com.example.interaction.model.NotificationType
import com.example.interaction.repository.InMemoryCommentRepository
import com.example.interaction.repository.InMemoryInteractionRepository
import com.example.interaction.repository.InMemoryNotificationRepository
import com.example.interaction.repository.InMemoryReportRepository
import com.example.model.CreatorModel
import com.example.model.NavigationTab
import com.example.player.VideoPlayerManager
import com.example.recommendation.repository.InMemoryRecommendationRepository
import com.example.security.repository.InMemoryAdminRepository
import com.example.security.service.SecurityManager
import com.example.ui.admin.AdminDashboardScreen
import com.example.ui.auth.AuthBottomSheet
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.AuthViewModel
import com.example.ui.create.CreateStudioScreen
import com.example.ui.create.VideoCreateViewModel
import com.example.ui.creator.CreatorStudioDashboardScreen
import com.example.ui.discover.DiscoverSearchScreen
import com.example.ui.discover.HashtagDetailScreen
import com.example.ui.discover.SoundDetailScreen
import com.example.ui.feed.FeedViewModel
import com.example.ui.feed.VerticalVideoFeed
import com.example.ui.navigation.HoggarBottomBar
import com.example.ui.posts.CreatePostScreen
import com.example.ui.posts.PostsFeedScreen
import com.example.ui.profile.EditProfileScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.profile.ProfileViewModel
import com.example.ui.screens.ActivityScreen
import com.example.ui.screens.DesignSystemShowcaseScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.HoggarColorTokens
import com.example.user.MockUserRepository
import com.example.user.UserProfile
import kotlinx.coroutines.launch

sealed interface MainDestination {
  data object Feed : MainDestination
  data object Discover : MainDestination
  data class Hashtag(val tag: String) : MainDestination
  data class Sound(val soundTitle: String, val soundAuthor: String) : MainDestination
  data class Create(val initialSoundTitle: String? = null, val initialSoundAuthor: String? = null) : MainDestination
  data object Activity : MainDestination
  data class Profile(val targetUserId: String? = null) : MainDestination
  data class EditProfile(val profile: UserProfile) : MainDestination
  data object Auth : MainDestination
  data object Settings : MainDestination
  data object DesignShowcase : MainDestination
  data object AdminDashboard : MainDestination
  data object CreatorStudio : MainDestination
  data object Posts : MainDestination
  data object CreatePost : MainDestination
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContainer(
  initialGoToAuth: Boolean = false,
  onReplaySplash: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  // 1. Shared Decoupled Repositories & Services
  val soundRepository = remember { InMemorySoundRepository() }
  val videoRepository = remember { MockVideoRepository() }
  val postRepository = remember { InMemoryPostRepository() }
  val followRepository = remember { InMemoryFollowRepository() }
  val userRepository = remember { MockUserRepository(followRepository, videoRepository) }
  val authRepository = remember { FirebaseAuthRepository(userRepository) }

  val notificationRepository = remember { InMemoryNotificationRepository() }
  val reportRepository = remember { InMemoryReportRepository() }
  val interactionRepository = remember { InMemoryInteractionRepository() }
  val recommendationRepository = remember { InMemoryRecommendationRepository(videoRepository, followRepository) }
  val securityManager = remember { SecurityManager() }
  val adminRepository = remember { InMemoryAdminRepository(videoRepository, securityManager) }
  val commentRepository = remember {
    InMemoryCommentRepository { recipientId, actor, text, isReply ->
      notificationRepository.dispatchNotification(
        recipientUserId = recipientId,
        actor = actor,
        type = if (isReply) NotificationType.Reply else NotificationType.Comment,
        previewText = text,
      )
    }
  }

  // 2. ViewModels
  val playerManager = remember { VideoPlayerManager(context.applicationContext) }
  val feedViewModel = remember { FeedViewModel(recommendationRepository = recommendationRepository, playerManager = playerManager) }
  val authViewModel = remember { AuthViewModel(authRepository) }
  val profileViewModel = remember { ProfileViewModel(userRepository, followRepository, authRepository) }
  val videoCreateViewModel = remember { VideoCreateViewModel(videoRepository, authRepository, soundRepository) }

  val authState by authViewModel.authState.collectAsState()
  val isGuest = !authState.isAuthenticated

  var showAuthBottomSheet by remember { mutableStateOf(false) }
  var authReasonMessage by remember { mutableStateOf("سجل دخولك للتفاعل مع المحتوى") }
  var pendingAuthAction by remember { mutableStateOf<(() -> Unit)?>(null) }

  val triggerAuthGate: (reason: String, pendingAction: (() -> Unit)?) -> Unit = { reason, action ->
    authReasonMessage = reason
    pendingAuthAction = action
    showAuthBottomSheet = true
  }

  var currentDestination by remember {
    mutableStateOf<MainDestination>(if (initialGoToAuth) MainDestination.Auth else MainDestination.Feed)
  }

  // Lifecycle Handling: Guarantee video playback pauses in background and resumes on return
  val lifecycleOwner = LocalLifecycleOwner.current
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> {
          playerManager.pauseActiveVideo()
        }
        Lifecycle.Event.ON_RESUME -> {
          if (currentDestination == MainDestination.Feed) {
            playerManager.resumeActiveVideo()
          }
        }
        Lifecycle.Event.ON_DESTROY -> {
          playerManager.releaseAll()
        }
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
      playerManager.releaseAll()
    }
  }

  // Handle system back navigation cleanly
  BackHandler(enabled = currentDestination != MainDestination.Feed) {
    when (currentDestination) {
      is MainDestination.Hashtag -> {
        currentDestination = MainDestination.Discover
      }
      is MainDestination.AdminDashboard -> {
        currentDestination = MainDestination.Profile(null)
      }
      is MainDestination.EditProfile -> {
        currentDestination = MainDestination.Profile(null)
      }
      is MainDestination.Settings -> {
        currentDestination = MainDestination.Profile(null)
      }
      is MainDestination.Auth -> {
        currentDestination = MainDestination.Feed
        playerManager.resumeActiveVideo()
      }
      else -> {
        currentDestination = MainDestination.Feed
        playerManager.resumeActiveVideo()
      }
    }
  }

  Scaffold(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase),
      containerColor = HoggarColorTokens.ObsidianBase,
      bottomBar = {
        // Show bottom navigation on primary tabs
        val showBottomNav = currentDestination is MainDestination.Feed ||
            currentDestination is MainDestination.Posts ||
            currentDestination is MainDestination.Activity ||
            (currentDestination is MainDestination.Profile && (currentDestination as MainDestination.Profile).targetUserId == null)

        if (showBottomNav) {
          val activeTab = when (currentDestination) {
            MainDestination.Feed -> NavigationTab.Home
            MainDestination.Posts -> NavigationTab.Posts
            MainDestination.Discover, is MainDestination.Hashtag -> NavigationTab.Posts
            MainDestination.Activity -> NavigationTab.Activity
            is MainDestination.Profile -> NavigationTab.Profile
            else -> NavigationTab.Home
          }

          HoggarBottomBar(
            currentTab = activeTab,
            onTabSelected = { tab ->
              when (tab) {
                NavigationTab.Home -> {
                  currentDestination = MainDestination.Feed
                  playerManager.resumeActiveVideo()
                }
                NavigationTab.Posts -> {
                  currentDestination = MainDestination.Posts
                  playerManager.pauseActiveVideo()
                }
                NavigationTab.Discover -> {
                  currentDestination = MainDestination.Discover
                  playerManager.pauseActiveVideo()
                }
                NavigationTab.Create -> {
                  if (isGuest) {
                    triggerAuthGate("سجل دخولك لتصوير الفيديوهات أو كتابة المنشورات في استوديو الهڨار", null)
                  } else {
                    currentDestination = MainDestination.Create()
                    playerManager.pauseActiveVideo()
                  }
                }
                NavigationTab.Activity -> {
                  currentDestination = MainDestination.Activity
                  playerManager.pauseActiveVideo()
                }
                NavigationTab.Profile -> {
                  currentDestination = MainDestination.Profile(null)
                  playerManager.pauseActiveVideo()
                }
              }
            },
          )
        }
      },
    ) { innerPadding ->
      val showBottomNav = currentDestination is MainDestination.Feed ||
          currentDestination is MainDestination.Posts ||
          currentDestination is MainDestination.Activity ||
          (currentDestination is MainDestination.Profile && (currentDestination as MainDestination.Profile).targetUserId == null)

      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(
            bottom = if (showBottomNav) innerPadding.calculateBottomPadding() else 0.dp,
          ),
      ) {
        Crossfade(
          targetState = currentDestination,
          animationSpec = tween(250),
          label = "destination_crossfade",
        ) { destination ->
          when (destination) {
            is MainDestination.Feed -> {
              val currentCreator = CreatorModel(
                id = authState.currentUser?.id ?: "user_me",
                username = authState.currentUser?.username ?: "creator_hoggar",
                displayName = authState.currentUser?.displayName ?: "مبدع الهڨار",
                avatarUrl = authState.currentUser?.avatarUrl ?: "",
                isVerified = authState.currentUser?.isVerified ?: false,
              )
              VerticalVideoFeed(
                viewModel = feedViewModel,
                commentRepository = commentRepository,
                reportRepository = reportRepository,
                interactionRepository = interactionRepository,
                notificationRepository = notificationRepository,
                currentUser = currentCreator,
                isGuest = isGuest,
                onRequestAuth = triggerAuthGate,
                onSearchClick = {
                  currentDestination = MainDestination.Discover
                  playerManager.pauseActiveVideo()
                },
                onCreatorClick = { creatorId ->
                  currentDestination = MainDestination.Profile(creatorId)
                  playerManager.pauseActiveVideo()
                },
                onHashtagClick = { tag ->
                  currentDestination = MainDestination.Hashtag(tag)
                  playerManager.pauseActiveVideo()
                },
                onSoundClick = { soundTitle, soundAuthor ->
                  currentDestination = MainDestination.Sound(soundTitle, soundAuthor)
                  playerManager.pauseActiveVideo()
                },
              )
            }

            is MainDestination.Discover -> {
              DiscoverSearchScreen(
                repository = recommendationRepository,
                onOpenCreatorProfile = { creatorId ->
                  currentDestination = MainDestination.Profile(creatorId)
                  playerManager.pauseActiveVideo()
                },
                onOpenHashtag = { tag ->
                  currentDestination = MainDestination.Hashtag(tag)
                  playerManager.pauseActiveVideo()
                },
                onOpenVideo = { video ->
                  currentDestination = MainDestination.Feed
                  playerManager.playVideo(video.id, video.videoUrl)
                },
              )
            }

            is MainDestination.Hashtag -> {
              HashtagDetailScreen(
                tag = destination.tag,
                repository = recommendationRepository,
                onBack = {
                  currentDestination = MainDestination.Discover
                },
                onVideoClick = { video ->
                  currentDestination = MainDestination.Feed
                  playerManager.playVideo(video.id, video.videoUrl)
                },
              )
            }

            is MainDestination.Sound -> {
              SoundDetailScreen(
                soundTitle = destination.soundTitle,
                soundAuthor = destination.soundAuthor,
                repository = recommendationRepository,
                onBack = {
                  currentDestination = MainDestination.Feed
                  playerManager.resumeActiveVideo()
                },
                onVideoClick = { video ->
                  currentDestination = MainDestination.Feed
                  playerManager.playVideo(video.id, video.videoUrl)
                },
                onUseSound = {
                  videoCreateViewModel.selectSoundByTitle(destination.soundTitle, destination.soundAuthor)
                  currentDestination = MainDestination.Create(destination.soundTitle, destination.soundAuthor)
                  playerManager.pauseActiveVideo()
                },
              )
            }

            is MainDestination.Create -> {
              CreateStudioScreen(
                viewModel = videoCreateViewModel,
                soundRepository = soundRepository,
                onClose = {
                  currentDestination = MainDestination.Feed
                  playerManager.resumeActiveVideo()
                },
                onOpenCreatePost = {
                  currentDestination = MainDestination.CreatePost
                  playerManager.pauseActiveVideo()
                },
                onViewPublished = { videoId ->
                  feedViewModel.loadFeed()
                  profileViewModel.loadProfile(null)
                  currentDestination = MainDestination.Profile(null)
                },
              )
            }

            is MainDestination.Posts -> {
              val currentUserId = authState.currentUser?.id ?: "user_me"
              PostsFeedScreen(
                postRepository = postRepository,
                currentUserId = currentUserId,
                isGuest = isGuest,
                onOpenCreatePost = {
                  currentDestination = MainDestination.CreatePost
                  playerManager.pauseActiveVideo()
                },
                onOpenCreatorProfile = { profileId ->
                  currentDestination = MainDestination.Profile(profileId)
                  playerManager.pauseActiveVideo()
                },
                onOpenHashtag = { tag ->
                  currentDestination = MainDestination.Hashtag(tag)
                  playerManager.pauseActiveVideo()
                },
                onOpenSearch = {
                  currentDestination = MainDestination.Discover
                  playerManager.pauseActiveVideo()
                },
                onRequestAuth = {
                  triggerAuthGate("سجل دخولك لكتابة المنشورات والتفاعل معها في الهڨار", null)
                },
              )
            }

            is MainDestination.CreatePost -> {
              val currentUser = authState.currentUser?.let { user ->
                CreatorModel(
                  id = user.id,
                  username = user.username,
                  displayName = user.displayName,
                  avatarUrl = user.avatarUrl,
                  isVerified = user.isVerified,
                  bio = user.bio,
                )
              } ?: CreatorModel(
                id = "user_me",
                username = "me",
                displayName = "أنا",
                avatarUrl = "https://picsum.photos/seed/user_avatar/200/200",
                isVerified = false,
                bio = "عضو في مجتمع الهڨار",
              )

              CreatePostScreen(
                currentUser = currentUser,
                postRepository = postRepository,
                onBack = {
                  currentDestination = MainDestination.Posts
                  playerManager.resumeActiveVideo()
                },
                onPostCreated = {
                  currentDestination = MainDestination.Posts
                  playerManager.resumeActiveVideo()
                },
              )
            }

            is MainDestination.Activity -> {
              ActivityScreen(
                userId = authState.currentUser?.id ?: "user_me",
                repository = notificationRepository,
                isGuest = isGuest,
                onRequestAuth = {
                  triggerAuthGate("سجل دخولك لمتابعة إشعاراتك وتفاعلات حسابك", null)
                },
                onOpenVideo = { videoId ->
                  currentDestination = MainDestination.Feed
                  playerManager.resumeActiveVideo()
                },
                onOpenProfile = { profileId ->
                  currentDestination = MainDestination.Profile(profileId)
                  playerManager.pauseActiveVideo()
                },
              )
            }

            is MainDestination.Profile -> {
              ProfileScreen(
                targetUserId = destination.targetUserId,
                viewModel = profileViewModel,
                onBack = if (destination.targetUserId != null) {
                  {
                    currentDestination = MainDestination.Feed
                    playerManager.resumeActiveVideo()
                  }
                } else null,
                onRequestAuth = {
                  triggerAuthGate("سجل دخولك إلى الهڨار لإنشاء وإدارة ملفك الشخصي", null)
                },
                onEditProfile = { profile ->
                  currentDestination = MainDestination.EditProfile(profile)
                },
                onOpenDesignSystem = {
                  currentDestination = MainDestination.DesignShowcase
                },
                onLogout = {
                  authViewModel.logout()
                  profileViewModel.loadProfile(null)
                },
                onDeleteAccount = { userId ->
                  authViewModel.deleteAccount(userId)
                  profileViewModel.loadProfile(null)
                  currentDestination = MainDestination.Feed
                  playerManager.resumeActiveVideo()
                },
                onVideoClick = { video ->
                  currentDestination = MainDestination.Feed
                  playerManager.playVideo(video.id, video.videoUrl)
                },
                onDeleteVideo = { videoId ->
                  scope.launch {
                    val currentUserId = authState.currentUser?.id ?: "user_me"
                    videoRepository.deleteVideo(videoId, currentUserId)
                    profileViewModel.loadProfile(destination.targetUserId)
                    feedViewModel.loadFeed()
                  }
                },
                onOpenCreatorStudio = {
                  currentDestination = MainDestination.CreatorStudio
                  playerManager.pauseActiveVideo()
                },
                onOpenAdmin = {
                  currentDestination = MainDestination.AdminDashboard
                  playerManager.pauseActiveVideo()
                },
                onOpenSettings = {
                  currentDestination = MainDestination.Settings
                  playerManager.pauseActiveVideo()
                },
              )
            }

            is MainDestination.CreatorStudio -> {
              val currentUserId = authState.currentUser?.id ?: "user_me"
              CreatorStudioDashboardScreen(
                currentUserId = currentUserId,
                videoRepository = videoRepository,
                soundRepository = soundRepository,
                onBack = {
                  currentDestination = MainDestination.Profile(null)
                  playerManager.resumeActiveVideo()
                },
                onOpenCreate = {
                  currentDestination = MainDestination.Create()
                  playerManager.pauseActiveVideo()
                },
                onOpenVideo = { video ->
                  currentDestination = MainDestination.Feed
                  playerManager.playVideo(video.id, video.videoUrl)
                },
                onUseSound = { sound ->
                  currentDestination = MainDestination.Create(
                    initialSoundTitle = sound.title,
                    initialSoundAuthor = sound.authorName,
                  )
                  playerManager.pauseActiveVideo()
                },
              )
            }

            is MainDestination.Settings -> {
              SettingsScreen(
                currentUserProfile = authState.currentUser?.let { user ->
                  UserProfile(
                    id = user.id,
                    username = user.username,
                    displayName = user.displayName,
                    bio = user.bio,
                    avatarUrl = user.avatarUrl,
                    isVerified = user.isVerified,
                    role = user.role,
                    isCurrentUser = true,
                  )
                },
                authRepository = authRepository,
                onBack = { currentDestination = MainDestination.Profile(null) },
                onEditProfile = { profile -> currentDestination = MainDestination.EditProfile(profile) },
                onLogout = {
                  authViewModel.logout()
                  currentDestination = MainDestination.Feed
                },
                onDeleteAccountConfirmed = { userId ->
                  authViewModel.deleteAccount(userId)
                  currentDestination = MainDestination.Feed
                  playerManager.resumeActiveVideo()
                },
                onOpenDesignSystem = {
                  currentDestination = MainDestination.DesignShowcase
                  playerManager.pauseActiveVideo()
                },
                onOpenAdmin = {
                  currentDestination = MainDestination.AdminDashboard
                  playerManager.pauseActiveVideo()
                },
              )
            }

            is MainDestination.AdminDashboard -> {
              AdminDashboardScreen(
                adminRepository = adminRepository,
                onExitAdmin = {
                  currentDestination = MainDestination.Profile(null)
                  playerManager.resumeActiveVideo()
                },
              )
            }

            is MainDestination.EditProfile -> {
              EditProfileScreen(
                profile = destination.profile,
                onSave = { displayName, bio, avatarUrl ->
                  scope.launch {
                    profileViewModel.updateProfile(displayName, bio, avatarUrl)
                    currentDestination = MainDestination.Profile(null)
                  }
                },
                onBack = {
                  currentDestination = MainDestination.Profile(null)
                },
              )
            }

            is MainDestination.Auth -> {
              AuthScreen(
                viewModel = authViewModel,
                onDismiss = {
                  currentDestination = MainDestination.Feed
                  playerManager.resumeActiveVideo()
                },
                onAuthSuccess = {
                  currentDestination = MainDestination.Profile(null)
                },
              )
            }

            is MainDestination.DesignShowcase -> {
              DesignSystemShowcaseScreen(
                onReplaySplash = onReplaySplash,
              )
            }
          }
        }
      }
    }

  if (showAuthBottomSheet) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    AuthBottomSheet(
      sheetState = sheetState,
      viewModel = authViewModel,
      reasonMessage = authReasonMessage,
      onDismiss = {
        showAuthBottomSheet = false
        pendingAuthAction = null
      },
      onAuthSuccess = {
        showAuthBottomSheet = false
        val action = pendingAuthAction
        pendingAuthAction = null
        action?.invoke()
        profileViewModel.loadProfile(null)
      },
    )
  }
}
