package com.example.ui.profile

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HoggarColorTokens

@Composable
fun DeleteAccountDialog(
  onConfirmDelete: () -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = HoggarColorTokens.BasaltSurface,
    title = {
      Text(
        text = "حذف الحساب بشكل نهائي؟",
        color = HoggarColorTokens.ErrorCoral,
        fontSize = 17.sp,
        fontWeight = FontWeight.Bold,
      )
    },
    text = {
      Column {
        Text(
          text = "تحذير: سيؤدي حذف الحساب إلى إزالة جميع فيديوهاتك وبياناتك ومتابعيك بشكل دائم. لا يمكن التراجع عن هذا الإجراء مطلقًا.",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 13.sp,
          lineHeight = 18.sp,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = "هل أنت متأكد من رغبتك في حذف الحساب نهائيًا من منصة الهڨار؟",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
        )
      }
    },
    confirmButton = {
      TextButton(
        onClick = onConfirmDelete,
        modifier = Modifier.testTag("btn_confirm_delete_account"),
      ) {
        Text(
          text = "نعم، حذف الحساب نهائيًا",
          color = HoggarColorTokens.ErrorCoral,
          fontWeight = FontWeight.Bold,
        )
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(
          text = "إلغاء والتراجع",
          color = HoggarColorTokens.TextPrimary,
        )
      }
    },
  )
}
