package com.example.ui.create

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.auth.AuthRepository
import com.example.data.repository.SoundRepository
import com.example.data.repository.VideoRepository
import com.example.data.repository.VideoUploadProgress
import com.example.model.CreatorModel
import com.example.model.SoundItem
import com.example.model.VideoItem
import com.example.model.VideoModerationStatus
import com.example.model.VideoProcessingStatus
import com.example.model.VideoStats
import com.example.model.VideoVisibility
import com.example.security.service.SecurityManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class CreationStage {
  CaptureOrPick,
  TrimAndEdit,
  MetadataAndPreview,
  Uploading,
}

data class VideoCreationState(
  val stage: CreationStage = CreationStage.CaptureOrPick,
  val rawVideoUri: String = "",
  val videoDurationSeconds: Int = 45,
  val trimStartSeconds: Int = 0,
  val trimEndSeconds: Int = 45,
  val isAudioMuted: Boolean = false,
  val selectedThumbnailUrl: String = "https://picsum.photos/seed/hoggar_new/720/1280",
  val description: String = "",
  val hashtags: List<String> = listOf("#الهڨار"),
  val visibility: VideoVisibility = VideoVisibility.Public,
  val selectedSound: SoundItem? = null,
  val originalAudioVolume: Float = 1.0f,
  val addedSoundVolume: Float = 1.0f,
  val uploadProgress: VideoUploadProgress? = null,
  val publishedVideo: VideoItem? = null,
  val errorMessage: String? = null,
)

class VideoCreateViewModel(
  private val videoRepository: VideoRepository,
  private val authRepository: AuthRepository,
  private val soundRepository: SoundRepository? = null,
  private val securityManager: SecurityManager = SecurityManager(),
) : ViewModel() {

  private val _state = MutableStateFlow(VideoCreationState())
  val state: StateFlow<VideoCreationState> = _state.asStateFlow()

  fun selectSound(sound: SoundItem?) {
    _state.value = _state.value.copy(
      selectedSound = sound,
    )
  }

  fun selectSoundByTitle(title: String, author: String = "") {
    val found = soundRepository?.findSoundByTitle(title)
    if (found != null) {
      _state.value = _state.value.copy(selectedSound = found)
    } else {
      _state.value = _state.value.copy(
        selectedSound = SoundItem(
          id = "snd_custom_${System.currentTimeMillis()}",
          title = title,
          authorName = author.ifEmpty { "صوت الهڨار" },
          durationSeconds = 60,
        ),
      )
    }
  }

  fun updateAudioVolumes(originalVolume: Float, addedVolume: Float) {
    _state.value = _state.value.copy(
      originalAudioVolume = originalVolume.coerceIn(0f, 1f),
      addedSoundVolume = addedVolume.coerceIn(0f, 1f),
    )
  }

  fun onVideoSelected(uri: String, durationSecs: Int = 45) {
    val initialEnd = durationSecs.coerceAtMost(60)
    _state.value = _state.value.copy(
      rawVideoUri = uri,
      videoDurationSeconds = durationSecs,
      trimStartSeconds = 0,
      trimEndSeconds = initialEnd,
      stage = CreationStage.TrimAndEdit,
      errorMessage = null,
    )
  }

  fun updateTrim(start: Int, end: Int) {
    val safeStart = start.coerceAtLeast(0)
    // Enforce 60s max duration limit
    val safeEnd = end.coerceAtMost(safeStart + 60).coerceAtMost(_state.value.videoDurationSeconds)
    _state.value = _state.value.copy(
      trimStartSeconds = safeStart,
      trimEndSeconds = safeEnd,
    )
  }

  fun toggleAudioMute() {
    _state.value = _state.value.copy(isAudioMuted = !_state.value.isAudioMuted)
  }

  fun selectThumbnail(url: String) {
    _state.value = _state.value.copy(selectedThumbnailUrl = url)
  }

  fun updateMetadata(description: String, tags: List<String>, visibility: VideoVisibility) {
    _state.value = _state.value.copy(
      description = description,
      hashtags = tags,
      visibility = visibility,
    )
  }

  fun proceedToMetadata() {
    val duration = _state.value.trimEndSeconds - _state.value.trimStartSeconds
    if (duration > 60) {
      _state.value = _state.value.copy(errorMessage = "مدة الفيديو يجب ألا تتجاوز 60 ثانية")
      return
    }
    _state.value = _state.value.copy(
      stage = CreationStage.MetadataAndPreview,
      errorMessage = null,
    )
  }

  fun backToTrimmer() {
    _state.value = _state.value.copy(stage = CreationStage.TrimAndEdit)
  }

  fun publishVideo() {
    val current = _state.value
    val currentUser = authRepository.authState.value.currentUser ?: return
    val duration = (current.trimEndSeconds - current.trimStartSeconds).coerceAtMost(60)

    // 1. File Upload Security Validation (Real MIME type, size, duration)
    val validation = securityManager.validateUploadFile(
      fileName = current.rawVideoUri.ifEmpty { "hoggar_video.mp4" },
      mimeType = "video/mp4",
      fileSizeBytes = 25 * 1024 * 1024L,
      durationSeconds = duration,
    )
    if (!validation.isValid) {
      _state.value = _state.value.copy(errorMessage = validation.errorMessage)
      return
    }

    // 2. Anti-Spam Rate Limit check for video uploads
    val rateCheck = securityManager.checkRateLimit("upload", currentUser.id)
    if (!rateCheck.isAllowed) {
      _state.value = _state.value.copy(errorMessage = rateCheck.message)
      return
    }

    val creator = CreatorModel(
      id = currentUser.id,
      username = currentUser.username,
      displayName = currentUser.displayName,
      avatarUrl = currentUser.avatarUrl,
      isVerified = currentUser.isVerified,
    )

    val soundTitle = when {
      current.isAudioMuted -> "صوت مكتوم"
      current.selectedSound != null -> current.selectedSound.title
      else -> "الصوت الأصلي - @${currentUser.username}"
    }

    val soundAuthor = when {
      current.selectedSound != null -> current.selectedSound.authorName
      else -> currentUser.displayName
    }

    current.selectedSound?.let { sound ->
      soundRepository?.incrementUsage(sound.id)
    }

    val videoItem = VideoItem(
      id = validation.secureStorageId,
      videoUrl = current.rawVideoUri.ifEmpty { "asset:///videos/hoggar_1.mp4" },
      thumbnailUrl = current.selectedThumbnailUrl,
      title = current.description.take(40).ifEmpty { "فيديو جديد في الهڨار" },
      description = current.description.ifEmpty { "فيديو جديد على منصة الهڨار #الهڨار" },
      tags = current.hashtags,
      durationSeconds = duration,
      creator = creator,
      ownerId = currentUser.id,
      stats = VideoStats(likesCount = 1L, viewsCount = 1L),
      soundTitle = soundTitle,
      soundAuthor = soundAuthor,
      visibility = current.visibility,
      processingStatus = VideoProcessingStatus.Uploading,
      moderationStatus = VideoModerationStatus.Approved,
      isAudioMuted = current.isAudioMuted,
      trimStartSeconds = current.trimStartSeconds,
      trimEndSeconds = current.trimEndSeconds,
    )

    _state.value = _state.value.copy(stage = CreationStage.Uploading)

    viewModelScope.launch {
      videoRepository.publishVideo(videoItem).collect { progress ->
        val pubVideo = progress.video
        if (progress.status == VideoProcessingStatus.Published && pubVideo != null) {
          // Automatic Audio Extraction: Extract and register this video's audio into the Hoggar Sound Vault
          if (!current.isAudioMuted) {
            soundRepository?.extractAndRegisterSoundFromVideo(pubVideo)
          }
        }
        _state.value = _state.value.copy(
          uploadProgress = progress,
          publishedVideo = pubVideo,
          errorMessage = progress.errorMessage,
        )
      }
    }
  }

  fun reset() {
    _state.value = VideoCreationState()
  }
}
