package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HoggarColorTokens

@Composable
fun HoggarBadge(
  text: String,
  modifier: Modifier = Modifier,
  backgroundColor: Color = HoggarColorTokens.SlateContainer,
  textColor: Color = HoggarColorTokens.TextPrimary,
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(backgroundColor)
      .padding(horizontal = 8.dp, vertical = 4.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = text,
      color = textColor,
      fontSize = 11.sp,
      fontWeight = FontWeight.SemiBold,
    )
  }
}

@Composable
fun HoggarTag(
  text: String,
  modifier: Modifier = Modifier,
  isInteractive: Boolean = false,
) {
  val bgColor = if (isInteractive) HoggarColorTokens.SlateHover else HoggarColorTokens.SlateContainer
  val textColor = if (isInteractive) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextPrimary

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(bgColor)
      .padding(horizontal = 8.dp, vertical = 4.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = text,
      color = textColor,
      fontSize = 12.sp,
      fontWeight = FontWeight.Medium,
    )
  }
}

@Composable
fun HoggarVerifiedBadge(
  modifier: Modifier = Modifier,
  size: Dp = 16.dp,
  badgeColor: Color = HoggarColorTokens.InteractiveAmber,
) {
  Box(
    modifier = modifier.size(size),
    contentAlignment = Alignment.Center,
  ) {
    // Crisp white background disc behind the cutout checkmark so it is brilliantly visible on dark backgrounds
    Box(
      modifier = Modifier
        .size(size * 0.55f)
        .background(Color.White, CircleShape),
    )
    // Official scalloped verified rosette
    Icon(
      imageVector = Icons.Filled.Verified,
      contentDescription = "حساب موثق",
      tint = badgeColor,
      modifier = Modifier.size(size),
    )
  }
}

@Composable
fun HoggarDurationBadge(
  durationText: String = "60s",
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(4.dp))
      .background(Color(0x80000000))
      .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(4.dp))
      .padding(horizontal = 6.dp, vertical = 2.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = durationText,
      color = HoggarColorTokens.TextPrimary,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
    )
  }
}
