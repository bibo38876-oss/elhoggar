package com.example.ui.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarLogoMark
import com.example.ui.theme.HoggarColorTokens

@Composable
fun GoogleBrandIcon(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier.size(20.dp)) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val radius = size.minDimension / 2f * 0.85f

    // Iconic Google colored segments: Blue, Red, Yellow, Green
    drawArc(
      color = Color(0xFF4285F4), // Blue
      startAngle = -45f,
      sweepAngle = 90f,
      useCenter = false,
      style = Stroke(width = radius * 0.38f),
    )
    drawArc(
      color = Color(0xFFEA4335), // Red
      startAngle = 135f,
      sweepAngle = 135f,
      useCenter = false,
      style = Stroke(width = radius * 0.38f),
    )
    drawArc(
      color = Color(0xFFFBBC05), // Yellow
      startAngle = 90f,
      sweepAngle = 45f,
      useCenter = false,
      style = Stroke(width = radius * 0.38f),
    )
    drawArc(
      color = Color(0xFF34A853), // Green
      startAngle = 45f,
      sweepAngle = 45f,
      useCenter = false,
      style = Stroke(width = radius * 0.38f),
    )

    // Center crossbar
    drawLine(
      color = Color(0xFF4285F4),
      start = center,
      end = Offset(center.x + radius * 0.95f, center.y),
      strokeWidth = radius * 0.38f,
    )
  }
}

/**
 * Universal Gated Authentication BottomSheet.
 * Displayed whenever a guest attempts an action requiring an authenticated user account
 * (e.g. Like, Comment, Follow, Create Video, Bookmark, or Access Account Features).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthBottomSheet(
  sheetState: SheetState,
  viewModel: AuthViewModel,
  reasonMessage: String = "سجل دخولك للتفاعل مع المحتوى",
  onDismiss: () -> Unit,
  onAuthSuccess: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val authState by viewModel.authState.collectAsState()

  var selectedTab by remember { mutableIntStateOf(0) } // 0: Login, 1: Register
  var emailInput by remember { mutableStateOf("") }
  var passwordInput by remember { mutableStateOf("") }
  var usernameInput by remember { mutableStateOf("") }
  var displayNameInput by remember { mutableStateOf("") }
  var isPasswordVisible by remember { mutableStateOf(false) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = HoggarColorTokens.BasaltSurface,
    scrimColor = Color(0xBB000000),
    dragHandle = {
      Box(
        modifier = Modifier
          .padding(top = 10.dp, bottom = 6.dp)
          .size(width = 44.dp, height = 4.dp)
          .clip(RoundedCornerShape(2.dp))
          .background(HoggarColorTokens.TextTertiary),
      )
    },
    modifier = modifier.testTag("auth_bottom_sheet"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 22.dp, vertical = 12.dp)
        .padding(bottom = 36.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      // Header with close button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          HoggarLogoMark(size = 32.dp, showGlow = false)
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "مجتمع الهڨار",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
          )
        }

        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Close",
            tint = HoggarColorTokens.TextSecondary,
            modifier = Modifier.size(20.dp),
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Reason Banner
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(HoggarColorTokens.SlateContainer)
          .border(1.dp, HoggarColorTokens.InteractiveAmber.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
          .padding(horizontal = 14.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = reasonMessage,
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "يمكنك تصفح جميع الفيديوهات كزائر، لكن التفاعل يتطلب حساباً لحفظ نشاطك.",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            lineHeight = 16.sp,
          )
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Error Banner if present
      AnimatedVisibility(visible = authState.errorMessage != null) {
        authState.errorMessage?.let { err ->
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 14.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(HoggarColorTokens.ErrorCoral.copy(alpha = 0.15f))
              .border(1.dp, HoggarColorTokens.ErrorCoral.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
              .padding(10.dp),
          ) {
            Text(
              text = err,
              color = HoggarColorTokens.ErrorCoral,
              fontSize = 12.sp,
              textAlign = TextAlign.Center,
              modifier = Modifier.fillMaxWidth(),
            )
          }
        }
      }

      // PRIMARY ACTION 1: GOOGLE SIGN IN
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(Color.White)
          .clickable(enabled = !authState.isLoading) {
            viewModel.loginWithGoogle(context) {
              onAuthSuccess()
            }
          }
          .padding(horizontal = 16.dp)
          .testTag("btn_google_sign_in"),
        contentAlignment = Alignment.Center,
      ) {
        if (authState.isLoading) {
          CircularProgressIndicator(color = HoggarColorTokens.CopperPrimary, modifier = Modifier.size(24.dp))
        } else {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
          ) {
            GoogleBrandIcon(modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = "المتابعة باستخدام Google",
              color = Color(0xFF1F1F1F),
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // DIVIDER OR
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        HorizontalDivider(modifier = Modifier.weight(1f), color = HoggarColorTokens.BorderSubtle)
        Text(
          text = "أو عبر البريد الإلكتروني",
          color = HoggarColorTokens.TextTertiary,
          fontSize = 12.sp,
          modifier = Modifier.padding(horizontal = 12.dp),
        )
        HorizontalDivider(modifier = Modifier.weight(1f), color = HoggarColorTokens.BorderSubtle)
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Tab Switcher: تسجيل الدخول / حساب جديد
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(HoggarColorTokens.SlateContainer)
          .padding(4.dp),
      ) {
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (selectedTab == 0) HoggarColorTokens.CopperPrimary else Color.Transparent)
            .clickable { selectedTab = 0 }
            .padding(vertical = 8.dp),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = "تسجيل الدخول",
            color = if (selectedTab == 0) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
          )
        }

        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (selectedTab == 1) HoggarColorTokens.CopperPrimary else Color.Transparent)
            .clickable { selectedTab = 1 }
            .padding(vertical = 8.dp),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = "إنشاء حساب",
            color = if (selectedTab == 1) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Input Fields Form
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        if (selectedTab == 0) {
          // Login: Email / Username
          TextField(
            value = emailInput,
            onValueChange = { emailInput = it },
            placeholder = { Text("البريد الإلكتروني أو اسم المستخدم", color = HoggarColorTokens.TextTertiary, fontSize = 13.sp) },
            leadingIcon = {
              Icon(Icons.Filled.Person, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(18.dp))
            },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
              .testTag("sheet_input_login_id"),
            colors = TextFieldDefaults.colors(
              focusedContainerColor = HoggarColorTokens.SlateContainer,
              unfocusedContainerColor = HoggarColorTokens.SlateContainer,
              focusedTextColor = HoggarColorTokens.TextPrimary,
              unfocusedTextColor = HoggarColorTokens.TextPrimary,
              focusedIndicatorColor = Color.Transparent,
              unfocusedIndicatorColor = Color.Transparent,
            ),
          )

          // Password
          TextField(
            value = passwordInput,
            onValueChange = { passwordInput = it },
            placeholder = { Text("كلمة المرور", color = HoggarColorTokens.TextTertiary, fontSize = 13.sp) },
            leadingIcon = {
              Icon(Icons.Filled.Lock, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(18.dp))
            },
            trailingIcon = {
              IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                Icon(
                  imageVector = if (isPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                  contentDescription = null,
                  tint = HoggarColorTokens.TextSecondary,
                  modifier = Modifier.size(18.dp),
                )
              }
            },
            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
              .testTag("sheet_input_login_password"),
            colors = TextFieldDefaults.colors(
              focusedContainerColor = HoggarColorTokens.SlateContainer,
              unfocusedContainerColor = HoggarColorTokens.SlateContainer,
              focusedTextColor = HoggarColorTokens.TextPrimary,
              unfocusedTextColor = HoggarColorTokens.TextPrimary,
              focusedIndicatorColor = Color.Transparent,
              unfocusedIndicatorColor = Color.Transparent,
            ),
          )
        } else {
          // Register: Username
          TextField(
            value = usernameInput,
            onValueChange = { usernameInput = it },
            placeholder = { Text("اسم المستخدم (Username)", color = HoggarColorTokens.TextTertiary, fontSize = 13.sp) },
            leadingIcon = {
              Icon(Icons.Filled.Person, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(18.dp))
            },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
              .testTag("sheet_input_reg_username"),
            colors = TextFieldDefaults.colors(
              focusedContainerColor = HoggarColorTokens.SlateContainer,
              unfocusedContainerColor = HoggarColorTokens.SlateContainer,
              focusedTextColor = HoggarColorTokens.TextPrimary,
              unfocusedTextColor = HoggarColorTokens.TextPrimary,
              focusedIndicatorColor = Color.Transparent,
              unfocusedIndicatorColor = Color.Transparent,
            ),
          )

          // Display Name
          TextField(
            value = displayNameInput,
            onValueChange = { displayNameInput = it },
            placeholder = { Text("اسم العرض الكامل", color = HoggarColorTokens.TextTertiary, fontSize = 13.sp) },
            leadingIcon = {
              Icon(Icons.Filled.Person, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(18.dp))
            },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp)),
            colors = TextFieldDefaults.colors(
              focusedContainerColor = HoggarColorTokens.SlateContainer,
              unfocusedContainerColor = HoggarColorTokens.SlateContainer,
              focusedTextColor = HoggarColorTokens.TextPrimary,
              unfocusedTextColor = HoggarColorTokens.TextPrimary,
              focusedIndicatorColor = Color.Transparent,
              unfocusedIndicatorColor = Color.Transparent,
            ),
          )

          // Email
          TextField(
            value = emailInput,
            onValueChange = { emailInput = it },
            placeholder = { Text("البريد الإلكتروني", color = HoggarColorTokens.TextTertiary, fontSize = 13.sp) },
            leadingIcon = {
              Icon(Icons.Filled.Email, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(18.dp))
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
              .testTag("sheet_input_reg_email"),
            colors = TextFieldDefaults.colors(
              focusedContainerColor = HoggarColorTokens.SlateContainer,
              unfocusedContainerColor = HoggarColorTokens.SlateContainer,
              focusedTextColor = HoggarColorTokens.TextPrimary,
              unfocusedTextColor = HoggarColorTokens.TextPrimary,
              focusedIndicatorColor = Color.Transparent,
              unfocusedIndicatorColor = Color.Transparent,
            ),
          )

          // Password
          TextField(
            value = passwordInput,
            onValueChange = { passwordInput = it },
            placeholder = { Text("كلمة المرور (6 أحرف على الأقل)", color = HoggarColorTokens.TextTertiary, fontSize = 13.sp) },
            leadingIcon = {
              Icon(Icons.Filled.Lock, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(18.dp))
            },
            trailingIcon = {
              IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                Icon(
                  imageVector = if (isPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                  contentDescription = null,
                  tint = HoggarColorTokens.TextSecondary,
                  modifier = Modifier.size(18.dp),
                )
              }
            },
            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
              .testTag("sheet_input_reg_password"),
            colors = TextFieldDefaults.colors(
              focusedContainerColor = HoggarColorTokens.SlateContainer,
              unfocusedContainerColor = HoggarColorTokens.SlateContainer,
              focusedTextColor = HoggarColorTokens.TextPrimary,
              unfocusedTextColor = HoggarColorTokens.TextPrimary,
              focusedIndicatorColor = Color.Transparent,
              unfocusedIndicatorColor = Color.Transparent,
            ),
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Submit Email Auth Button
        HoggarButton(
          text = if (selectedTab == 0) "دخول بالبريد" else "إنشاء الحساب بالبريد",
          variant = HoggarButtonVariant.PrimaryCopper,
          isLoading = authState.isLoading,
          onClick = {
            if (selectedTab == 0) {
              viewModel.login(emailInput, passwordInput) {
                onAuthSuccess()
              }
            } else {
              viewModel.register(usernameInput, displayNameInput, emailInput, passwordInput) {
                onAuthSuccess()
              }
            }
          },
          modifier = Modifier.fillMaxWidth().testTag("btn_email_submit"),
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Continue as Guest Option
      Text(
        text = "المتابعة كزائر دون تسجيل الآن",
        color = HoggarColorTokens.TextTertiary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .clickable(onClick = onDismiss)
          .padding(horizontal = 12.dp, vertical = 6.dp)
          .testTag("btn_continue_as_guest"),
      )
    }
  }
}
