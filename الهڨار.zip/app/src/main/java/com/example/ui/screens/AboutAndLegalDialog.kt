package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarLogoMark
import com.example.ui.theme.HoggarColorTokens
import java.util.UUID

enum class LegalTab(val titleAr: String, val icon: ImageVector) {
  About("حول الهڨار", Icons.Filled.Info),
  Privacy("سياسة الخصوصية", Icons.Filled.Security),
  Terms("شروط الخدمة", Icons.Filled.Description),
  Community("إرشادات المجتمع", Icons.Filled.Policy),
  Support("الدعم الفني", Icons.Filled.SupportAgent),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutAndLegalSheet(
  initialTab: LegalTab = LegalTab.About,
  onDismiss: () -> Unit,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var currentTab by remember { mutableStateOf(initialTab) }
  var supportMessage by remember { mutableStateOf("") }
  var supportSentTicket by remember { mutableStateOf<String?>(null) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = HoggarColorTokens.BasaltSurface,
    contentColor = HoggarColorTokens.TextPrimary,
    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
    modifier = Modifier.testTag("about_and_legal_sheet"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 8.dp)
        .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      // Header Bar
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(onClick = onDismiss) {
          Icon(Icons.Filled.Close, contentDescription = "إغلاق", tint = HoggarColorTokens.TextSecondary)
        }
        Text(
          text = currentTab.titleAr,
          color = HoggarColorTokens.TextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.width(48.dp))
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Tab selector row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(HoggarColorTokens.ObsidianBase)
          .padding(4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
      ) {
        LegalTab.entries.forEach { tab ->
          val isSelected = tab == currentTab
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) HoggarColorTokens.InteractiveAmber else Color.Transparent)
              .clickable {
                currentTab = tab
                supportSentTicket = null
              }
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = tab.icon,
              contentDescription = tab.titleAr,
              tint = if (isSelected) HoggarColorTokens.ObsidianBase else HoggarColorTokens.TextSecondary,
              modifier = Modifier.size(20.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Content based on tab
      when (currentTab) {
        LegalTab.About -> {
          HoggarLogoMark(size = 72.dp)
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "تطبيق الهڨار",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
          )
          Text(
            text = "منصة الفيديوهات القصيرة حتى 60 ثانية",
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "الإصدار: 1.0.0 (Production Release)",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 12.sp,
          )
          Spacer(modifier = Modifier.height(16.dp))

          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.ObsidianBase),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "نبذة عن المنصة",
                color = HoggarColorTokens.TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "«الهڨار» تطبيق مبتكر ومخصص لمشاركة وصناعة الفيديوهات القصيرة العمودية بهوية بصرية مستوحاة من عراقة جبال الهڨار وعمق التراث الجزائري والإفريقي، مصمم بمعايير أداء فائقة تضمن تجربة تصفح سريعة وخفيفة وتفاعلاً حقيقياً ومحترماً.",
                color = HoggarColorTokens.TextSecondary,
                fontSize = 14.sp,
                lineHeight = 22.sp,
              )
            }
          }
        }

        LegalTab.Privacy -> {
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.ObsidianBase),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "التزام الخصوصية وحماية البيانات",
                color = HoggarColorTokens.InteractiveAmber,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
              )
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = "• نلتزم بحماية خصوصية المستخدمين وعدم بيع أو مشاركة البيانات الشخصية مع أي طرف ثالث.\n" +
                  "• نجمع فقط البيانات التشغيلية الضرورية لعمل المشغل وجودة البث وحسابات المشاهدة دون أي تتبع تجسسي.\n" +
                  "• يتم تشفير كلمات المرور والرموز واستخدام آليات أمان صارمة ومطابقة لمعايير الحماية العالمية.\n" +
                  "• يحق للمستخدم في أي وقت حذف حسابه وكافة بياناته وفيديوهاته نهائياً من خوادم التطبيق بنقرة واحدة.",
                color = HoggarColorTokens.TextSecondary,
                fontSize = 14.sp,
                lineHeight = 24.sp,
              )
            }
          }
        }

        LegalTab.Terms -> {
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.ObsidianBase),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "شروط الاستخدام والخدمة",
                color = HoggarColorTokens.InteractiveAmber,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
              )
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = "• يُشترط أن يمتلك المستخدم حقوق نشر المحتوى أو المقاطع الصوتية التي يقوم برفعها.\n" +
                  "• يُحظر نشر أي محتوى يحرّض على العنف أو الكراهية أو ينتهك الآداب العامة وقوانين النشر.\n" +
                  "• تحتفظ إدارة المنصة بحق حظر الحسابات أو إزالة المقاطع المخالفة فور التحقق من البلاغات.\n" +
                  "• المنصة توفر خدمة النشر والمشاهدة التشاركية مع تطبيق تدابير الأمان والتحقق الآلي واليدوي.",
                color = HoggarColorTokens.TextSecondary,
                fontSize = 14.sp,
                lineHeight = 24.sp,
              )
            }
          }
        }

        LegalTab.Community -> {
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.ObsidianBase),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "إرشادات مجتمع الهڨار",
                color = HoggarColorTokens.InteractiveAmber,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
              )
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = "• شجّع الإبداع الهادف واحتفِ بالثقافة والتراث وتجارب الحياة اليومية المميزة.\n" +
                  "• التزم بالاحترام المتبادل في قسم التعليقات وتجنب المضايقات أو الإساءات اللفظية.\n" +
                  "• استخدم زر الإبلاغ عن أي محتوى مخالف لمساعدتنا في الحفاظ على مجتمع آمن ونظيف للجميع.",
                color = HoggarColorTokens.TextSecondary,
                fontSize = 14.sp,
                lineHeight = 24.sp,
              )
            }
          }
        }

        LegalTab.Support -> {
          if (supportSentTicket != null) {
            Card(
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.ObsidianBase),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                Text(
                  text = "تم استلام رسالتك بنجاح",
                  color = HoggarColorTokens.InteractiveAmber,
                  fontSize = 18.sp,
                  fontWeight = FontWeight.Bold,
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = "رقم التذكرة: $supportSentTicket",
                  color = HoggarColorTokens.TextPrimary,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Medium,
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = "فريق دعم الهڨار سيراجع طلبك ويعالج المشكلة بأسرع وقت.",
                  color = HoggarColorTokens.TextSecondary,
                  fontSize = 13.sp,
                  textAlign = TextAlign.Center,
                )
              }
            }
          } else {
            Card(
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.ObsidianBase),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(modifier = Modifier.padding(16.dp)) {
                Text(
                  text = "التواصل مع الدعم الفني والإبلاغ عن مشكلة",
                  color = HoggarColorTokens.InteractiveAmber,
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = "اكتب استفسارك أو وصف المشكلة التي تواجهها وسيقوم فريق الدعم بمتابعتها:",
                  color = HoggarColorTokens.TextSecondary,
                  fontSize = 13.sp,
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                  value = supportMessage,
                  onValueChange = { supportMessage = it },
                  placeholder = { Text("اشرح المشكلة بوضوح هنا...", color = HoggarColorTokens.TextTertiary) },
                  minLines = 4,
                  maxLines = 6,
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("support_input"),
                  colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = HoggarColorTokens.InteractiveAmber,
                    unfocusedBorderColor = HoggarColorTokens.BasaltSurface,
                    focusedTextColor = HoggarColorTokens.TextPrimary,
                    unfocusedTextColor = HoggarColorTokens.TextPrimary,
                  ),
                )
                Spacer(modifier = Modifier.height(14.dp))
                HoggarButton(
                  text = "إرسال إلى فريق الدعم",
                  variant = HoggarButtonVariant.PrimaryCopper,
                  enabled = supportMessage.isNotBlank(),
                  onClick = {
                    val ticketId = "TKT-${UUID.randomUUID().toString().take(6).uppercase()}"
                    supportSentTicket = ticketId
                    supportMessage = ""
                  },
                  modifier = Modifier.fillMaxWidth(),
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
