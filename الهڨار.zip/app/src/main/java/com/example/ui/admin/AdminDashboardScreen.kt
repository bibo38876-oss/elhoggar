package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.VideoItem
import com.example.model.VideoModerationStatus
import com.example.security.model.AccountStatus
import com.example.security.model.AuditLogEntry
import com.example.security.model.EnhancedReportItem
import com.example.security.model.PlatformMetrics
import com.example.security.model.ReportStatus
import com.example.security.model.UserRole
import com.example.security.repository.AdminRepository
import com.example.security.repository.AdminUserEntry
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarCard
import com.example.ui.components.HoggarEmptyState
import com.example.ui.theme.HoggarColorTokens
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminDashboardScreen(
  adminRepository: AdminRepository,
  onExitAdmin: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val scope = rememberCoroutineScope()
  var currentRole by remember { mutableStateOf(UserRole.SuperAdmin) }
  var selectedTab by remember { mutableIntStateOf(0) } // 0: المؤشرات, 1: البلاغات, 2: الفيديوهات, 3: المستخدمون, 4: سجل التدقيق

  val metrics by adminRepository.getPlatformMetrics().collectAsState(initial = PlatformMetrics())
  val reports by adminRepository.getReports().collectAsState(initial = emptyList())
  val videos by adminRepository.getVideosForModeration().collectAsState(initial = emptyList())
  val users by adminRepository.getUsers().collectAsState(initial = emptyList())
  val auditLogs by adminRepository.getAuditLogs().collectAsState(initial = emptyList())

  // Dialog State for Actions
  var actionErrorDialogText by remember { mutableStateOf<String?>(null) }
  var actionSuccessToast by remember { mutableStateOf<String?>(null) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("admin_dashboard_screen"),
  ) {
    // Top Bar with Shield, Role Switcher, and Back Button
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(HoggarColorTokens.BasaltSurface)
        .padding(horizontal = 16.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onExitAdmin) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Exit Admin",
            tint = HoggarColorTokens.TextPrimary,
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Icon(
          imageVector = Icons.Filled.Shield,
          contentDescription = null,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(24.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          Text(
            text = "مركز الإشراف والأمان",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = "منصة الهڨار • لوحة الإدارة المركزية",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 11.sp,
          )
        }
      }

      // Quick Role Switcher for verification
      RoleBadgeDropdown(
        currentRole = currentRole,
        onRoleSelected = { currentRole = it },
      )
    }

    // Tabs: المؤشرات, البلاغات, الفيديوهات, المستخدمون, سجل التدقيق
    val tabTitles = listOf("المؤشرات", "البلاغات (${reports.count { it.status == ReportStatus.Pending }})", "الفيديوهات", "المستخدمون", "سجل التدقيق")
    ScrollableTabRow(
      selectedTabIndex = selectedTab,
      containerColor = HoggarColorTokens.BasaltSurface,
      contentColor = HoggarColorTokens.TextPrimary,
      edgePadding = 16.dp,
      indicator = { tabPositions ->
        SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
          color = HoggarColorTokens.InteractiveAmber,
        )
      },
    ) {
      tabTitles.forEachIndexed { index, title ->
        Tab(
          selected = selectedTab == index,
          onClick = { selectedTab = index },
          text = {
            Text(
              text = title,
              color = if (selectedTab == index) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextSecondary,
              fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
              fontSize = 13.sp,
            )
          },
        )
      }
    }

    // Tab Body
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
      when (selectedTab) {
        0 -> MetricsTabContent(metrics = metrics)
        1 -> ReportsTabContent(
          reports = reports,
          onUpdateStatus = { reportId, newStatus ->
            scope.launch {
              val res = adminRepository.updateReportStatus(
                reportId = reportId,
                newStatus = newStatus,
                reviewerId = "admin_user",
                reviewerName = currentRole.labelAr,
                actorRole = currentRole,
                resolutionNote = "تم فحص البلاغ وتطبيق السياسة الإدارية",
              )
              res.onFailure { actionErrorDialogText = it.message }
            }
          },
        )
        2 -> VideosTabContent(
          videos = videos,
          onModerate = { videoId, newStatus ->
            scope.launch {
              val res = adminRepository.moderateVideo(
                videoId = videoId,
                newStatus = newStatus,
                actorId = "admin_user",
                actorName = currentRole.labelAr,
                actorRole = currentRole,
                reason = "قرار إشرافي وفق سياسة المحتوى",
              )
              res.onFailure { actionErrorDialogText = it.message }
            }
          },
          onDelete = { videoId ->
            scope.launch {
              val res = adminRepository.deleteVideoByAdmin(
                videoId = videoId,
                actorId = "admin_user",
                actorName = currentRole.labelAr,
                actorRole = currentRole,
                reason = "حذف نهائي لمخالفة شروط الخدمة",
              )
              res.onFailure { actionErrorDialogText = it.message }
            }
          },
        )
        3 -> UsersTabContent(
          users = users,
          onUpdateStatus = { targetUserId, newStatus ->
            scope.launch {
              val res = adminRepository.updateUserStatus(
                targetUserId = targetUserId,
                newStatus = newStatus,
                actorId = "admin_user",
                actorName = currentRole.labelAr,
                actorRole = currentRole,
                reason = "تعديل حالة الحساب من لوحة الإشراف",
              )
              res.onFailure { actionErrorDialogText = it.message }
            }
          },
        )
        4 -> AuditLogsTabContent(logs = auditLogs)
      }
    }
  }

  // Error Alert Dialog
  actionErrorDialogText?.let { errorMsg ->
    AlertDialog(
      onDismissRequest = { actionErrorDialogText = null },
      title = { Text(text = "تنبيه الصلاحيات والأمان", color = HoggarColorTokens.TextPrimary, fontWeight = FontWeight.Bold) },
      text = { Text(text = errorMsg, color = HoggarColorTokens.TextSecondary, fontSize = 13.sp) },
      confirmButton = {
        TextButton(onClick = { actionErrorDialogText = null }) {
          Text(text = "حسناً", color = HoggarColorTokens.InteractiveAmber, fontWeight = FontWeight.Bold)
        }
      },
      containerColor = HoggarColorTokens.SlateContainer,
    )
  }
}

@Composable
private fun RoleBadgeDropdown(
  currentRole: UserRole,
  onRoleSelected: (UserRole) -> Unit,
) {
  var expanded by remember { mutableStateOf(false) }

  Box {
    Row(
      modifier = Modifier
        .clip(RoundedCornerShape(8.dp))
        .background(HoggarColorTokens.SlateContainer)
        .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(8.dp))
        .clickable {
          // Cycle through roles for rapid permission testing
          val nextRole = when (currentRole) {
            UserRole.SuperAdmin -> UserRole.Moderator
            UserRole.Moderator -> UserRole.Support
            UserRole.Support -> UserRole.SuperAdmin
            UserRole.RegularUser -> UserRole.SuperAdmin
          }
          onRoleSelected(nextRole)
        }
        .padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .size(8.dp)
          .clip(CircleShape)
          .background(if (currentRole == UserRole.SuperAdmin) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.CopperPrimary),
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = currentRole.labelAr,
        color = HoggarColorTokens.TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
      )
    }
  }
}

@Composable
private fun MetricsTabContent(metrics: PlatformMetrics) {
  LazyColumn(
    verticalArrangement = Arrangement.spacedBy(12.dp),
    modifier = Modifier.fillMaxSize(),
  ) {
    item {
      Text(
        text = "المؤشرات الإحصائية العامة للمنصة",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(vertical = 4.dp),
      )
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        MetricCard(
          title = "إجمالي المستخدمين",
          value = metrics.totalUsers.toString(),
          icon = Icons.Filled.People,
          modifier = Modifier.weight(1f),
        )
        MetricCard(
          title = "المستخدمون النشطون",
          value = metrics.activeUsers.toString(),
          icon = Icons.Filled.CheckCircle,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.weight(1f),
        )
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        MetricCard(
          title = "إجمالي الفيديوهات",
          value = metrics.totalVideos.toString(),
          icon = Icons.Filled.Videocam,
          modifier = Modifier.weight(1f),
        )
        MetricCard(
          title = "إجمالي المشاهدات",
          value = formatCompact(metrics.totalViews),
          icon = Icons.Filled.Assessment,
          modifier = Modifier.weight(1f),
        )
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        MetricCard(
          title = "بلاغات مفتوحة",
          value = metrics.pendingReports.toString(),
          icon = Icons.Filled.Report,
          tint = if (metrics.pendingReports > 0) Color(0xFFFF5252) else HoggarColorTokens.TextSecondary,
          modifier = Modifier.weight(1f),
        )
        MetricCard(
          title = "حسابات مقيدة",
          value = metrics.restrictedUsers.toString(),
          icon = Icons.Filled.Block,
          tint = Color(0xFFFFB74D),
          modifier = Modifier.weight(1f),
        )
      }
    }
  }
}

@Composable
private fun MetricCard(
  title: String,
  value: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  modifier: Modifier = Modifier,
  tint: Color = HoggarColorTokens.TextPrimary,
) {
  HoggarCard(
    modifier = modifier,
    contentPadding = 12.dp,
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text(text = title, color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, color = tint, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
      }
      Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(26.dp))
    }
  }
}

@Composable
private fun ReportsTabContent(
  reports: List<EnhancedReportItem>,
  onUpdateStatus: (String, ReportStatus) -> Unit,
) {
  if (reports.isEmpty()) {
    HoggarEmptyState(
      title = "لا توجد بلاغات معلقة",
      description = "جميع البلاغات تم التدقيق فيها واتخاذ الإجراءات اللازمة.",
    )
    return
  }

  LazyColumn(
    verticalArrangement = Arrangement.spacedBy(10.dp),
    modifier = Modifier.fillMaxSize(),
  ) {
    items(reports, key = { it.reportId }) { report ->
      HoggarCard(contentPadding = 12.dp) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(HoggarColorTokens.SlateContainer),
              contentAlignment = Alignment.Center,
            ) {
              Icon(imageVector = Icons.Filled.Report, contentDescription = null, tint = Color(0xFFFF5252), modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "${report.targetType.name} : ${report.targetId}",
                color = HoggarColorTokens.TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = "السبب: ${report.reason.labelAr}",
                color = HoggarColorTokens.TextSecondary,
                fontSize = 11.sp,
              )
            }
          }

          // Status Badge
          StatusBadge(status = report.status)
        }

        if (report.description.isNotEmpty()) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "التفاصيل: ${report.description}",
            color = HoggarColorTokens.TextTertiary,
            fontSize = 11.sp,
            lineHeight = 16.sp,
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Actions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          if (report.status != ReportStatus.Resolved) {
            HoggarButton(
              text = "اتخاذ إجراء / تم الحل",
              onClick = { onUpdateStatus(report.reportId, ReportStatus.Resolved) },
              variant = HoggarButtonVariant.PrimaryCopper,
              modifier = Modifier.weight(1f),
            )
          }

          if (report.status != ReportStatus.Dismissed) {
            HoggarButton(
              text = "حفظ البلاغ",
              onClick = { onUpdateStatus(report.reportId, ReportStatus.Dismissed) },
              variant = HoggarButtonVariant.Outlined,
              modifier = Modifier.weight(1f),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun StatusBadge(status: ReportStatus) {
  val color = when (status) {
    ReportStatus.Pending -> Color(0xFFFF5252)
    ReportStatus.Reviewing -> Color(0xFFFFB74D)
    ReportStatus.Resolved -> Color(0xFF66BB6A)
    ReportStatus.Dismissed -> HoggarColorTokens.TextSecondary
  }
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(color.copy(alpha = 0.15f))
      .border(0.5.dp, color, RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 4.dp),
  ) {
    Text(text = status.labelAr, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
  }
}

@Composable
private fun VideosTabContent(
  videos: List<VideoItem>,
  onModerate: (String, VideoModerationStatus) -> Unit,
  onDelete: (String) -> Unit,
) {
  LazyColumn(
    verticalArrangement = Arrangement.spacedBy(10.dp),
    modifier = Modifier.fillMaxSize(),
  ) {
    items(videos, key = { it.id }) { video ->
      HoggarCard(contentPadding = 10.dp) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(
            modifier = Modifier
              .width(60.dp)
              .aspectRatio(9f / 14f)
              .clip(RoundedCornerShape(6.dp))
              .background(HoggarColorTokens.BasaltSurface),
          ) {
            AsyncImage(model = video.thumbnailUrl, contentDescription = null, modifier = Modifier.fillMaxSize())
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(text = video.title, color = HoggarColorTokens.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(text = "@${video.creator.username} • ${video.durationSeconds} ثانية", color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            ModerationStatusPill(status = video.moderationStatus)
          }

          IconButton(onClick = { onDelete(video.id) }) {
            Icon(imageVector = Icons.Filled.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252))
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Moderation Control Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          HoggarButton(
            text = "اعتماد",
            onClick = { onModerate(video.id, VideoModerationStatus.Approved) },
            variant = HoggarButtonVariant.PrimaryCopper,
            modifier = Modifier.weight(1f),
          )
          HoggarButton(
            text = "تقييد",
            onClick = { onModerate(video.id, VideoModerationStatus.Restricted) },
            variant = HoggarButtonVariant.Outlined,
            modifier = Modifier.weight(1f),
          )
          HoggarButton(
            text = "رفض",
            onClick = { onModerate(video.id, VideoModerationStatus.Rejected) },
            variant = HoggarButtonVariant.Outlined,
            modifier = Modifier.weight(1f),
          )
        }
      }
    }
  }
}

@Composable
private fun ModerationStatusPill(status: VideoModerationStatus) {
  val color = when (status) {
    VideoModerationStatus.Approved -> Color(0xFF66BB6A)
    VideoModerationStatus.Pending -> Color(0xFFFFB74D)
    VideoModerationStatus.Rejected -> Color(0xFFFF5252)
    VideoModerationStatus.Restricted -> Color(0xFFFF7043)
  }
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(4.dp))
      .background(color.copy(alpha = 0.15f))
      .padding(horizontal = 6.dp, vertical = 2.dp),
  ) {
    Text(text = status.labelAr, color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
private fun UsersTabContent(
  users: List<AdminUserEntry>,
  onUpdateStatus: (String, AccountStatus) -> Unit,
) {
  LazyColumn(
    verticalArrangement = Arrangement.spacedBy(10.dp),
    modifier = Modifier.fillMaxSize(),
  ) {
    items(users, key = { it.id }) { user ->
      HoggarCard(contentPadding = 12.dp) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(text = user.displayName, color = HoggarColorTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(text = "@${user.username} • ${user.role.labelAr}", color = HoggarColorTokens.InteractiveAmber, fontSize = 11.sp)
            Text(text = "الفيديوهات: ${user.videoCount}", color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
          }

          AccountStatusBadge(status = user.status)
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          if (user.status != AccountStatus.Active) {
            HoggarButton(
              text = "تنشيط الحساب",
              onClick = { onUpdateStatus(user.id, AccountStatus.Active) },
              variant = HoggarButtonVariant.PrimaryCopper,
              modifier = Modifier.weight(1f),
            )
          }
          if (user.status != AccountStatus.Restricted) {
            HoggarButton(
              text = "تقييد الحساب",
              onClick = { onUpdateStatus(user.id, AccountStatus.Restricted) },
              variant = HoggarButtonVariant.Outlined,
              modifier = Modifier.weight(1f),
            )
          }
          if (user.status != AccountStatus.Banned) {
            HoggarButton(
              text = "حظر نهائي",
              onClick = { onUpdateStatus(user.id, AccountStatus.Banned) },
              variant = HoggarButtonVariant.Outlined,
              modifier = Modifier.weight(1f),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun AccountStatusBadge(status: AccountStatus) {
  val color = when (status) {
    AccountStatus.Active -> Color(0xFF66BB6A)
    AccountStatus.Restricted -> Color(0xFFFFB74D)
    AccountStatus.Banned -> Color(0xFFFF5252)
  }
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(color.copy(alpha = 0.15f))
      .border(0.5.dp, color, RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 4.dp),
  ) {
    Text(text = status.labelAr, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
  }
}

@Composable
private fun AuditLogsTabContent(logs: List<AuditLogEntry>) {
  val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.getDefault()) }

  LazyColumn(
    verticalArrangement = Arrangement.spacedBy(8.dp),
    modifier = Modifier.fillMaxSize(),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(imageVector = Icons.Filled.History, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "سجل العمليات الإدارية الثابت (غير قابل للحذف)",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
        )
      }
      Spacer(modifier = Modifier.height(4.dp))
    }

    items(logs, key = { it.id }) { log ->
      HoggarCard(contentPadding = 10.dp) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(text = log.actionType.labelAr, color = HoggarColorTokens.InteractiveAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          Text(text = dateFormat.format(Date(log.timestampMs)), color = HoggarColorTokens.TextTertiary, fontSize = 10.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "المسؤول: ${log.actorName} (${log.actorRole.labelAr})", color = HoggarColorTokens.TextPrimary, fontSize = 11.sp)
        Text(text = "الهدف: ${log.targetType} [${log.targetId}]", color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
        if (log.reason.isNotEmpty()) {
          Text(text = "السبب: ${log.reason}", color = HoggarColorTokens.TextTertiary, fontSize = 11.sp)
        }
      }
    }
  }
}

private fun formatCompact(count: Long): String {
  return when {
    count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
    count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
    else -> count.toString()
  }
}
