package com.example.ui.create

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.repository.SoundRepository
import com.example.model.VideoProcessingStatus
import com.example.model.VideoVisibility
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarCard
import com.example.ui.components.HoggarDurationBadge
import com.example.ui.components.HoggarLogoMark
import com.example.ui.components.HoggarTag
import com.example.ui.theme.HoggarColorTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateStudioScreen(
  viewModel: VideoCreateViewModel,
  onClose: () -> Unit,
  onViewPublished: (videoId: String) -> Unit,
  soundRepository: SoundRepository? = null,
  onOpenCreatePost: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val state by viewModel.state.collectAsState()
  var showSoundPicker by remember { mutableStateOf(false) }

  // Android Photo Picker for Videos (zero-permission, fully Google Play compliant)
  val videoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia(),
  ) { uri ->
    if (uri != null) {
      viewModel.onVideoSelected(uri.toString(), 52)
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("create_studio_screen"),
  ) {
    when (state.stage) {
      CreationStage.CaptureOrPick -> {
        CaptureOrPickView(
          onPickFromGallery = {
            videoPickerLauncher.launch(
              PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly),
            )
          },
          onSampleSelected = { url, duration ->
            viewModel.onVideoSelected(url, duration)
          },
          onOpenCreatePost = onOpenCreatePost,
          onClose = onClose,
        )
      }

      CreationStage.TrimAndEdit -> {
        TrimAndEditView(
          state = state,
          onUpdateTrim = { start, end -> viewModel.updateTrim(start, end) },
          onToggleAudio = { viewModel.toggleAudioMute() },
          onSelectCover = { url -> viewModel.selectThumbnail(url) },
          onOpenSoundPicker = { showSoundPicker = true },
          onRemoveSound = { viewModel.selectSound(null) },
          onUpdateAudioVolumes = { orig, added -> viewModel.updateAudioVolumes(orig, added) },
          onProceed = { viewModel.proceedToMetadata() },
          onBack = { viewModel.reset() },
        )
      }

      CreationStage.MetadataAndPreview -> {
        MetadataAndPreviewView(
          state = state,
          onUpdateMetadata = { desc, tags, vis -> viewModel.updateMetadata(desc, tags, vis) },
          onPublish = { viewModel.publishVideo() },
          onBack = { viewModel.backToTrimmer() },
        )
      }

      CreationStage.Uploading -> {
        UploadingPipelineView(
          state = state,
          onRetry = { viewModel.publishVideo() },
          onFinish = {
            state.publishedVideo?.let { onViewPublished(it.id) } ?: onClose()
          },
        )
      }
    }

    // Modal Sound Vault Picker
    if (showSoundPicker && soundRepository != null) {
      val pickerSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
      SoundPickerBottomSheet(
        soundRepository = soundRepository,
        currentSelectedSound = state.selectedSound,
        sheetState = pickerSheetState,
        onSoundSelected = { sound ->
          viewModel.selectSound(sound)
        },
        onDismiss = { showSoundPicker = false },
      )
    }
  }
}

// -------------------------------------------------------------
// STAGE 1: CAPTURE OR PICK
// -------------------------------------------------------------
@Composable
private fun CaptureOrPickView(
  onPickFromGallery: () -> Unit,
  onSampleSelected: (url: String, duration: Int) -> Unit,
  onOpenCreatePost: (() -> Unit)? = null,
  onClose: () -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    // Top Bar
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onClose) {
        Icon(
          imageVector = Icons.Filled.Close,
          contentDescription = "Close",
          tint = HoggarColorTokens.TextPrimary,
        )
      }
      Text(
        text = "استوديو إنشاء المحتوى",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
      )
      Spacer(modifier = Modifier.width(48.dp))
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Studio Hero Card
    HoggarLogoMark(size = 72.dp, showGlow = true)
    Spacer(modifier = Modifier.height(14.dp))
    Text(
      text = "أنشئ وشارك في مجتمع الهڨار",
      color = HoggarColorTokens.TextPrimary,
      fontSize = 21.sp,
      fontWeight = FontWeight.ExtraBold,
    )
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = "فيديوهات عمودية (9:16) أو منشورات وتغريدات كتابية مع صور",
      color = HoggarColorTokens.TextSecondary,
      fontSize = 13.sp,
    )

    Spacer(modifier = Modifier.height(28.dp))

    // Primary Actions (Video Gallery, Camera, and Text/Photo Post)
    Column(
      modifier = Modifier.fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      HoggarButton(
        text = "اختيار فيديو من الهاتف (9:16)",
        onClick = onPickFromGallery,
        variant = HoggarButtonVariant.PrimaryCopper,
        icon = Icons.Filled.VideoLibrary,
        modifier = Modifier.fillMaxWidth().testTag("btn_pick_gallery_video"),
      )

      HoggarButton(
        text = "تسجيل فيديو بالكاميرا (60 ثانية كحد أقصى)",
        onClick = {
          // Pre-select live vertical recording sample
          onSampleSelected(
            "asset:///videos/hoggar_1.mp4",
            50,
          )
        },
        variant = HoggarButtonVariant.Outlined,
        icon = Icons.Filled.Videocam,
        modifier = Modifier.fillMaxWidth().testTag("btn_camera_record"),
      )

      if (onOpenCreatePost != null) {
        HoggarButton(
          text = "كتابة منشور أو تغريدة جديدة مع صور ✍️",
          onClick = onOpenCreatePost,
          variant = HoggarButtonVariant.Outlined,
          icon = Icons.Filled.Edit,
          modifier = Modifier.fillMaxWidth().testTag("btn_create_post_from_studio"),
        )
      }
    }

    Spacer(modifier = Modifier.height(32.dp))

    // Quick Sample Selection for Instant Testing
    HoggarCard(modifier = Modifier.fillMaxWidth()) {
      Text(
        text = "أو اختر عينة صحراوية جاهزة للمعاينة والقص السريع:",
        color = HoggarColorTokens.TextSecondary,
        fontSize = 12.sp,
      )

      Spacer(modifier = Modifier.height(12.dp))

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SampleClipRow(
          title = "غروب شمس أسكرام (75 ثانية - يتطلب قصًا)",
          duration = "75 ثانية",
          requiresTrim = true,
          onClick = {
            onSampleSelected(
              "asset:///videos/hoggar_1.mp4",
              75,
            )
          },
        )
        SampleClipRow(
          title = "صياغة قلائد الفضة في تمنراست",
          duration = "38 ثانية",
          requiresTrim = false,
          onClick = {
            onSampleSelected(
              "asset:///videos/hoggar_2.mp4",
              38,
            )
          },
        )
        SampleClipRow(
          title = "إيقاعات الطيندي تحت النجوم",
          duration = "58 ثانية",
          requiresTrim = false,
          onClick = {
            onSampleSelected(
              "asset:///videos/hoggar_3.mp4",
              58,
            )
          },
        )
      }
    }
  }
}

@Composable
private fun SampleClipRow(
  title: String,
  duration: String,
  requiresTrim: Boolean,
  onClick: () -> Unit,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .background(HoggarColorTokens.SlateContainer)
      .clickable(onClick = onClick)
      .padding(10.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column {
      Text(text = title, color = HoggarColorTokens.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
      if (requiresTrim) {
        Text(text = "أطول من 60 ثانية - ستتمكن من قصه للحد الأقصى", color = HoggarColorTokens.WarningDune, fontSize = 11.sp)
      }
    }
    HoggarDurationBadge(duration)
  }
}

// -------------------------------------------------------------
// STAGE 2: TRIM AND EDIT (TIMELINE & 60s STRICT ENFORCEMENT)
// -------------------------------------------------------------
@Composable
private fun TrimAndEditView(
  state: VideoCreationState,
  onUpdateTrim: (start: Int, end: Int) -> Unit,
  onToggleAudio: () -> Unit,
  onSelectCover: (url: String) -> Unit,
  onOpenSoundPicker: () -> Unit = {},
  onRemoveSound: () -> Unit = {},
  onUpdateAudioVolumes: (original: Float, added: Float) -> Unit = { _, _ -> },
  onProceed: () -> Unit,
  onBack: () -> Unit,
) {
  val selectedDuration = state.trimEndSeconds - state.trimStartSeconds
  val isExceeding = selectedDuration > 60

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
  ) {
    // Top Bar
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack) {
        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = HoggarColorTokens.TextPrimary)
      }
      Text(text = "محرر وقص الفيديو", color = HoggarColorTokens.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
      IconButton(onClick = onProceed) {
        Icon(imageVector = Icons.Filled.Check, contentDescription = "Proceed", tint = HoggarColorTokens.InteractiveAmber)
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Video 9:16 Aspect Preview Placeholder
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(320.dp)
        .clip(RoundedCornerShape(16.dp))
        .background(HoggarColorTokens.BasaltSurface)
        .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(16.dp)),
      contentAlignment = Alignment.Center,
    ) {
      AsyncImage(
        model = state.selectedThumbnailUrl,
        contentDescription = "Preview",
        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(16.dp)),
      )

      HoggarDurationBadge(
        durationText = "$selectedDuration ثانية",
        modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
      )

      // Audio Mute Quick Toggle Overlay
      Box(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(12.dp)
          .clip(CircleShape)
          .background(Color(0x77000000))
          .clickable(onClick = onToggleAudio)
          .padding(8.dp),
      ) {
        Icon(
          imageVector = if (state.isAudioMuted) Icons.AutoMirrored.Filled.VolumeMute else Icons.AutoMirrored.Filled.VolumeUp,
          contentDescription = "Audio Toggle",
          tint = if (state.isAudioMuted) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextPrimary,
          modifier = Modifier.size(20.dp),
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Trimmer Timeline Card
    HoggarCard(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Filled.ContentCut, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "قص الفيديو وتحديد المدة", color = HoggarColorTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Text(
          text = "$selectedDuration / 60 ثانية",
          color = if (isExceeding) HoggarColorTokens.ErrorCoral else HoggarColorTokens.InteractiveAmber,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Trim Start Slider
      Column {
        Text(text = "نقطة البداية: ${state.trimStartSeconds} ثانية", color = HoggarColorTokens.TextSecondary, fontSize = 12.sp)
        Slider(
          value = state.trimStartSeconds.toFloat(),
          onValueChange = { newStart ->
            val s = newStart.toInt()
            val maxEnd = (s + 60).coerceAtMost(state.videoDurationSeconds)
            val currentEnd = state.trimEndSeconds.coerceAtLeast(s + 1).coerceAtMost(maxEnd)
            onUpdateTrim(s, currentEnd)
          },
          valueRange = 0f..state.videoDurationSeconds.toFloat().coerceAtLeast(1f),
          colors = SliderDefaults.colors(
            thumbColor = HoggarColorTokens.InteractiveAmber,
            activeTrackColor = HoggarColorTokens.CopperPrimary,
            inactiveTrackColor = HoggarColorTokens.SlateContainer,
          ),
        )
      }

      // Trim End Slider
      Column {
        Text(text = "نقطة النهاية: ${state.trimEndSeconds} ثانية", color = HoggarColorTokens.TextSecondary, fontSize = 12.sp)
        Slider(
          value = state.trimEndSeconds.toFloat(),
          onValueChange = { newEnd ->
            val e = newEnd.toInt()
            val s = state.trimStartSeconds
            val adjustedEnd = e.coerceIn(s + 1, (s + 60).coerceAtMost(state.videoDurationSeconds))
            onUpdateTrim(s, adjustedEnd)
          },
          valueRange = 0f..state.videoDurationSeconds.toFloat().coerceAtLeast(1f),
          colors = SliderDefaults.colors(
            thumbColor = HoggarColorTokens.InteractiveAmber,
            activeTrackColor = HoggarColorTokens.CopperPrimary,
            inactiveTrackColor = HoggarColorTokens.SlateContainer,
          ),
        )
      }

      Text(
        text = "الحد الأقصى المسموح به في منصة الهڨار هو 60 ثانية للحفاظ على تجربة سريعة وخفيفة للمشاهدين.",
        color = HoggarColorTokens.TextTertiary,
        fontSize = 11.sp,
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Sound Track Selection & Volume Balancing Card
    HoggarCard(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.MusicNote,
            contentDescription = null,
            tint = HoggarColorTokens.InteractiveAmber,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "المسار الصوتي والموسيقى",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
          )
        }

        HoggarButton(
          text = if (state.selectedSound != null) "تغيير الصوت" else "مكتبة الأصوات 🎵",
          onClick = onOpenSoundPicker,
          variant = HoggarButtonVariant.Outlined,
          modifier = Modifier.height(32.dp).testTag("btn_open_sound_picker"),
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      if (state.selectedSound != null) {
        val sound = state.selectedSound
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(HoggarColorTokens.SlateContainer)
            .border(1.dp, HoggarColorTokens.CopperPrimary, RoundedCornerShape(12.dp))
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(HoggarColorTokens.BasaltSurface)
              .border(1.dp, HoggarColorTokens.CopperPrimary, CircleShape),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.MusicNote,
              contentDescription = null,
              tint = HoggarColorTokens.InteractiveAmber,
              modifier = Modifier.size(18.dp),
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = sound.title,
              color = HoggarColorTokens.TextPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
            )
            Text(
              text = sound.authorName.ifEmpty { "@${sound.authorUsername}" },
              color = HoggarColorTokens.TextSecondary,
              fontSize = 11.sp,
            )
          }

          IconButton(onClick = onRemoveSound) {
            Icon(
              imageVector = Icons.Filled.Delete,
              contentDescription = "Remove Sound",
              tint = HoggarColorTokens.ErrorCoral,
              modifier = Modifier.size(18.dp),
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Dual Volume Sliders
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(text = "صوت الفيديو الأصلي", color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
            Text(
              text = "${(state.originalAudioVolume * 100).toInt()}%",
              color = HoggarColorTokens.InteractiveAmber,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
            )
          }
          Slider(
            value = state.originalAudioVolume,
            onValueChange = { onUpdateAudioVolumes(it, state.addedSoundVolume) },
            valueRange = 0f..1f,
            colors = SliderDefaults.colors(
              thumbColor = HoggarColorTokens.InteractiveAmber,
              activeTrackColor = HoggarColorTokens.CopperPrimary,
              inactiveTrackColor = HoggarColorTokens.SlateContainer,
            ),
          )
        }

        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(text = "صوت المقطع الصوتي المضاف", color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
            Text(
              text = "${(state.addedSoundVolume * 100).toInt()}%",
              color = HoggarColorTokens.InteractiveAmber,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
            )
          }
          Slider(
            value = state.addedSoundVolume,
            onValueChange = { onUpdateAudioVolumes(state.originalAudioVolume, it) },
            valueRange = 0f..1f,
            colors = SliderDefaults.colors(
              thumbColor = HoggarColorTokens.InteractiveAmber,
              activeTrackColor = HoggarColorTokens.CopperPrimary,
              inactiveTrackColor = HoggarColorTokens.SlateContainer,
            ),
          )
        }
      } else {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(HoggarColorTokens.SlateContainer.copy(alpha = 0.5f))
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Filled.MusicNote,
            contentDescription = null,
            tint = HoggarColorTokens.TextTertiary,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "سيتم استخدام الصوت الأصلي للمقطع واستخراجه تلقائيًا لمكتبة أصوات الهڨار بعد النشر.",
            color = HoggarColorTokens.TextTertiary,
            fontSize = 11.sp,
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Cover Image Selector
    Text(text = "اختر صورة الغلاف:", color = HoggarColorTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    Spacer(modifier = Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      val covers = listOf(
        "https://picsum.photos/seed/hoggar_cover1/720/1280",
        "https://picsum.photos/seed/hoggar_cover2/720/1280",
        "https://picsum.photos/seed/hoggar_cover3/720/1280",
        "https://picsum.photos/seed/hoggar_cover4/720/1280",
      )
      covers.forEach { url ->
        Box(
          modifier = Modifier
            .weight(1f)
            .aspectRatio(9f / 14f)
            .clip(RoundedCornerShape(8.dp))
            .border(
              if (state.selectedThumbnailUrl == url) 2.dp else 1.dp,
              if (state.selectedThumbnailUrl == url) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.BorderSubtle,
              RoundedCornerShape(8.dp),
            )
            .clickable { onSelectCover(url) },
        ) {
          AsyncImage(model = url, contentDescription = null, modifier = Modifier.fillMaxSize())
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    HoggarButton(
      text = "متابعة إلى معلومات النشر",
      onClick = onProceed,
      variant = HoggarButtonVariant.PrimaryCopper,
      modifier = Modifier.fillMaxWidth().testTag("btn_proceed_metadata"),
    )
  }
}

// -------------------------------------------------------------
// STAGE 3: METADATA & PREVIEW (TITLE, TAGS, VISIBILITY)
// -------------------------------------------------------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MetadataAndPreviewView(
  state: VideoCreationState,
  onUpdateMetadata: (desc: String, tags: List<String>, vis: VideoVisibility) -> Unit,
  onPublish: () -> Unit,
  onBack: () -> Unit,
) {
  var description by remember { mutableStateOf(state.description) }
  var visibility by remember { mutableStateOf(state.visibility) }
  val activeTags = remember { mutableStateOf(state.hashtags.toMutableList()) }

  val maxDescLength = 200

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
  ) {
    // Top Bar
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack) {
        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = HoggarColorTokens.TextPrimary)
      }
      Text(text = "تفاصيل ومعاينة النشر", color = HoggarColorTokens.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
      Spacer(modifier = Modifier.width(48.dp))
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Description Input
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(text = "وصف الفيديو", color = HoggarColorTokens.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(text = "${description.length}/$maxDescLength", color = HoggarColorTokens.TextTertiary, fontSize = 12.sp)
      }
      Spacer(modifier = Modifier.height(6.dp))
      TextField(
        value = description,
        onValueChange = {
          if (it.length <= maxDescLength) {
            description = it
            onUpdateMetadata(description, activeTags.value, visibility)
          }
        },
        placeholder = { Text("اكتب وصفًا جذابًا للحظتك المصورة في الهڨار...", color = HoggarColorTokens.TextTertiary, fontSize = 13.sp) },
        minLines = 3,
        maxLines = 4,
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
          .testTag("input_video_description"),
        colors = TextFieldDefaults.colors(
          focusedContainerColor = HoggarColorTokens.SlateContainer,
          unfocusedContainerColor = HoggarColorTokens.SlateContainer,
          focusedTextColor = HoggarColorTokens.TextPrimary,
          unfocusedTextColor = HoggarColorTokens.TextPrimary,
          focusedIndicatorColor = Color.Transparent,
          unfocusedIndicatorColor = Color.Transparent,
        ),
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Suggested Hashtags
    Text(text = "أضف وسومًا رائجة:", color = HoggarColorTokens.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    Spacer(modifier = Modifier.height(6.dp))
    val suggestedTags = listOf("#الهڨار", "#قمة_تاهات", "#تمنراست", "#صحراء_الجزائر", "#سياحة", "#فن")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      suggestedTags.forEach { tag ->
        val isSelected = activeTags.value.contains(tag)
        HoggarTag(
          text = tag,
          isInteractive = true,
          modifier = Modifier.clickable {
            if (isSelected) activeTags.value.remove(tag) else activeTags.value.add(tag)
            onUpdateMetadata(description, activeTags.value, visibility)
          },
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Visibility Selector (Public vs Private)
    Text(text = "إعدادات الخصوصية:", color = HoggarColorTokens.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    Spacer(modifier = Modifier.height(8.dp))
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      // Public Option
      Box(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(10.dp))
          .background(if (visibility == VideoVisibility.Public) HoggarColorTokens.SlateHover else HoggarColorTokens.SlateContainer)
          .border(
            if (visibility == VideoVisibility.Public) 1.5.dp else 1.dp,
            if (visibility == VideoVisibility.Public) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.BorderSubtle,
            RoundedCornerShape(10.dp),
          )
          .clickable {
            visibility = VideoVisibility.Public
            onUpdateMetadata(description, activeTags.value, visibility)
          }
          .padding(12.dp)
          .testTag("opt_visibility_public"),
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Filled.Public, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "عام للجميع", color = HoggarColorTokens.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
          Text(text = "يظهر في الخلاصة الرئيسية ولجميع المشاهدين", color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
        }
      }

      // Private Option
      Box(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(10.dp))
          .background(if (visibility == VideoVisibility.Private) HoggarColorTokens.SlateHover else HoggarColorTokens.SlateContainer)
          .border(
            if (visibility == VideoVisibility.Private) 1.5.dp else 1.dp,
            if (visibility == VideoVisibility.Private) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.BorderSubtle,
            RoundedCornerShape(10.dp),
          )
          .clickable {
            visibility = VideoVisibility.Private
            onUpdateMetadata(description, activeTags.value, visibility)
          }
          .padding(12.dp)
          .testTag("opt_visibility_private"),
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Filled.Lock, contentDescription = null, tint = HoggarColorTokens.TextSecondary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "خاص", color = HoggarColorTokens.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
          Text(text = "يظهر في ملفك فقط ولا يظهر للعامة", color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Audio Sound Info Pill
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(10.dp))
        .background(HoggarColorTokens.SlateContainer)
        .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
        .padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.MusicNote,
          contentDescription = null,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (state.selectedSound != null) {
            "المسار: ${state.selectedSound.title}"
          } else {
            "المسار: الصوت الأصلي للمقطع (سيستخرج لمكتبة الهڨار)"
          },
          color = HoggarColorTokens.TextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Publish Trigger Button
    HoggarButton(
      text = "نشر الفيديو الآن",
      onClick = onPublish,
      variant = HoggarButtonVariant.PrimaryCopper,
      icon = Icons.Filled.CloudUpload,
      modifier = Modifier.fillMaxWidth().testTag("btn_publish_video"),
    )
  }
}

// -------------------------------------------------------------
// STAGE 4: BACKGROUND UPLOADING PIPELINE VIEW
// -------------------------------------------------------------
@Composable
private fun UploadingPipelineView(
  state: VideoCreationState,
  onRetry: () -> Unit,
  onFinish: () -> Unit,
) {
  val progress = state.uploadProgress
  val isFinished = progress?.status == VideoProcessingStatus.Published
  val isFailed = progress?.status == VideoProcessingStatus.Failed

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(24.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    if (isFinished) {
      Box(
        modifier = Modifier
          .size(80.dp)
          .clip(CircleShape)
          .background(HoggarColorTokens.SuccessOasis.copy(alpha = 0.2f))
          .border(2.dp, HoggarColorTokens.SuccessOasis, CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(imageVector = Icons.Filled.Check, contentDescription = null, tint = HoggarColorTokens.SuccessOasis, modifier = Modifier.size(44.dp))
      }

      Spacer(modifier = Modifier.height(18.dp))

      Text(text = "تم نشر الفيديو بنجاح!", color = HoggarColorTokens.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "أصبح الفيديو متاحًا الآن في ملفك الشخصي وفي خلاصة الهڨار.",
        color = HoggarColorTokens.TextSecondary,
        fontSize = 13.sp,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(28.dp))

      HoggarButton(
        text = "مشاهدة الفيديو",
        onClick = onFinish,
        variant = HoggarButtonVariant.PrimaryCopper,
        modifier = Modifier.fillMaxWidth().testTag("btn_view_published"),
      )
    } else if (isFailed) {
      Text(text = "فشلت عملية النشر", color = HoggarColorTokens.ErrorCoral, fontSize = 18.sp, fontWeight = FontWeight.Bold)
      Spacer(modifier = Modifier.height(8.dp))
      Text(text = progress?.errorMessage ?: "حدث خطأ أثناء معالجة الفيديو", color = HoggarColorTokens.TextSecondary, fontSize = 13.sp)
      Spacer(modifier = Modifier.height(20.dp))
      HoggarButton(text = "إعادة المحاولة", onClick = onRetry, variant = HoggarButtonVariant.PrimaryCopper)
    } else {
      HoggarLogoMark(size = 72.dp, isPulsing = true, showGlow = true)
      Spacer(modifier = Modifier.height(20.dp))
      Text(
        text = progress?.stageDescription ?: "جارٍ معالجة الفيديو...",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(14.dp))

      val progressFraction = progress?.progressFraction ?: 0.1f
      LinearProgressIndicator(
        progress = { progressFraction },
        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
        color = HoggarColorTokens.InteractiveAmber,
        trackColor = HoggarColorTokens.SlateContainer,
      )

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "${(progressFraction * 100).toInt()}%",
        color = HoggarColorTokens.InteractiveAmber,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
      )

      Spacer(modifier = Modifier.height(20.dp))

      // Pipeline stages list
      Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        PipelineStageRow("الرفع إلى خوادم الهڨار", progressFraction >= 0.2f)
        PipelineStageRow("التحقق من ترميز الفيديو (9:16)", progressFraction >= 0.4f)
        PipelineStageRow("معالجة وضغط الفيديو لتقليل استهلاك البيانات", progressFraction >= 0.65f)
        PipelineStageRow("توليد صورة الغلاف المحسنة", progressFraction >= 0.85f)
        PipelineStageRow("استخراج الصوت وتسجيله في مكتبة أصوات الهڨار", progressFraction >= 0.90f)
        PipelineStageRow("الفحص الآلي لسلامة المحتوى", progressFraction >= 0.95f)
      }
    }
  }
}

@Composable
private fun PipelineStageRow(label: String, isDone: Boolean) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(
      modifier = Modifier
        .size(16.dp)
        .clip(CircleShape)
        .background(if (isDone) HoggarColorTokens.SuccessOasis else HoggarColorTokens.SlateContainer),
      contentAlignment = Alignment.Center,
    ) {
      if (isDone) {
        Icon(imageVector = Icons.Filled.Check, contentDescription = null, tint = HoggarColorTokens.ObsidianBase, modifier = Modifier.size(11.dp))
      }
    }
    Spacer(modifier = Modifier.width(10.dp))
    Text(
      text = label,
      color = if (isDone) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextTertiary,
      fontSize = 12.sp,
    )
  }
}
