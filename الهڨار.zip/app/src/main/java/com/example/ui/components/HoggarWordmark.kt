package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HoggarColorTokens

enum class WordmarkSize {
  Small,
  Medium,
  Large,
  Hero
}

/**
 * Official Typographic Wordmark for «الهڨار»
 * Engineered with bold modern geometry and clean optical balance.
 */
@Composable
fun HoggarWordmark(
  modifier: Modifier = Modifier,
  size: WordmarkSize = WordmarkSize.Medium,
  showLatinSubtitle: Boolean = false,
  testTag: String = "hoggar_wordmark",
) {
  val fontSize: TextUnit = when (size) {
    WordmarkSize.Small -> 18.sp
    WordmarkSize.Medium -> 24.sp
    WordmarkSize.Large -> 32.sp
    WordmarkSize.Hero -> 44.sp
  }

  val subtitleSize: TextUnit = when (size) {
    WordmarkSize.Small -> 9.sp
    WordmarkSize.Medium -> 11.sp
    WordmarkSize.Large -> 13.sp
    WordmarkSize.Hero -> 15.sp
  }

  Column(
    modifier = modifier.testTag(testTag),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    Text(
      text = "الهڨار",
      color = HoggarColorTokens.TextPrimary,
      fontSize = fontSize,
      fontWeight = FontWeight.ExtraBold,
      fontFamily = FontFamily.SansSerif,
      letterSpacing = 0.5.sp,
    )

    if (showLatinSubtitle) {
      Text(
        text = "EL HOGGAR",
        color = HoggarColorTokens.TextSecondary,
        fontSize = subtitleSize,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.SansSerif,
        letterSpacing = 2.sp,
      )
    }
  }
}

/**
 * Combined Brand Lockup (Symbol + Wordmark)
 */
@Composable
fun HoggarBrandLockup(
  modifier: Modifier = Modifier,
  iconSize: Dp = 32.dp,
  wordmarkSize: WordmarkSize = WordmarkSize.Medium,
  showSubtitle: Boolean = false,
  testTag: String = "hoggar_brand_lockup",
) {
  Row(
    modifier = modifier.testTag(testTag),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.Center,
  ) {
    HoggarLogoMark(size = iconSize)
    Spacer(modifier = Modifier.width(10.dp))
    HoggarWordmark(size = wordmarkSize, showLatinSubtitle = showSubtitle)
  }
}
