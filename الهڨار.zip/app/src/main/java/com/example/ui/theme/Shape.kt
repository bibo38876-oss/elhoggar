package com.example.ui.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * Modern restrained geometric radii.
 * Not exaggerated, but sharp and purposeful.
 */
@Immutable
data class HoggarShapesTokens(
  val sharp: Shape = RoundedCornerShape(0.dp),
  val extraSmall: Shape = RoundedCornerShape(4.dp),
  val small: Shape = RoundedCornerShape(8.dp),
  val medium: Shape = RoundedCornerShape(12.dp),
  val large: Shape = RoundedCornerShape(16.dp),
  val extraLarge: Shape = RoundedCornerShape(24.dp),
  val pill: Shape = RoundedCornerShape(999.dp),
  val circular: Shape = CircleShape,
)

val LocalHoggarShapes = staticCompositionLocalOf { HoggarShapesTokens() }

val MaterialThemeShapes = Shapes(
  extraSmall = RoundedCornerShape(4.dp),
  small = RoundedCornerShape(8.dp),
  medium = RoundedCornerShape(12.dp),
  large = RoundedCornerShape(16.dp),
  extraLarge = RoundedCornerShape(24.dp),
)
