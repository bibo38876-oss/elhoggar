package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HoggarCard
import com.example.ui.components.HoggarTag
import com.example.ui.components.HoggarVerifiedBadge
import com.example.ui.theme.HoggarColorTokens

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DiscoverScreen(
  onSelectTag: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var searchQuery by remember { mutableStateOf("") }

  val trendingTags = listOf(
    "#الهڨار",
    "#قمة_تاهات",
    "#تمنراست",
    "#صناعة_الفضة",
    "#تيناريوين",
    "#أسكرام",
    "#شاي_صحراوي",
    "#طاسيلي_ناجر",
    "#موسيقى_الطيندي",
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .padding(horizontal = 16.dp),
  ) {
    Spacer(modifier = Modifier.height(12.dp))

    // Search Bar
    TextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp))
        .testTag("input_search"),
      placeholder = {
        Text(
          text = "ابحث عن صُنّاع المحتوى، الفيديوهات، والوسوم...",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 13.sp,
        )
      },
      leadingIcon = {
        Icon(
          imageVector = Icons.Filled.Search,
          contentDescription = "Search",
          tint = HoggarColorTokens.InteractiveAmber,
        )
      },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Clear",
            tint = HoggarColorTokens.TextSecondary,
            modifier = Modifier.clickable { searchQuery = "" },
          )
        }
      },
      singleLine = true,
      colors = TextFieldDefaults.colors(
        focusedContainerColor = HoggarColorTokens.SlateContainer,
        unfocusedContainerColor = HoggarColorTokens.SlateContainer,
        focusedTextColor = HoggarColorTokens.TextPrimary,
        unfocusedTextColor = HoggarColorTokens.TextPrimary,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
      ),
    )

    Spacer(modifier = Modifier.height(20.dp))

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
      // Trending Tags Section
      item {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.TrendingUp,
            contentDescription = null,
            tint = HoggarColorTokens.InteractiveAmber,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "الوسوم الأكثر رواجًا في الهڨار",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          trendingTags.forEach { tag ->
            HoggarTag(
              text = tag,
              isInteractive = true,
              modifier = Modifier.clickable {
                searchQuery = tag
                onSelectTag(tag)
              },
            )
          }
        }
      }

      // Featured Sahara Creators
      item {
        Text(
          text = "مبدعون ومستكشفون مقترحون",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          CreatorSuggestionItem(
            name = "مستكشف الهڨار",
            handle = "@hoggar_explorer",
            desc = "توثيق قمم وسهول الصحراء الكبرى",
            followers = "42.8K",
          )
          CreatorSuggestionItem(
            name = "حِرَف تمنراست",
            handle = "@tamanrasset_crafts",
            desc = "صياغة الفضة والنقوش التارقية",
            followers = "19.5K",
          )
          CreatorSuggestionItem(
            name = "إيقاعات الصحراء",
            handle = "@sahara_rhythms",
            desc = "جلسات الطيندي والجيتار الصحراوي",
            followers = "28.9K",
          )
        }
      }
    }
  }
}

@Composable
private fun CreatorSuggestionItem(
  name: String,
  handle: String,
  desc: String,
  followers: String,
) {
  HoggarCard(contentPadding = 12.dp) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(HoggarColorTokens.SlateContainer),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = name.take(1),
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = name,
              color = HoggarColorTokens.TextPrimary,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
            )
            Spacer(modifier = Modifier.width(4.dp))
            HoggarVerifiedBadge()
          }
          Text(
            text = handle,
            color = HoggarColorTokens.TextSecondary,
            fontSize = 12.sp,
          )
          Text(
            text = desc,
            color = HoggarColorTokens.TextTertiary,
            fontSize = 11.sp,
          )
        }
      }

      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(HoggarColorTokens.CopperPrimary)
          .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = "متابعة",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
        )
      }
    }
  }
}
