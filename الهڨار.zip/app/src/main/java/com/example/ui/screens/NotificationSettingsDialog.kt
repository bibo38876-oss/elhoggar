package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.interaction.model.NotificationPreferences
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.theme.HoggarColorTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationSettingsDialog(
  initialPreferences: NotificationPreferences,
  onSave: (NotificationPreferences) -> Unit,
  onDismiss: () -> Unit,
) {
  var preferences by remember { mutableStateOf(initialPreferences) }

  BasicAlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier
      .clip(RoundedCornerShape(16.dp))
      .background(HoggarColorTokens.BasaltSurface)
      .padding(20.dp),
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.NotificationsActive,
            contentDescription = null,
            tint = HoggarColorTokens.InteractiveAmber,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "إعدادات الإشعارات",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
          )
        }
        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Close",
            tint = HoggarColorTokens.TextSecondary,
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
      Text(
        text = "تحكم في أنواع التنبيهات الفورية التي ترغب في استلامها عبر المنصة:",
        color = HoggarColorTokens.TextSecondary,
        fontSize = 12.sp,
      )
      Spacer(modifier = Modifier.height(16.dp))

      // Switches
      NotificationToggleRow(
        title = "إشعارات الإعجابات",
        description = "تنبيه عند تفاعل المستخدمين مع فيديوهاتك",
        checked = preferences.likesEnabled,
        onCheckedChange = { preferences = preferences.copy(likesEnabled = it) },
      )

      NotificationToggleRow(
        title = "إشعارات التعليقات",
        description = "تنبيه عند إضافة تعليقات جديدة على منشوراتك",
        checked = preferences.commentsEnabled,
        onCheckedChange = { preferences = preferences.copy(commentsEnabled = it) },
      )

      NotificationToggleRow(
        title = "إشعارات الردود",
        description = "تنبيه عند الرد المباشر على تعليقاتك",
        checked = preferences.repliesEnabled,
        onCheckedChange = { preferences = preferences.copy(repliesEnabled = it) },
      )

      NotificationToggleRow(
        title = "المتابعات الجديدة",
        description = "تنبيه عندما يبدأ مستخدم جديد بمتابعتك",
        checked = preferences.followsEnabled,
        onCheckedChange = { preferences = preferences.copy(followsEnabled = it) },
      )

      NotificationToggleRow(
        title = "إشعارات المحتوى",
        description = "تنبيهات اعتماد المقاطع والوسوم الرائجة",
        checked = preferences.contentEnabled,
        onCheckedChange = { preferences = preferences.copy(contentEnabled = it) },
      )

      NotificationToggleRow(
        title = "إشعارات النظام والأمان",
        description = "تنبيهات تسجيل الدخول وتحديثات المنصة",
        checked = preferences.systemEnabled,
        onCheckedChange = { preferences = preferences.copy(systemEnabled = it) },
      )

      Spacer(modifier = Modifier.height(20.dp))

      HoggarButton(
        text = "حفظ التفضيلات",
        onClick = {
          onSave(preferences)
          onDismiss()
        },
        variant = HoggarButtonVariant.PrimaryCopper,
        modifier = Modifier.fillMaxWidth(),
      )
    }
  }
}

@Composable
private fun NotificationToggleRow(
  title: String,
  description: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        color = HoggarColorTokens.TextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
      )
      Text(
        text = description,
        color = HoggarColorTokens.TextTertiary,
        fontSize = 11.sp,
      )
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(
        checkedThumbColor = HoggarColorTokens.ObsidianBase,
        checkedTrackColor = HoggarColorTokens.InteractiveAmber,
        uncheckedThumbColor = HoggarColorTokens.TextTertiary,
        uncheckedTrackColor = HoggarColorTokens.SlateContainer,
      ),
    )
  }
}
