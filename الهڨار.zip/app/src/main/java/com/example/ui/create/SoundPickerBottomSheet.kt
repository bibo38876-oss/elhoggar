package com.example.ui.create

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.repository.SoundRepository
import com.example.model.SoundItem
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarEmptyState
import com.example.ui.theme.HoggarColorTokens

private enum class SoundFilterCategory(val label: String) {
  All("كل الأصوات"),
  Trending("الأكثر رواجاً 🔥"),
  Extracted("مستخرجة من الفيديوهات 🎬"),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundPickerBottomSheet(
  soundRepository: SoundRepository,
  currentSelectedSound: SoundItem?,
  sheetState: SheetState,
  onSoundSelected: (SoundItem?) -> Unit,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val allSounds by soundRepository.getAllSounds().collectAsState(initial = emptyList())
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf(SoundFilterCategory.All) }
  var previewPlayingSoundId by remember { mutableStateOf<String?>(null) }

  val filteredSounds = remember(allSounds, searchQuery, selectedCategory) {
    allSounds.filter { sound ->
      val matchesSearch = if (searchQuery.isBlank()) true else {
        val q = searchQuery.trim().lowercase()
        sound.title.lowercase().contains(q) ||
          sound.authorName.lowercase().contains(q) ||
          sound.authorUsername.lowercase().contains(q)
      }
      val matchesCategory = when (selectedCategory) {
        SoundFilterCategory.All -> true
        SoundFilterCategory.Trending -> sound.isTrending || sound.usageCount >= 1000
        SoundFilterCategory.Extracted -> sound.isExtractedFromVideo
      }
      matchesSearch && matchesCategory
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = HoggarColorTokens.BasaltSurface,
    contentColor = HoggarColorTokens.TextPrimary,
    dragHandle = {
      Box(
        modifier = Modifier
          .padding(vertical = 10.dp)
          .width(36.dp)
          .height(4.dp)
          .clip(RoundedCornerShape(2.dp))
          .background(HoggarColorTokens.SlateContainer),
      )
    },
    modifier = modifier.fillMaxHeight(0.85f),
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
    ) {
      // 1. Header Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "مكتبة أصوات الهڨار",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = "أصوات مستخرجة من فيديوهات المبدعين ومتاحة للجميع",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 11.sp,
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Close",
            tint = HoggarColorTokens.TextSecondary,
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 2. Search Bar
      TextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = {
          Text(
            text = "ابحث عن صوت أو صانع محتوى في الهڨار...",
            color = HoggarColorTokens.TextTertiary,
            fontSize = 13.sp,
          )
        },
        leadingIcon = {
          Icon(
            imageVector = Icons.Filled.Search,
            contentDescription = null,
            tint = HoggarColorTokens.TextSecondary,
          )
        },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Clear",
                tint = HoggarColorTokens.TextSecondary,
                modifier = Modifier.size(16.dp),
              )
            }
          }
        },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(14.dp))
          .testTag("input_search_sound"),
        colors = TextFieldDefaults.colors(
          focusedContainerColor = HoggarColorTokens.SlateContainer,
          unfocusedContainerColor = HoggarColorTokens.SlateContainer,
          focusedTextColor = HoggarColorTokens.TextPrimary,
          unfocusedTextColor = HoggarColorTokens.TextPrimary,
          focusedIndicatorColor = Color.Transparent,
          unfocusedIndicatorColor = Color.Transparent,
        ),
      )

      Spacer(modifier = Modifier.height(10.dp))

      // 3. Category Filter Chips
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth(),
      ) {
        items(SoundFilterCategory.entries.toTypedArray()) { cat ->
          val isSelected = selectedCategory == cat
          FilterChip(
            selected = isSelected,
            onClick = { selectedCategory = cat },
            label = {
              Text(
                text = cat.label,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = HoggarColorTokens.CopperPrimary,
              selectedLabelColor = HoggarColorTokens.TextPrimary,
              containerColor = HoggarColorTokens.SlateContainer,
              labelColor = HoggarColorTokens.TextSecondary,
            ),
            border = FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = isSelected,
              borderColor = if (isSelected) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.BorderSubtle,
            ),
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // 4. Reset to Original Sound Option
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(if (currentSelectedSound == null) HoggarColorTokens.SlateContainer else Color(0x33000000))
          .border(
            1.dp,
            if (currentSelectedSound == null) HoggarColorTokens.CopperPrimary else HoggarColorTokens.BorderSubtle,
            RoundedCornerShape(12.dp),
          )
          .clickable {
            onSoundSelected(null)
            onDismiss()
          }
          .padding(horizontal = 14.dp, vertical = 10.dp)
          .testTag("btn_keep_original_sound"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(HoggarColorTokens.BasaltSurface),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.MusicNote,
              contentDescription = null,
              tint = if (currentSelectedSound == null) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextSecondary,
              modifier = Modifier.size(18.dp),
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = "الصوت الأصلي للفيديو",
              color = HoggarColorTokens.TextPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text = "الاحتفاظ بالصوت المسجل أثناء التقاط الفيديو",
              color = HoggarColorTokens.TextTertiary,
              fontSize = 11.sp,
            )
          }
        }
        if (currentSelectedSound == null) {
          Icon(
            imageVector = Icons.Filled.Check,
            contentDescription = "Selected",
            tint = HoggarColorTokens.InteractiveAmber,
            modifier = Modifier.size(18.dp),
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 5. Sound List
      if (filteredSounds.isEmpty()) {
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          contentAlignment = Alignment.Center,
        ) {
          HoggarEmptyState(
            title = "لا توجد أصوات مطابقة",
            description = "جرب البحث بكلمات أخرى أو اختر فئة مختلفة.",
          )
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(filteredSounds, key = { it.id }) { sound ->
            val isSelected = currentSelectedSound?.id == sound.id
            val isPlayingPreview = previewPlayingSoundId == sound.id

            SoundItemCard(
              sound = sound,
              isSelected = isSelected,
              isPlayingPreview = isPlayingPreview,
              onTogglePreview = {
                previewPlayingSoundId = if (isPlayingPreview) null else sound.id
              },
              onSelect = {
                onSoundSelected(sound)
                onDismiss()
              },
            )
          }
          item { Spacer(modifier = Modifier.height(16.dp)) }
        }
      }
    }
  }
}

@Composable
private fun SoundItemCard(
  sound: SoundItem,
  isSelected: Boolean,
  isPlayingPreview: Boolean,
  onTogglePreview: () -> Unit,
  onSelect: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val discTransition = rememberInfiniteTransition(label = "disc_anim")
  val rotation by discTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(4000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "disc_rotation",
  )

  Row(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(if (isSelected) HoggarColorTokens.SlateContainer else HoggarColorTokens.BasaltSurface)
      .border(
        1.dp,
        if (isSelected) HoggarColorTokens.CopperPrimary else HoggarColorTokens.BorderSubtle,
        RoundedCornerShape(14.dp),
      )
      .padding(12.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    // Disc / Cover with preview toggle button
    Box(
      modifier = Modifier
        .size(46.dp)
        .clip(CircleShape)
        .background(HoggarColorTokens.SlateContainer)
        .border(1.5.dp, HoggarColorTokens.CopperPrimary, CircleShape)
        .rotate(if (isPlayingPreview) rotation else 0f)
        .clickable(onClick = onTogglePreview),
      contentAlignment = Alignment.Center,
    ) {
      if (sound.coverUrl.isNotEmpty()) {
        AsyncImage(
          model = sound.coverUrl,
          contentDescription = null,
          modifier = Modifier.fillMaxSize().clip(CircleShape),
        )
      }
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color(0x55000000)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = if (isPlayingPreview) Icons.Filled.Pause else Icons.Filled.PlayArrow,
          contentDescription = if (isPlayingPreview) "Pause" else "Play",
          tint = HoggarColorTokens.TextPrimary,
          modifier = Modifier.size(20.dp),
        )
      }
    }

    Spacer(modifier = Modifier.width(12.dp))

    // Sound Info
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = sound.title,
        color = HoggarColorTokens.TextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = sound.authorName.ifEmpty { "@${sound.authorUsername}" },
        color = HoggarColorTokens.TextSecondary,
        fontSize = 11.sp,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "${sound.usageCount} مقطع فيديو",
          color = HoggarColorTokens.InteractiveAmber,
          fontSize = 10.sp,
          fontWeight = FontWeight.SemiBold,
        )
        if (sound.isExtractedFromVideo) {
          Spacer(modifier = Modifier.width(6.dp))
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(Color(0x33FF6926))
              .padding(horizontal = 4.dp, vertical = 1.dp),
          ) {
            Text(
              text = "مستخرج من فيديو",
              color = HoggarColorTokens.InteractiveAmber,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.width(10.dp))

    // Select CTA Button
    HoggarButton(
      text = if (isSelected) "مختار" else "استخدام",
      icon = if (isSelected) Icons.Filled.Check else Icons.Filled.MusicNote,
      onClick = onSelect,
      variant = if (isSelected) HoggarButtonVariant.Outlined else HoggarButtonVariant.PrimaryCopper,
      modifier = Modifier.height(34.dp).testTag("btn_select_sound_${sound.id}"),
    )
  }
}
