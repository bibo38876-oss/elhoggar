package com.example.ui.interaction

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VideoItem
import com.example.ui.theme.HoggarColorTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareBottomSheet(
  video: VideoItem,
  shareUrl: String,
  sheetState: SheetState,
  onDismiss: () -> Unit,
  onShareCompleted: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = HoggarColorTokens.BasaltSurface,
    contentColor = HoggarColorTokens.TextPrimary,
    dragHandle = {
      Box(
        modifier = Modifier
          .padding(vertical = 10.dp)
          .width(36.dp)
          .height(4.dp)
          .clip(RoundedCornerShape(2.dp))
          .background(HoggarColorTokens.SlateContainer),
      )
    },
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
      Text(
        text = "مشاركة الفيديو",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Share Link Card with Copy Action
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(HoggarColorTokens.SlateContainer)
          .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
          .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = shareUrl,
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
          )
          Text(
            text = "رابط فيديو عمودي عميق (Deep Link)",
            color = HoggarColorTokens.TextTertiary,
            fontSize = 10.sp,
          )
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(HoggarColorTokens.CopperPrimary)
            .clickable {
              val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
              val clip = ClipData.newPlainText("El Hoggar Video", shareUrl)
              clipboard.setPrimaryClip(clip)
              Toast.makeText(context, "تم نسخ الرابط إلى الحافظة", Toast.LENGTH_SHORT).show()
              onShareCompleted()
              onDismiss()
            }
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("btn_copy_link"),
          contentAlignment = Alignment.Center,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = HoggarColorTokens.TextPrimary, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "نسخ", color = HoggarColorTokens.TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Native Android Share Sheet Trigger
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(HoggarColorTokens.SlateHover)
          .clickable {
            val intent = Intent(Intent.ACTION_SEND).apply {
              type = "text/plain"
              putExtra(Intent.EXTRA_SUBJECT, video.title)
              putExtra(
                Intent.EXTRA_TEXT,
                "${video.title}\nشاهد هذا الفيديو الرائع على منصة «الهڨار»:\n$shareUrl",
              )
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة فيديو الهڨار عبر"))
            onShareCompleted()
            onDismiss()
          }
          .padding(14.dp)
          .testTag("btn_android_sharesheet"),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(HoggarColorTokens.InteractiveAmber),
          contentAlignment = Alignment.Center,
        ) {
          Icon(Icons.Filled.Share, contentDescription = null, tint = HoggarColorTokens.ObsidianBase, modifier = Modifier.size(18.dp))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Text(text = "مشاركة عبر التطبيقات الأخرى", color = HoggarColorTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text(text = "واتساب، ماسنجر، تيليغرام، وتطبيقات التواصل", color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
        }
      }

      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}
