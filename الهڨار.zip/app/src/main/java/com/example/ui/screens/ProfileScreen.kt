package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarEmptyState
import com.example.ui.components.HoggarLogoMark
import com.example.ui.components.HoggarVerifiedBadge
import com.example.ui.theme.HoggarColorTokens

@Composable
fun ProfileScreen(
  onOpenDesignSystem: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedTab by remember { mutableIntStateOf(0) } // 0: Videos, 1: Liked, 2: Saved

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .padding(horizontal = 16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Spacer(modifier = Modifier.height(16.dp))

    // Profile Avatar with Hoggar Copper Ring
    Box(
      modifier = Modifier
        .size(88.dp)
        .clip(CircleShape)
        .background(HoggarColorTokens.BasaltSurface)
        .border(2.dp, HoggarColorTokens.CopperPrimary, CircleShape),
      contentAlignment = Alignment.Center,
    ) {
      HoggarLogoMark(size = 48.dp)
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Name & Handle
    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = "مبدع الهڨار",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
      )
      Spacer(modifier = Modifier.width(6.dp))
      HoggarVerifiedBadge()
    }

    Text(
      text = "@creator_hoggar",
      color = HoggarColorTokens.TextSecondary,
      fontSize = 13.sp,
    )

    Spacer(modifier = Modifier.height(16.dp))

    // Metrics Row (Following, Followers, Likes)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      ProfileMetric(count = "128", label = "أتابعه")
      Box(
        modifier = Modifier
          .width(1.dp)
          .height(24.dp)
          .background(HoggarColorTokens.BorderSubtle),
      )
      ProfileMetric(count = "24.5K", label = "المتابعون")
      Box(
        modifier = Modifier
          .width(1.dp)
          .height(24.dp)
          .background(HoggarColorTokens.BorderSubtle),
      )
      ProfileMetric(count = "182K", label = "الإعجابات")
    }

    Spacer(modifier = Modifier.height(18.dp))

    // Profile Actions: Edit Profile & Design System Spec Guide
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      HoggarButton(
        text = "تعديل الملف",
        onClick = {},
        variant = HoggarButtonVariant.Outlined,
        modifier = Modifier.weight(1f),
      )

      HoggarButton(
        text = "دليل الهوية",
        onClick = onOpenDesignSystem,
        variant = HoggarButtonVariant.PrimaryCopper,
        icon = Icons.Filled.Palette,
        modifier = Modifier.weight(1f).testTag("btn_open_design_system"),
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Profile Content Tabs (فيديوهاتي، المعجب بها، المحفوظات)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .border(0.dp, Color.Transparent)
        .background(HoggarColorTokens.SlateContainer, RoundedCornerShape(10.dp))
        .padding(4.dp),
      horizontalArrangement = Arrangement.SpaceAround,
    ) {
      ProfileTabButton(
        title = "الفيديوهات",
        isSelected = selectedTab == 0,
        onClick = { selectedTab = 0 },
      )
      ProfileTabButton(
        title = "المعجب بها",
        isSelected = selectedTab == 1,
        onClick = { selectedTab = 1 },
      )
      ProfileTabButton(
        title = "المحفوظات",
        isSelected = selectedTab == 2,
        onClick = { selectedTab = 2 },
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Empty state under profile tab
    HoggarEmptyState(
      title = when (selectedTab) {
        0 -> "لم تنشر أي فيديو بعد"
        1 -> "قائمة الفيديوهات المعجب بها فارغة"
        else -> "لا توجد عناصر محفوظة"
      },
      description = "قم بتسجيل ونشر أول فيديو عمودي لك في الهڨار وشارك لحظاتك مع العالم.",
      actionText = "إنشاء فيديو جديد",
      onActionClick = {},
    )
  }
}

@Composable
private fun ProfileMetric(count: String, label: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = count,
      color = HoggarColorTokens.TextPrimary,
      fontSize = 16.sp,
      fontWeight = FontWeight.Bold,
    )
    Text(
      text = label,
      color = HoggarColorTokens.TextSecondary,
      fontSize = 12.sp,
    )
  }
}

@Composable
private fun ProfileTabButton(title: String, isSelected: Boolean, onClick: () -> Unit) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .background(if (isSelected) HoggarColorTokens.CopperPrimary else Color.Transparent)
      .clickable(onClick = onClick)
      .padding(horizontal = 16.dp, vertical = 8.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = title,
      color = if (isSelected) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
      fontSize = 13.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
    )
  }
}
