package com.example.ui.feed

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.CreatorModel
import com.example.model.VideoItem
import com.example.player.VideoPlayerManager
import com.example.recommendation.engine.InteractionSignal
import com.example.recommendation.model.FeedCursor
import com.example.recommendation.model.FeedItem
import com.example.recommendation.model.FeedItemReason
import com.example.recommendation.model.FeedRequest
import com.example.recommendation.model.NetworkQuality
import com.example.recommendation.model.RecommendationContext
import com.example.recommendation.model.WatchEvent
import com.example.recommendation.repository.RecommendationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

sealed interface FeedUiState {
  data object Loading : FeedUiState
  data class Success(
    val items: List<FeedItem>,
    val cursor: FeedCursor,
    val isLoadingMore: Boolean = false,
  ) : FeedUiState {
    val videos: List<VideoItem> get() = items.map { it.video }
  }
  data class Error(val message: String, val isNetworkError: Boolean = false) : FeedUiState
  data object Empty : FeedUiState
}

class FeedViewModel(
  private val recommendationRepository: RecommendationRepository,
  val playerManager: VideoPlayerManager,
) : ViewModel() {

  private val _uiState = MutableStateFlow<FeedUiState>(FeedUiState.Loading)
  val uiState: StateFlow<FeedUiState> = _uiState.asStateFlow()

  private val _activePageIndex = MutableStateFlow(0)
  val activePageIndex: StateFlow<Int> = _activePageIndex.asStateFlow()

  private val _isFollowingTab = MutableStateFlow(false) // false = For You, true = Following
  val isFollowingTab: StateFlow<Boolean> = _isFollowingTab.asStateFlow()

  // Track start time of active video for calculating accurate WatchEvent telemetry
  private var activeVideoStartTimeMs: Long = System.currentTimeMillis()
  private var activeVideoId: String? = null

  init {
    loadFeed()
  }

  fun loadFeed() {
    viewModelScope.launch {
      _uiState.value = FeedUiState.Loading
      val request = FeedRequest(
        userId = "user_me",
        cursor = null,
        pageSize = 6,
        context = RecommendationContext(
          preferredTags = listOf("#الهڨار", "#تاهات"),
          networkQuality = recommendationRepository.networkQuality.value,
        ),
      )

      recommendationRepository.getFeedPage(request)
        .catch { e ->
          _uiState.value = FeedUiState.Error(
            message = e.message ?: "فشل تحميل الخلاصة",
            isNetworkError = true,
          )
        }
        .collect { result ->
          result.onSuccess { page ->
            if (page.items.isEmpty()) {
              _uiState.value = FeedUiState.Empty
            } else {
              _uiState.value = FeedUiState.Success(
                items = page.items,
                cursor = page.cursor,
                isLoadingMore = false,
              )

              // Start playing first video
              val first = page.items.firstOrNull()?.video
              if (first != null) {
                activeVideoId = first.id
                activeVideoStartTimeMs = System.currentTimeMillis()
                playerManager.playVideo(first.id, first.videoUrl)

                // SMART PREFETCH: Preload ONLY the immediate next video
                if (page.items.size > 1) {
                  val next = page.items[1].video
                  playerManager.preloadVideo(next.id, next.videoUrl)
                }
              }
            }
          }.onFailure { e ->
            _uiState.value = FeedUiState.Error(e.message ?: "فشل الاتصال بالخادم", isNetworkError = true)
          }
        }
    }
  }

  /**
   * Loads next page when user scrolls near the end of current feed list.
   */
  fun loadNextPage() {
    val currentState = _uiState.value
    if (currentState !is FeedUiState.Success || !currentState.cursor.hasMore || currentState.isLoadingMore) {
      return
    }

    _uiState.value = currentState.copy(isLoadingMore = true)

    viewModelScope.launch {
      val request = FeedRequest(
        userId = "user_me",
        cursor = currentState.cursor.nextCursor,
        pageSize = 5,
        context = RecommendationContext(
          preferredTags = listOf("#الهڨار", "#تاهات"),
          networkQuality = recommendationRepository.networkQuality.value,
          recentWatchedIds = currentState.items.map { it.video.id },
        ),
      )

      recommendationRepository.getFeedPage(request).collect { result ->
        result.onSuccess { page ->
          val combined = currentState.items + page.items
          _uiState.value = FeedUiState.Success(
            items = combined,
            cursor = page.cursor,
            isLoadingMore = false,
          )
        }.onFailure {
          _uiState.value = currentState.copy(isLoadingMore = false)
        }
      }
    }
  }

  /**
   * Called when VerticalPager settles on a new page.
   * Records telemetry WatchEvent for the previous video and preloads only the next video.
   */
  fun onPageChanged(newIndex: Int) {
    val currentState = _uiState.value
    if (currentState is FeedUiState.Success) {
      val items = currentState.items
      if (newIndex in items.indices) {
        val previousVideoId = activeVideoId
        val previousStartTime = activeVideoStartTimeMs

        // 1. Record WatchEvent for the departed video
        if (previousVideoId != null) {
          val watchDuration = (System.currentTimeMillis() - previousStartTime).coerceAtLeast(0L)
          val prevVideo = items.firstOrNull { it.video.id == previousVideoId }?.video
          val totalDurationMs = ((prevVideo?.durationSeconds ?: 60) * 1000L).coerceAtLeast(1000L)
          val completionRate = (watchDuration.toFloat() / totalDurationMs).coerceIn(0f, 2f)

          recommendationRepository.recordWatchEvent(
            WatchEvent(
              videoId = previousVideoId,
              watchDurationMs = watchDuration,
              completionRate = completionRate,
              isSkippedQuickly = watchDuration < 2000L,
              isReplayed = completionRate >= 1.0f,
              videoTags = prevVideo?.tags ?: emptyList(),
              creatorId = prevVideo?.creator?.id ?: "",
              soundTitle = prevVideo?.soundTitle ?: "",
            ),
          )
        }

        // 2. Activate playback for the new video
        _activePageIndex.value = newIndex
        val currentVideo = items[newIndex].video
        activeVideoId = currentVideo.id
        activeVideoStartTimeMs = System.currentTimeMillis()

        playerManager.playVideo(currentVideo.id, currentVideo.videoUrl)

        // 3. SMART PREFETCH: Preload ONLY the immediate next video (conservative bandwidth)
        if (newIndex + 1 < items.size) {
          val next = items[newIndex + 1].video
          playerManager.preloadVideo(next.id, next.videoUrl)
        }

        // 4. Cursor Pagination trigger: fetch more items when nearing bottom (2 items left)
        if (newIndex >= items.size - 2) {
          loadNextPage()
        }
      }
    }
  }

  fun toggleLike(video: VideoItem) {
    recommendationRepository.recordInteraction(
      videoId = video.id,
      type = InteractionSignal.Like,
      tags = video.tags,
      creatorId = video.creator.id,
    )
    viewModelScope.launch {
      val currentState = _uiState.value
      if (currentState is FeedUiState.Success) {
        val updated = currentState.items.map { item ->
          if (item.video.id == video.id) {
            val newLiked = !item.video.isLiked
            val newCount = if (newLiked) item.video.stats.likesCount + 1 else item.video.stats.likesCount - 1
            item.copy(
              video = item.video.copy(
                isLiked = newLiked,
                stats = item.video.stats.copy(likesCount = newCount),
              ),
            )
          } else {
            item
          }
        }
        _uiState.value = currentState.copy(items = updated)
      }
    }
  }

  fun toggleBookmark(video: VideoItem) {
    recommendationRepository.recordInteraction(
      videoId = video.id,
      type = InteractionSignal.Bookmark,
      tags = video.tags,
      creatorId = video.creator.id,
    )
    viewModelScope.launch {
      val currentState = _uiState.value
      if (currentState is FeedUiState.Success) {
        val updated = currentState.items.map { item ->
          if (item.video.id == video.id) {
            item.copy(video = item.video.copy(isBookmarked = !item.video.isBookmarked))
          } else {
            item
          }
        }
        _uiState.value = currentState.copy(items = updated)
      }
    }
  }

  fun toggleFollow(creator: CreatorModel) {
    recommendationRepository.recordInteraction(
      videoId = "",
      type = InteractionSignal.Follow,
      tags = emptyList(),
      creatorId = creator.id,
    )
    viewModelScope.launch {
      val currentState = _uiState.value
      if (currentState is FeedUiState.Success) {
        val updated = currentState.items.map { item ->
          if (item.video.creator.id == creator.id) {
            item.copy(video = item.video.copy(isFollowing = !item.video.isFollowing))
          } else {
            item
          }
        }
        _uiState.value = currentState.copy(items = updated)
      }
    }
  }

  fun markNotInterested(video: VideoItem) {
    recommendationRepository.recordInteraction(
      videoId = video.id,
      type = InteractionSignal.NotInterested,
      tags = video.tags,
      creatorId = video.creator.id,
    )
    viewModelScope.launch {
      val currentState = _uiState.value
      if (currentState is FeedUiState.Success) {
        val updated = currentState.items.filter { it.video.id != video.id }
        if (updated.isEmpty()) {
          _uiState.value = FeedUiState.Empty
        } else {
          _uiState.value = currentState.copy(items = updated)
          val newIndex = _activePageIndex.value.coerceIn(0, updated.lastIndex)
          _activePageIndex.value = newIndex
          val nextVideo = updated[newIndex].video
          playerManager.playVideo(nextVideo.id, nextVideo.videoUrl)
        }
      }
    }
  }

  fun blockCreator(creatorId: String) {
    recommendationRepository.recordInteraction(
      videoId = "",
      type = InteractionSignal.Block,
      tags = emptyList(),
      creatorId = creatorId,
    )
    viewModelScope.launch {
      val currentState = _uiState.value
      if (currentState is FeedUiState.Success) {
        val updated = currentState.items.filter { it.video.creator.id != creatorId }
        if (updated.isEmpty()) {
          _uiState.value = FeedUiState.Empty
        } else {
          _uiState.value = currentState.copy(items = updated)
          val newIndex = _activePageIndex.value.coerceIn(0, updated.lastIndex)
          _activePageIndex.value = newIndex
          val nextVideo = updated[newIndex].video
          playerManager.playVideo(nextVideo.id, nextVideo.videoUrl)
        }
      }
    }
  }

  fun selectFeedTab(isFollowing: Boolean) {
    _isFollowingTab.value = isFollowing
    if (isFollowing) {
      loadFollowingFeed()
    } else {
      loadFeed()
    }
  }

  fun loadFollowingFeed() {
    viewModelScope.launch {
      recommendationRepository.getFollowingFeed("user_me").collect { videos ->
        if (videos.isNotEmpty()) {
          val feedItems = videos.map { video ->
            FeedItem(
              video = video,
              score = 100.0,
              reason = FeedItemReason.FollowedCreator,
            )
          }
          _uiState.value = FeedUiState.Success(
            items = feedItems,
            cursor = FeedCursor(null, false),
            isLoadingMore = false,
          )
        }
      }
    }
  }

  fun onAppPause() {
    playerManager.pauseActiveVideo()
  }

  fun onAppResume() {
    playerManager.resumeActiveVideo()
  }

  override fun onCleared() {
    super.onCleared()
    playerManager.releaseAll()
  }
}
