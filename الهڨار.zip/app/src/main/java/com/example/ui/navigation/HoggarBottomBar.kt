package com.example.ui.navigation

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NavigationTab
import com.example.ui.components.HoggarLogoMark
import com.example.ui.theme.HoggarColorTokens

@Composable
fun HoggarBottomBar(
  currentTab: NavigationTab,
  onTabSelected: (NavigationTab) -> Unit,
  modifier: Modifier = Modifier,
  isArabic: Boolean = true,
) {
  val navBarBottomPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  Surface(
    color = HoggarColorTokens.ObsidianBase.copy(alpha = 0.95f),
    modifier = modifier
      .fillMaxWidth()
      .border(BorderStroke(1.dp, HoggarColorTokens.BorderSubtle)),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(
          top = 8.dp,
          bottom = navBarBottomPadding + 4.dp,
          start = 12.dp,
          end = 12.dp,
        ),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      // 1. Home Tab
      BottomNavItem(
        tab = NavigationTab.Home,
        isSelected = currentTab == NavigationTab.Home,
        onClick = { onTabSelected(NavigationTab.Home) },
        isArabic = isArabic,
      )

      // 2. Posts Tab (المنشورات الكتابية والتغريدات)
      BottomNavItem(
        tab = NavigationTab.Posts,
        isSelected = currentTab == NavigationTab.Posts,
        onClick = { onTabSelected(NavigationTab.Posts) },
        isArabic = isArabic,
      )

      // 3. Center Create Video Camera Crest
      Box(
        modifier = Modifier
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = ripple(bounded = false, radius = 28.dp),
            onClick = { onTabSelected(NavigationTab.Create) },
          )
          .minimumInteractiveComponentSize()
          .testTag("nav_btn_create"),
        contentAlignment = Alignment.Center,
      ) {
        Box(
          modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(HoggarColorTokens.CopperPrimary),
          contentAlignment = Alignment.Center,
        ) {
          HoggarLogoMark(size = 24.dp)
        }
      }

      // 4. Activity Tab
      BottomNavItem(
        tab = NavigationTab.Activity,
        isSelected = currentTab == NavigationTab.Activity,
        onClick = { onTabSelected(NavigationTab.Activity) },
        isArabic = isArabic,
      )

      // 5. Profile Tab
      BottomNavItem(
        tab = NavigationTab.Profile,
        isSelected = currentTab == NavigationTab.Profile,
        onClick = { onTabSelected(NavigationTab.Profile) },
        isArabic = isArabic,
      )
    }
  }
}

@Composable
private fun BottomNavItem(
  tab: NavigationTab,
  isSelected: Boolean,
  onClick: () -> Unit,
  isArabic: Boolean,
) {
  val iconColor by animateColorAsState(
    targetValue = if (isSelected) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
    label = "nav_icon_color",
  )
  val textColor by animateColorAsState(
    targetValue = if (isSelected) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextSecondary,
    label = "nav_text_color",
  )

  Column(
    modifier = Modifier
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = ripple(bounded = false, radius = 24.dp),
        onClick = onClick,
      )
      .minimumInteractiveComponentSize()
      .padding(horizontal = 8.dp, vertical = 4.dp)
      .testTag("nav_tab_${tab.route}"),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Icon(
      imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
      contentDescription = if (isArabic) tab.labelAr else tab.labelEn,
      tint = iconColor,
      modifier = Modifier.size(24.dp),
    )

    Spacer(modifier = Modifier.height(3.dp))

    Text(
      text = if (isArabic) tab.labelAr else tab.labelEn,
      color = textColor,
      fontSize = 11.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
    )
  }
}
