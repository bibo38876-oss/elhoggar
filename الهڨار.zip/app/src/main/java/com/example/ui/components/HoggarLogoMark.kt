package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.HoggarColorTokens

/**
 * El Hoggar Geometric Emblem
 * Precision vector rendering of the Amazigh Saharan talismanic lozenge.
 * Formed by central faceted diamond, flanking aerodynamic wings, and inner aperture.
 */
@Composable
fun HoggarLogoMark(
  modifier: Modifier = Modifier,
  size: Dp = 48.dp,
  showGlow: Boolean = false,
  isPulsing: Boolean = false,
  testTag: String = "hoggar_logo_mark",
) {
  val infiniteTransition = rememberInfiniteTransition(label = "hoggar_mark_transition")
  val pulseScale by if (isPulsing) {
    infiniteTransition.animateFloat(
      initialValue = 0.96f,
      targetValue = 1.04f,
      animationSpec = infiniteRepeatable(
        animation = tween(1200, easing = FastOutSlowInEasing),
        repeatMode = RepeatMode.Reverse,
      ),
      label = "pulse_scale",
    )
  } else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
  }

  val glowAlpha by if (showGlow) {
    infiniteTransition.animateFloat(
      initialValue = 0.25f,
      targetValue = 0.55f,
      animationSpec = infiniteRepeatable(
        animation = tween(1600, easing = FastOutSlowInEasing),
        repeatMode = RepeatMode.Reverse,
      ),
      label = "glow_alpha",
    )
  } else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
  }

  Box(
    modifier = modifier
      .size(size)
      .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    Canvas(
      modifier = Modifier
        .size(size * pulseScale),
    ) {
      val w = this.size.width
      val h = this.size.height

      // Optional ambient glow behind the mark
      if (showGlow) {
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(
              HoggarColorTokens.InteractiveAmber.copy(alpha = glowAlpha),
              Color.Transparent,
            ),
            center = Offset(w * 0.5f, h * 0.5f),
            radius = w * 0.65f,
          ),
          center = Offset(w * 0.5f, h * 0.5f),
          radius = w * 0.65f,
        )
      }

      // Left Main Diamond Facet (Deep Burnished Copper)
      val leftFacet = Path().apply {
        moveTo(w * 0.50f, h * 0.08f)
        lineTo(w * 0.33f, h * 0.50f)
        lineTo(w * 0.50f, h * 0.92f)
        close()
      }
      drawPath(
        path = leftFacet,
        brush = Brush.linearGradient(
          colors = listOf(HoggarColorTokens.CopperDark, HoggarColorTokens.CopperPrimary),
          start = Offset(w * 0.33f, h * 0.50f),
          end = Offset(w * 0.50f, h * 0.50f),
        ),
      )

      // Right Main Diamond Facet (Sunlit Copper / Dynamic Sheen)
      val rightFacet = Path().apply {
        moveTo(w * 0.50f, h * 0.08f)
        lineTo(w * 0.67f, h * 0.50f)
        lineTo(w * 0.50f, h * 0.92f)
        close()
      }
      drawPath(
        path = rightFacet,
        brush = Brush.linearGradient(
          colors = listOf(HoggarColorTokens.CopperLight, HoggarColorTokens.CopperPrimary),
          start = Offset(w * 0.50f, h * 0.50f),
          end = Offset(w * 0.67f, h * 0.50f),
        ),
      )

      // Left Flanking Geometric Wing (Amazigh talisman chevron)
      val leftWing = Path().apply {
        moveTo(w * 0.22f, h * 0.25f)
        lineTo(w * 0.30f, h * 0.40f)
        lineTo(w * 0.26f, h * 0.68f)
        lineTo(w * 0.17f, h * 0.52f)
        close()
      }
      drawPath(
        path = leftWing,
        brush = Brush.linearGradient(
          colors = listOf(HoggarColorTokens.InteractiveAmber, HoggarColorTokens.CopperDark),
          start = Offset(w * 0.17f, h * 0.25f),
          end = Offset(w * 0.30f, h * 0.68f),
        ),
      )

      // Right Flanking Geometric Wing (Amazigh talisman chevron)
      val rightWing = Path().apply {
        moveTo(w * 0.78f, h * 0.25f)
        lineTo(w * 0.83f, h * 0.52f)
        lineTo(w * 0.74f, h * 0.68f)
        lineTo(w * 0.70f, h * 0.40f)
        close()
      }
      drawPath(
        path = rightWing,
        brush = Brush.linearGradient(
          colors = listOf(HoggarColorTokens.CopperLight, HoggarColorTokens.CopperDark),
          start = Offset(w * 0.70f, h * 0.25f),
          end = Offset(w * 0.83f, h * 0.68f),
        ),
      )

      // Center Diamond Aperture (Negative Space Silhouette)
      val innerAperture = Path().apply {
        moveTo(w * 0.50f, h * 0.33f)
        lineTo(w * 0.61f, h * 0.50f)
        lineTo(w * 0.50f, h * 0.67f)
        lineTo(w * 0.39f, h * 0.50f)
        close()
      }
      drawPath(
        path = innerAperture,
        color = HoggarColorTokens.ObsidianBase,
      )

      // Center Glowing Seed Diamond (Focal Point / Lens)
      val centerSeed = Path().apply {
        moveTo(w * 0.50f, h * 0.42f)
        lineTo(w * 0.56f, h * 0.50f)
        lineTo(w * 0.50f, h * 0.58f)
        lineTo(w * 0.44f, h * 0.50f)
        close()
      }
      drawPath(
        path = centerSeed,
        brush = Brush.linearGradient(
          colors = listOf(HoggarColorTokens.InteractiveAmber, HoggarColorTokens.CopperLight),
          start = Offset(w * 0.44f, h * 0.42f),
          end = Offset(w * 0.56f, h * 0.58f),
        ),
      )

      // Subtle Precision Fine Hairline Highlights
      drawPath(
        path = leftFacet,
        color = Color(0x33FFFFFF),
        style = Stroke(width = 0.75.dp.toPx()),
      )
      drawPath(
        path = rightFacet,
        color = Color(0x33FFFFFF),
        style = Stroke(width = 0.75.dp.toPx()),
      )
    }
  }
}
