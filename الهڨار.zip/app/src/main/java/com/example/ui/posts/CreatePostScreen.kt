package com.example.ui.posts

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.repository.PostRepository
import com.example.model.CreatorModel
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.theme.HoggarColorTokens
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreatePostScreen(
  currentUser: CreatorModel,
  postRepository: PostRepository,
  onBack: () -> Unit,
  onPostCreated: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val scope = rememberCoroutineScope()
  var postText by remember { mutableStateOf("") }
  var isSubmitting by remember { mutableStateOf(false) }
  val attachedImages = remember { mutableStateListOf<String>() }

  // Multi-image picker launcher
  val imagePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 4),
  ) { uris ->
    uris.forEach { uri ->
      if (!attachedImages.contains(uri.toString()) && attachedImages.size < 4) {
        attachedImages.add(uri.toString())
      }
    }
  }

  val maxChars = 320
  val remainingChars = maxChars - postText.length
  val canPost = postText.trim().isNotEmpty() || attachedImages.isNotEmpty()

  val suggestedTags = listOf(
    "#الهڨار",
    "#تمنراست",
    "#أسكرام",
    "#تيناريوين",
    "#طاسيلي",
    "#صناعة_الفضة",
    "#سياحة_صحراوية",
    "#ثقافة_تارقية",
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .padding(horizontal = 16.dp)
      .testTag("create_post_screen"),
  ) {
    // 1. Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onBack,
          modifier = Modifier.testTag("btn_close_create_post"),
        ) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Close",
            tint = HoggarColorTokens.TextPrimary,
          )
        }
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = "منشور جديد",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
        )
      }

      // Publish Button
      if (isSubmitting) {
        CircularProgressIndicator(
          color = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(28.dp),
          strokeWidth = 2.5.dp,
        )
      } else {
        HoggarButton(
          text = "نشر المنشور",
          onClick = {
            if (canPost && !isSubmitting) {
              isSubmitting = true
              scope.launch {
                postRepository.createPost(
                  author = currentUser,
                  text = postText.trim(),
                  imageUrls = attachedImages.toList(),
                )
                isSubmitting = false
                onPostCreated()
              }
            }
          },
          enabled = canPost && remainingChars >= 0,
          variant = HoggarButtonVariant.PrimaryCopper,
          modifier = Modifier.testTag("btn_submit_post"),
        )
      }
    }

    // Scrollable input content
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState()),
    ) {
      Spacer(modifier = Modifier.height(10.dp))

      // User avatar + username banner
      Row(verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(
          model = currentUser.avatarUrl.ifEmpty { "https://picsum.photos/seed/user_avatar/200/200" },
          contentDescription = currentUser.displayName,
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .border(1.5.dp, HoggarColorTokens.CopperPrimary, CircleShape),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = currentUser.displayName,
            color = HoggarColorTokens.TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = "@${currentUser.username}",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 12.sp,
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Main Text Input Area
      TextField(
        value = postText,
        onValueChange = { postText = it },
        placeholder = {
          Text(
            text = "شارك أفكارك، قصصك، وتجاربك مع مجتمع الهڨار والجنوب... (يمكنك إرفاق صور والوسوم #)",
            color = HoggarColorTokens.TextTertiary,
            fontSize = 15.sp,
          )
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(180.dp)
          .testTag("input_post_text"),
        colors = TextFieldDefaults.colors(
          focusedContainerColor = Color.Transparent,
          unfocusedContainerColor = Color.Transparent,
          focusedTextColor = HoggarColorTokens.TextPrimary,
          unfocusedTextColor = HoggarColorTokens.TextPrimary,
          focusedIndicatorColor = Color.Transparent,
          unfocusedIndicatorColor = Color.Transparent,
        ),
      )

      // Character Counter & Warning
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "$remainingChars حرف متبقي",
          color = if (remainingChars < 20) HoggarColorTokens.ErrorCoral else HoggarColorTokens.TextTertiary,
          fontSize = 11.sp,
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Attached Images Grid Preview
      if (attachedImages.isNotEmpty()) {
        Text(
          text = "الصور المرفقة (${attachedImages.size}/4):",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          attachedImages.forEachIndexed { index, imgUri ->
            Box(
              modifier = Modifier
                .weight(1f)
                .aspectRatio(1f)
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp)),
            ) {
              AsyncImage(
                model = imgUri,
                contentDescription = "Attached Image $index",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
              )

              // Remove image button
              IconButton(
                onClick = { attachedImages.removeAt(index) },
                modifier = Modifier
                  .align(Alignment.TopEnd)
                  .size(24.dp)
                  .background(Color(0x99000000), CircleShape),
              ) {
                Icon(
                  imageVector = Icons.Filled.Close,
                  contentDescription = "Remove",
                  tint = Color.White,
                  modifier = Modifier.size(14.dp),
                )
              }
            }
          }
          // Empty slots filler
          repeat(4 - attachedImages.size) {
            Box(
              modifier = Modifier
                .weight(1f)
                .aspectRatio(1f)
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, HoggarColorTokens.BorderSubtle.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                .background(HoggarColorTokens.BasaltSurface.copy(alpha = 0.5f))
                .clickable {
                  imagePickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                  )
                },
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.AddPhotoAlternate,
                contentDescription = "Add image",
                tint = HoggarColorTokens.TextTertiary,
                modifier = Modifier.size(22.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
      }

      // Fast Image & Media Actions
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(HoggarColorTokens.SlateContainer)
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = {
              imagePickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
              )
            },
            enabled = attachedImages.size < 4,
            modifier = Modifier.testTag("btn_attach_images"),
          ) {
            Icon(
              imageVector = Icons.Filled.Image,
              contentDescription = "Add Images",
              tint = if (attachedImages.size < 4) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextTertiary,
            )
          }

          Spacer(modifier = Modifier.width(4.dp))

          Text(
            text = "إرفاق صور (حتى 4 صور)",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 12.sp,
          )
        }

        // Demo sample photo quick adder
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(HoggarColorTokens.BasaltSurface)
            .clickable {
              val samplePhotos = listOf(
                "https://picsum.photos/seed/desert_scene1/800/600",
                "https://picsum.photos/seed/desert_scene2/800/600",
                "https://picsum.photos/seed/desert_scene3/800/600",
              )
              val next = samplePhotos.firstOrNull { !attachedImages.contains(it) }
              if (next != null && attachedImages.size < 4) {
                attachedImages.add(next)
              }
            }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Filled.AutoAwesome,
              contentDescription = null,
              tint = HoggarColorTokens.InteractiveAmber,
              modifier = Modifier.size(13.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "عينة صورة صحراوية",
              color = HoggarColorTokens.InteractiveAmber,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Quick Suggested Hashtags
      Text(
        text = "وسوم مقترحة للتغريد والنشر:",
        color = HoggarColorTokens.TextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
      )
      Spacer(modifier = Modifier.height(8.dp))

      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        suggestedTags.forEach { tag ->
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(HoggarColorTokens.BasaltSurface)
              .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(8.dp))
              .clickable {
                if (!postText.contains(tag)) {
                  postText = if (postText.isEmpty()) tag else "$postText $tag"
                }
              }
              .padding(horizontal = 10.dp, vertical = 6.dp),
          ) {
            Text(
              text = tag,
              color = HoggarColorTokens.InteractiveAmber,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(40.dp))
    }
  }
}
