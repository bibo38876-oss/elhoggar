package com.example.ui.interaction

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VideoItem
import com.example.ui.theme.HoggarColorTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoMoreOptionsBottomSheet(
  video: VideoItem,
  sheetState: SheetState,
  onDismiss: () -> Unit,
  onNotInterested: () -> Unit,
  onToggleBookmark: () -> Unit,
  onShare: () -> Unit,
  onReport: () -> Unit,
  onBlockCreator: () -> Unit,
  onToggleClearMode: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val deepLink = "https://elhoggar.dz/v/${video.id}"

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = HoggarColorTokens.BasaltSurface,
    contentColor = HoggarColorTokens.TextPrimary,
    dragHandle = {
      Box(
        modifier = Modifier
          .padding(vertical = 10.dp)
          .width(36.dp)
          .height(4.dp)
          .clip(RoundedCornerShape(2.dp))
          .background(HoggarColorTokens.SlateContainer),
      )
    },
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 8.dp),
    ) {
      Text(
        text = "خيارات الفيديو",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
      )

      Spacer(modifier = Modifier.height(14.dp))

      // 0. Clear Mode
      MoreOptionItem(
        icon = Icons.Filled.Visibility,
        title = "وضع الشاشة النظيفة",
        subtitle = "إخفاء كافة العناصر والأزرار للتركيز الكامل على الفيديو",
        onClick = {
          onDismiss()
          onToggleClearMode()
        },
        testTag = "btn_more_clear_mode",
      )

      HorizontalDivider(color = HoggarColorTokens.BorderSubtle, thickness = 0.5.dp)

      // 1. Not Interested
      MoreOptionItem(
        icon = Icons.Filled.VisibilityOff,
        title = "غير مهتم بهذا المحتوى",
        subtitle = "تقليل اقتراح مقاطع مشابهة في خلاصتك",
        onClick = {
          onNotInterested()
          Toast.makeText(context, "تم استبعاد هذا المحتوى من توصياتك", Toast.LENGTH_SHORT).show()
          onDismiss()
        },
        testTag = "btn_more_not_interested",
      )

      HorizontalDivider(color = HoggarColorTokens.BorderSubtle, thickness = 0.5.dp)

      // 2. Bookmark / Save
      MoreOptionItem(
        icon = if (video.isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
        title = if (video.isBookmarked) "إزالة من المحفوظات" else "حفظ الفيديو",
        subtitle = "الوصول للفيديو لاحقًا في ملفك الشخصي",
        tint = if (video.isBookmarked) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextPrimary,
        onClick = {
          onToggleBookmark()
          onDismiss()
        },
        testTag = "btn_more_bookmark",
      )

      HorizontalDivider(color = HoggarColorTokens.BorderSubtle, thickness = 0.5.dp)

      // 3. Share via Apps
      MoreOptionItem(
        icon = Icons.Filled.Share,
        title = "مشاركة عبر التطبيقات",
        subtitle = "إرسال الرابط إلى الأصدقاء",
        onClick = {
          onDismiss()
          val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "فيديو الهڨار: ${video.title}")
            putExtra(Intent.EXTRA_TEXT, "${video.title}\nشاهده على الهڨار: $deepLink")
          }
          context.startActivity(Intent.createChooser(sendIntent, "مشاركة الفيديو"))
        },
        testTag = "btn_more_share",
      )

      HorizontalDivider(color = HoggarColorTokens.BorderSubtle, thickness = 0.5.dp)

      // 4. Copy Link
      MoreOptionItem(
        icon = Icons.Filled.ContentCopy,
        title = "نسخ رابط الفيديو",
        subtitle = deepLink,
        onClick = {
          val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
          val clip = ClipData.newPlainText("Hoggar Video Link", deepLink)
          clipboard.setPrimaryClip(clip)
          Toast.makeText(context, "تم نسخ الرابط للحافظة", Toast.LENGTH_SHORT).show()
          onDismiss()
        },
        testTag = "btn_more_copy_link",
      )

      HorizontalDivider(color = HoggarColorTokens.BorderSubtle, thickness = 0.5.dp)

      // 5. Report
      MoreOptionItem(
        icon = Icons.Filled.Flag,
        title = "إبلاغ عن المحتوى",
        subtitle = "مساعدة فريق الهڨار في الحفاظ على مجتمع آمن",
        tint = Color(0xFFEF5350),
        onClick = {
          onDismiss()
          onReport()
        },
        testTag = "btn_more_report",
      )

      HorizontalDivider(color = HoggarColorTokens.BorderSubtle, thickness = 0.5.dp)

      // 6. Block Creator
      MoreOptionItem(
        icon = Icons.Filled.Block,
        title = "حظر @${video.creator.username}",
        subtitle = "إخفاء كافة الفيديوهات والمشاركات من هذا الحساب",
        tint = Color(0xFFE57373),
        onClick = {
          onBlockCreator()
          Toast.makeText(context, "تم حظر الحساب بنجاح", Toast.LENGTH_SHORT).show()
          onDismiss()
        },
        testTag = "btn_more_block",
      )

      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun MoreOptionItem(
  icon: ImageVector,
  title: String,
  subtitle: String? = null,
  tint: Color = HoggarColorTokens.TextPrimary,
  onClick: () -> Unit,
  testTag: String,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(vertical = 12.dp)
      .testTag(testTag),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = title,
      tint = tint,
      modifier = Modifier.size(24.dp),
    )
    Spacer(modifier = Modifier.width(14.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        color = tint,
        fontSize = 14.sp,
        fontWeight = FontWeight.Medium,
      )
      if (subtitle != null) {
        Text(
          text = subtitle,
          color = HoggarColorTokens.TextSecondary,
          fontSize = 11.sp,
        )
      }
    }
  }
}
