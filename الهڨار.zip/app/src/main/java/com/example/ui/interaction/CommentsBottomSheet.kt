package com.example.ui.interaction

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.interaction.model.CommentItem
import com.example.interaction.repository.CommentRepository
import com.example.model.CreatorModel
import com.example.ui.components.HoggarEmptyState
import com.example.ui.components.HoggarVerifiedBadge
import com.example.ui.theme.HoggarColorTokens
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentsBottomSheet(
  videoId: String,
  videoOwnerId: String,
  currentUser: CreatorModel,
  repository: CommentRepository,
  sheetState: SheetState,
  onDismiss: () -> Unit,
  onReportComment: (CommentItem) -> Unit,
  isGuest: Boolean = false,
  onRequestAuth: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val comments by repository.getComments(videoId).collectAsState(initial = emptyList())
  val scope = rememberCoroutineScope()

  var commentInput by remember { mutableStateOf("") }
  var replyingToComment by remember { mutableStateOf<CommentItem?>(null) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = HoggarColorTokens.BasaltSurface,
    contentColor = HoggarColorTokens.TextPrimary,
    dragHandle = {
      Box(
        modifier = Modifier
          .padding(vertical = 10.dp)
          .width(36.dp)
          .height(4.dp)
          .clip(RoundedCornerShape(2.dp))
          .background(HoggarColorTokens.SlateContainer),
      )
    },
    modifier = modifier.fillMaxHeight(0.75f),
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .imePadding(),
    ) {
      // 1. Header
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "التعليقات (${comments.sumOf { 1 + it.repliesCount }})",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )

        IconButton(onClick = onDismiss) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Close",
            tint = HoggarColorTokens.TextSecondary,
          )
        }
      }

      Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(HoggarColorTokens.BorderSubtle))

      // 2. Comments List
      if (comments.isEmpty()) {
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          contentAlignment = Alignment.Center,
        ) {
          HoggarEmptyState(
            title = "لا توجد تعليقات حتى الآن",
            description = "كن أول من يشارك رأيه حول هذا الفيديو في الهڨار.",
          )
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
          item { Spacer(modifier = Modifier.height(6.dp)) }

          items(comments, key = { it.id }) { comment ->
            CommentRowItem(
              comment = comment,
              currentUserId = currentUser.id,
              videoOwnerId = videoOwnerId,
              onLike = {
                if (isGuest) {
                  onRequestAuth?.invoke()
                } else {
                  scope.launch { repository.toggleLikeComment(comment.id, currentUser.id) }
                }
              },
              onReply = {
                if (isGuest) {
                  onRequestAuth?.invoke()
                } else {
                  replyingToComment = comment
                }
              },
              onTogglePin = {
                if (isGuest) {
                  onRequestAuth?.invoke()
                } else {
                  scope.launch { repository.togglePinComment(comment.id, currentUser.id, videoOwnerId) }
                }
              },
              onDelete = {
                scope.launch { repository.deleteComment(comment.id, currentUser.id, videoOwnerId) }
              },
              onReport = {
                if (isGuest) {
                  onRequestAuth?.invoke()
                } else {
                  onReportComment(comment)
                }
              },
            )
          }

          item { Spacer(modifier = Modifier.height(10.dp)) }
        }
      }

      // 3. Error Banner
      AnimatedVisibility(visible = errorMessage != null) {
        errorMessage?.let { err ->
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(HoggarColorTokens.ErrorCoral.copy(alpha = 0.2f))
              .padding(8.dp),
          ) {
            Text(text = err, color = HoggarColorTokens.ErrorCoral, fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
          }
        }
      }

      // 4. Replying To Indicator
      if (replyingToComment != null) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(HoggarColorTokens.SlateContainer)
            .padding(horizontal = 16.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "الرد على @${replyingToComment?.author?.username}:",
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
          )
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Cancel Reply",
            tint = HoggarColorTokens.TextSecondary,
            modifier = Modifier.size(16.dp).clickable { replyingToComment = null },
          )
        }
      }

      // 5. Bottom Input Bar
      if (isGuest) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(HoggarColorTokens.ObsidianElevated)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(HoggarColorTokens.SlateContainer)
              .border(1.dp, HoggarColorTokens.InteractiveAmber.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
              .clickable { onRequestAuth?.invoke() }
              .padding(horizontal = 16.dp, vertical = 12.dp)
              .testTag("btn_guest_comment_prompt"),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "سجل دخولك لتتمكن من كتابة تعليق 💬",
              color = HoggarColorTokens.TextSecondary,
              fontSize = 13.sp,
            )
            Text(
              text = "تسجيل الدخول",
              color = HoggarColorTokens.InteractiveAmber,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      } else {
        // Quick Reaction Emoji Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(HoggarColorTokens.ObsidianElevated)
            .padding(horizontal = 14.dp, vertical = 5.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          val quickEmojis = listOf("🔥", "❤️", "👏", "😂", "🇩🇿", "✨", "🐫", "💯")
          quickEmojis.forEach { emoji ->
            Box(
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(HoggarColorTokens.SlateContainer.copy(alpha = 0.7f))
                .clickable {
                  commentInput += emoji
                },
              contentAlignment = Alignment.Center,
            ) {
              Text(text = emoji, fontSize = 16.sp)
            }
          }
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(HoggarColorTokens.ObsidianElevated)
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(HoggarColorTokens.SlateContainer),
            contentAlignment = Alignment.Center,
          ) {
            if (currentUser.avatarUrl.isNotEmpty()) {
              AsyncImage(model = currentUser.avatarUrl, contentDescription = null, modifier = Modifier.fillMaxSize().clip(CircleShape))
            } else {
              Text(text = currentUser.displayName.take(1), color = HoggarColorTokens.InteractiveAmber, fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.width(10.dp))

          TextField(
            value = commentInput,
            onValueChange = {
              commentInput = it
              errorMessage = null
            },
            placeholder = { Text(if (replyingToComment != null) "اكتب ردك..." else "أضف تعليقًا في الهڨار...", color = HoggarColorTokens.TextTertiary, fontSize = 13.sp) },
            singleLine = true,
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(20.dp))
              .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(20.dp))
              .testTag("input_comment_text"),
            colors = TextFieldDefaults.colors(
              focusedContainerColor = HoggarColorTokens.SlateContainer,
              unfocusedContainerColor = HoggarColorTokens.SlateContainer,
              focusedTextColor = HoggarColorTokens.TextPrimary,
              unfocusedTextColor = HoggarColorTokens.TextPrimary,
              focusedIndicatorColor = Color.Transparent,
              unfocusedIndicatorColor = Color.Transparent,
            ),
          )

          Spacer(modifier = Modifier.width(8.dp))

          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(if (commentInput.trim().isNotEmpty()) HoggarColorTokens.CopperPrimary else HoggarColorTokens.SlateContainer)
            .clickable(enabled = commentInput.trim().isNotEmpty()) {
              scope.launch {
                val result = repository.addComment(
                  videoId = videoId,
                  author = currentUser,
                  text = commentInput,
                  parentCommentId = replyingToComment?.id,
                )
                if (result.isSuccess) {
                  commentInput = ""
                  replyingToComment = null
                  errorMessage = null
                } else {
                  errorMessage = result.exceptionOrNull()?.message
                }
              }
            }
            .testTag("btn_send_comment"),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = "Send",
            tint = if (commentInput.trim().isNotEmpty()) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextTertiary,
            modifier = Modifier.size(18.dp),
          )
        }
      }
    }
    }
  }
}

@Composable
private fun CommentRowItem(
  comment: CommentItem,
  currentUserId: String,
  videoOwnerId: String,
  onLike: () -> Unit,
  onReply: () -> Unit,
  onTogglePin: () -> Unit,
  onDelete: () -> Unit,
  onReport: () -> Unit,
) {
  val context = LocalContext.current
  var showMenu by remember { mutableStateOf(false) }
  var areRepliesExpanded by remember { mutableStateOf(false) }

  val isCommentAuthor = comment.author.id == currentUserId
  val isVideoOwner = currentUserId == videoOwnerId

  Column(modifier = Modifier.fillMaxWidth()) {
    // Pinned Badge if comment is pinned
    if (comment.isPinned) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 4.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.PushPin,
          contentDescription = null,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(13.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = "مثبت من صاحب الفيديو",
          color = HoggarColorTokens.InteractiveAmber,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
        )
      }
    }

    Row(modifier = Modifier.fillMaxWidth()) {
      // Author Avatar
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(HoggarColorTokens.SlateContainer),
        contentAlignment = Alignment.Center,
      ) {
        if (comment.author.avatarUrl.isNotEmpty()) {
          AsyncImage(model = comment.author.avatarUrl, contentDescription = null, modifier = Modifier.fillMaxSize().clip(CircleShape))
        } else {
          Text(text = comment.author.displayName.take(1), color = HoggarColorTokens.InteractiveAmber, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.width(10.dp))

      // Comment Content & Actions
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = comment.author.displayName, color = HoggarColorTokens.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          if (comment.author.isVerified) {
            Spacer(modifier = Modifier.width(4.dp))
            HoggarVerifiedBadge()
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "@${comment.author.username}", color = HoggarColorTokens.TextTertiary, fontSize = 11.sp)
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(text = comment.text, color = HoggarColorTokens.TextPrimary, fontSize = 13.sp, lineHeight = 18.sp)

        Spacer(modifier = Modifier.height(4.dp))

        // Reply & More Options Row
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "رد",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.clickable(onClick = onReply),
          )

          Spacer(modifier = Modifier.width(12.dp))

          Box {
            Icon(
              imageVector = Icons.Filled.MoreVert,
              contentDescription = "More",
              tint = HoggarColorTokens.TextTertiary,
              modifier = Modifier.size(14.dp).clickable { showMenu = true },
            )

            DropdownMenu(
              expanded = showMenu,
              onDismissRequest = { showMenu = false },
              modifier = Modifier.background(HoggarColorTokens.BasaltSurface),
            ) {
              if (isVideoOwner) {
                DropdownMenuItem(
                  text = { Text(if (comment.isPinned) "إلغاء التثبيت" else "تثبيت التعليق", color = HoggarColorTokens.TextPrimary) },
                  leadingIcon = { Icon(Icons.Filled.PushPin, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber) },
                  onClick = {
                    showMenu = false
                    onTogglePin()
                  },
                )
              }
              if (isCommentAuthor || isVideoOwner) {
                DropdownMenuItem(
                  text = { Text("حذف التعليق", color = HoggarColorTokens.ErrorCoral) },
                  leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null, tint = HoggarColorTokens.ErrorCoral) },
                  onClick = {
                    showMenu = false
                    onDelete()
                  },
                )
              }
              DropdownMenuItem(
                text = { Text("نسخ التعليق", color = HoggarColorTokens.TextPrimary) },
                leadingIcon = { Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = HoggarColorTokens.TextSecondary) },
                onClick = {
                  showMenu = false
                  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                  clipboard.setPrimaryClip(ClipData.newPlainText("Comment", comment.text))
                  Toast.makeText(context, "تم نسخ نص التعليق", Toast.LENGTH_SHORT).show()
                },
              )
              if (!isCommentAuthor) {
                DropdownMenuItem(
                  text = { Text("إبلاغ عن التعليق", color = HoggarColorTokens.WarningDune) },
                  leadingIcon = { Icon(Icons.Filled.Flag, contentDescription = null, tint = HoggarColorTokens.WarningDune) },
                  onClick = {
                    showMenu = false
                    onReport()
                  },
                )
              }
            }
          }
        }

        // Replies Toggle & Expanded List
        if (comment.repliesCount > 0) {
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (areRepliesExpanded) "إخفاء الردود" else "عرض الردود (${comment.repliesCount})",
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.clickable { areRepliesExpanded = !areRepliesExpanded },
          )

          if (areRepliesExpanded) {
            Column(
              modifier = Modifier.padding(top = 6.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              comment.replies.forEach { reply ->
                Row(modifier = Modifier.fillMaxWidth()) {
                  Box(
                    modifier = Modifier
                      .size(26.dp)
                      .clip(CircleShape)
                      .background(HoggarColorTokens.SlateContainer),
                    contentAlignment = Alignment.Center,
                  ) {
                    Text(text = reply.author.displayName.take(1), color = HoggarColorTokens.InteractiveAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text(text = "@${reply.author.username}", color = HoggarColorTokens.TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(text = reply.text, color = HoggarColorTokens.TextPrimary, fontSize = 12.sp)
                  }
                }
              }
            }
          }
        }
      }

      // Comment Like Column
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(start = 8.dp),
      ) {
        Icon(
          imageVector = if (comment.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
          contentDescription = "Like Comment",
          tint = if (comment.isLiked) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextTertiary,
          modifier = Modifier.size(16.dp).clickable(onClick = onLike),
        )
        if (comment.likesCount > 0) {
          Text(text = comment.likesCount.toString(), color = HoggarColorTokens.TextTertiary, fontSize = 10.sp)
        }
      }
    }
  }
}
