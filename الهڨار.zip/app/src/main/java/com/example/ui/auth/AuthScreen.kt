package com.example.ui.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarLogoMark
import com.example.ui.components.HoggarWordmark
import com.example.ui.components.WordmarkSize
import com.example.ui.theme.HoggarColorTokens

@Composable
fun AuthScreen(
  viewModel: AuthViewModel,
  onDismiss: () -> Unit,
  onAuthSuccess: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val authState by viewModel.authState.collectAsState()
  val recoveryMessage by viewModel.recoveryMessage.collectAsState()

  var selectedTab by remember { mutableIntStateOf(0) } // 0: Sign In, 1: Register

  // Form Fields
  var usernameInput by remember { mutableStateOf("") }
  var displayNameInput by remember { mutableStateOf("") }
  var emailInput by remember { mutableStateOf("") }
  var passwordInput by remember { mutableStateOf("") }
  var isPasswordVisible by remember { mutableStateOf(false) }

  var showForgotPasswordDialog by remember { mutableStateOf(false) }
  var recoveryEmailInput by remember { mutableStateOf("") }

  // Dismiss if authenticated
  if (authState.isAuthenticated) {
    onAuthSuccess()
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("auth_screen"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 24.dp, vertical = 16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      // Top Close Button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(HoggarColorTokens.SlateContainer)
            .clickable(onClick = onDismiss),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Dismiss",
            tint = HoggarColorTokens.TextPrimary,
            modifier = Modifier.size(20.dp),
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Hoggar Geometric Emblem & Typographic Wordmark
      HoggarLogoMark(size = 64.dp, showGlow = true)
      Spacer(modifier = Modifier.height(12.dp))
      HoggarWordmark(size = WordmarkSize.Medium, showLatinSubtitle = true)

      Spacer(modifier = Modifier.height(20.dp))

      val context = LocalContext.current

      // GOOGLE SIGN IN BUTTON
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(Color.White)
          .clickable(enabled = !authState.isLoading) {
            viewModel.loginWithGoogle(context) {
              onAuthSuccess()
            }
          }
          .padding(horizontal = 16.dp)
          .testTag("btn_auth_google"),
        contentAlignment = Alignment.Center,
      ) {
        if (authState.isLoading) {
          androidx.compose.material3.CircularProgressIndicator(color = HoggarColorTokens.CopperPrimary, modifier = Modifier.size(24.dp))
        } else {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
          ) {
            GoogleBrandIcon(modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = "المتابعة باستخدام Google",
              color = Color(0xFF1F1F1F),
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // DIVIDER OR
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        androidx.compose.material3.HorizontalDivider(modifier = Modifier.weight(1f), color = HoggarColorTokens.BorderSubtle)
        Text(
          text = "أو عبر البريد الإلكتروني",
          color = HoggarColorTokens.TextTertiary,
          fontSize = 12.sp,
          modifier = Modifier.padding(horizontal = 12.dp),
        )
        androidx.compose.material3.HorizontalDivider(modifier = Modifier.weight(1f), color = HoggarColorTokens.BorderSubtle)
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Tab Switcher: تسجيل الدخول / إنشاء حساب
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(HoggarColorTokens.SlateContainer)
          .padding(4.dp),
      ) {
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (selectedTab == 0) HoggarColorTokens.CopperPrimary else Color.Transparent)
            .clickable { selectedTab = 0 }
            .padding(vertical = 10.dp)
            .testTag("tab_auth_signin"),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = "تسجيل الدخول",
            color = if (selectedTab == 0) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
          )
        }

        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (selectedTab == 1) HoggarColorTokens.CopperPrimary else Color.Transparent)
            .clickable { selectedTab = 1 }
            .padding(vertical = 10.dp)
            .testTag("tab_auth_register"),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = "إنشاء حساب جديد",
            color = if (selectedTab == 1) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
          )
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Error Banner
      AnimatedVisibility(visible = authState.errorMessage != null) {
        authState.errorMessage?.let { err ->
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(HoggarColorTokens.ErrorCoral.copy(alpha = 0.15f))
              .border(1.dp, HoggarColorTokens.ErrorCoral.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
              .padding(12.dp),
          ) {
            Text(
              text = err,
              color = HoggarColorTokens.ErrorCoral,
              fontSize = 13.sp,
              textAlign = TextAlign.Center,
              modifier = Modifier.fillMaxWidth(),
            )
          }
          Spacer(modifier = Modifier.height(14.dp))
        }
      }

      // Input Fields Form
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        if (selectedTab == 0) {
          // Sign In Fields
          AuthTextField(
            value = usernameInput,
            onValueChange = { usernameInput = it },
            label = "اسم المستخدم أو البريد الإلكتروني",
            placeholder = "مثال: creator_hoggar أو user@elhoggar.dz",
            leadingIcon = Icons.Filled.Person,
            testTag = "input_login_id",
          )

          AuthTextField(
            value = passwordInput,
            onValueChange = { passwordInput = it },
            label = "كلمة المرور",
            placeholder = "أدخل كلمة المرور",
            leadingIcon = Icons.Filled.Lock,
            isPassword = true,
            isPasswordVisible = isPasswordVisible,
            onTogglePasswordVisibility = { isPasswordVisible = !isPasswordVisible },
            testTag = "input_login_password",
          )

          // Forgot password trigger
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
          ) {
            Text(
              text = "نسيت كلمة المرور؟",
              color = HoggarColorTokens.InteractiveAmber,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
              modifier = Modifier.clickable { showForgotPasswordDialog = true },
            )
          }
        } else {
          // Register Fields (Username, Display Name, Email, Password)
          AuthTextField(
            value = usernameInput,
            onValueChange = { usernameInput = it },
            label = "اسم المستخدم (Username)",
            placeholder = "مثال: tassili_star (أحرف وأرقام و _ فقط)",
            leadingIcon = Icons.Filled.Person,
            testTag = "input_register_username",
          )

          AuthTextField(
            value = displayNameInput,
            onValueChange = { displayNameInput = it },
            label = "اسم العرض (Display Name)",
            placeholder = "مثال: رحالة الطاسيلي",
            leadingIcon = Icons.Filled.Person,
            testTag = "input_register_display_name",
          )

          AuthTextField(
            value = emailInput,
            onValueChange = { emailInput = it },
            label = "البريد الإلكتروني",
            placeholder = "name@example.com",
            leadingIcon = Icons.Filled.Email,
            keyboardType = KeyboardType.Email,
            testTag = "input_register_email",
          )

          AuthTextField(
            value = passwordInput,
            onValueChange = { passwordInput = it },
            label = "كلمة المرور",
            placeholder = "6 أحرف على الأقل",
            leadingIcon = Icons.Filled.Lock,
            isPassword = true,
            isPasswordVisible = isPasswordVisible,
            onTogglePasswordVisibility = { isPasswordVisible = !isPasswordVisible },
            testTag = "input_register_password",
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Submit Button
        HoggarButton(
          text = if (selectedTab == 0) "تسجيل الدخول" else "إنشاء الحساب",
          onClick = {
            if (selectedTab == 0) {
              viewModel.login(usernameInput, passwordInput)
            } else {
              viewModel.register(usernameInput, displayNameInput, emailInput, passwordInput)
            }
          },
          variant = HoggarButtonVariant.PrimaryCopper,
          isLoading = authState.isLoading,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("btn_auth_submit"),
        )
      }
    }

    // Password Recovery Dialog
    if (showForgotPasswordDialog) {
      AlertDialog(
        onDismissRequest = {
          showForgotPasswordDialog = false
          viewModel.clearRecoveryMessage()
        },
        containerColor = HoggarColorTokens.BasaltSurface,
        title = {
          Text(
            text = "استعادة الوصول إلى الحساب",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
          )
        },
        text = {
          Column {
            Text(
              text = "أدخل بريدك الإلكتروني المسجل وسنرسل لك تعليمات استعادة كلمة المرور.",
              color = HoggarColorTokens.TextSecondary,
              fontSize = 13.sp,
            )
            Spacer(modifier = Modifier.height(12.dp))
            AuthTextField(
              value = recoveryEmailInput,
              onValueChange = { recoveryEmailInput = it },
              label = "البريد الإلكتروني",
              placeholder = "name@example.com",
              leadingIcon = Icons.Filled.Email,
              keyboardType = KeyboardType.Email,
              testTag = "input_recovery_email",
            )
            if (recoveryMessage != null) {
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = recoveryMessage ?: "",
                color = HoggarColorTokens.InteractiveAmber,
                fontSize = 12.sp,
              )
            }
          }
        },
        confirmButton = {
          TextButton(
            onClick = { viewModel.recoverPassword(recoveryEmailInput) },
          ) {
            Text("إرسال الرابط", color = HoggarColorTokens.InteractiveAmber, fontWeight = FontWeight.Bold)
          }
        },
        dismissButton = {
          TextButton(
            onClick = {
              showForgotPasswordDialog = false
              viewModel.clearRecoveryMessage()
            },
          ) {
            Text("إلغاء", color = HoggarColorTokens.TextSecondary)
          }
        },
      )
    }
  }
}

@Composable
private fun AuthTextField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  placeholder: String,
  leadingIcon: androidx.compose.ui.graphics.vector.ImageVector,
  modifier: Modifier = Modifier,
  isPassword: Boolean = false,
  isPasswordVisible: Boolean = false,
  onTogglePasswordVisibility: (() -> Unit)? = null,
  keyboardType: KeyboardType = KeyboardType.Text,
  testTag: String = "auth_text_field",
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Text(
      text = label,
      color = HoggarColorTokens.TextSecondary,
      fontSize = 12.sp,
      fontWeight = FontWeight.Medium,
    )
    Spacer(modifier = Modifier.height(6.dp))
    TextField(
      value = value,
      onValueChange = onValueChange,
      placeholder = { Text(placeholder, color = HoggarColorTokens.TextTertiary, fontSize = 13.sp) },
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(10.dp))
        .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
        .testTag(testTag),
      leadingIcon = {
        Icon(
          imageVector = leadingIcon,
          contentDescription = null,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(20.dp),
        )
      },
      trailingIcon = if (isPassword && onTogglePasswordVisibility != null) {
        {
          IconButton(onClick = onTogglePasswordVisibility) {
            Icon(
              imageVector = if (isPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
              contentDescription = "Toggle Password Visibility",
              tint = HoggarColorTokens.TextSecondary,
            )
          }
        }
      } else null,
      visualTransformation = if (isPassword && !isPasswordVisible) PasswordVisualTransformation() else VisualTransformation.None,
      keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
      singleLine = true,
      colors = TextFieldDefaults.colors(
        focusedContainerColor = HoggarColorTokens.SlateContainer,
        unfocusedContainerColor = HoggarColorTokens.SlateContainer,
        focusedTextColor = HoggarColorTokens.TextPrimary,
        unfocusedTextColor = HoggarColorTokens.TextPrimary,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
      ),
    )
  }
}
