package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.LocalLocalization
import com.example.localization.hoggarString
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarLogoMark
import com.example.ui.theme.HoggarColorTokens

@Composable
fun FirstRunScreen(
  onContinueAsGuest: () -> Unit,
  onGoToAuth: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val localization = LocalLocalization.current
  val isArabic = localization.currentLanguage == AppLanguage.Arabic

  fun markCompleted() {
    val prefs = context.getSharedPreferences("elhoggar_settings", Context.MODE_PRIVATE)
    prefs.edit().putBoolean("has_completed_first_run", true).apply()
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("first_run_screen"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp, vertical = 16.dp)
        .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      // Top row: Language toggle button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
      ) {
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(HoggarColorTokens.BasaltSurface)
            .border(1.dp, HoggarColorTokens.SlateContainer, RoundedCornerShape(20.dp))
            .clickable {
              val nextLang = if (isArabic) AppLanguage.English else AppLanguage.Arabic
              localization.setLanguage(context, nextLang)
            }
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("first_run_language_toggle"),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Filled.Language,
            contentDescription = "Language",
            tint = HoggarColorTokens.InteractiveAmber,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isArabic) "English" else "العربية",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
          )
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Center: Sacred Geometric Emblem and Core Value
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(top = 40.dp),
      ) {
        HoggarLogoMark(
          size = 100.dp,
          showGlow = true,
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
          text = "الهڨار",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 32.sp,
          fontWeight = FontWeight.ExtraBold,
          textAlign = TextAlign.Center,
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = "فيديوهات قصيرة. حضور أكبر.",
          color = HoggarColorTokens.InteractiveAmber,
          fontSize = 17.sp,
          fontWeight = FontWeight.Bold,
          textAlign = TextAlign.Center,
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "منصة المشاهدة العمودية الأولى بأصالة جزائرية وهوية تارقية أصيلة.",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 14.sp,
          textAlign = TextAlign.Center,
          lineHeight = 22.sp,
          modifier = Modifier.padding(horizontal = 20.dp),
        )
      }

      Spacer(modifier = Modifier.height(40.dp))

      // Bottom Actions: Sign In, Create Account, Browse as Guest
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        HoggarButton(
          text = "تسجيل الدخول",
          variant = HoggarButtonVariant.PrimaryCopper,
          onClick = {
            markCompleted()
            onGoToAuth()
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("first_run_btn_signin"),
        )

        HoggarButton(
          text = "إنشاء حساب جديد",
          variant = HoggarButtonVariant.Outlined,
          onClick = {
            markCompleted()
            onGoToAuth()
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("first_run_btn_signup"),
        )

        HoggarButton(
          text = "تصفح كزائر",
          variant = HoggarButtonVariant.Ghost,
          onClick = {
            markCompleted()
            onContinueAsGuest()
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("first_run_btn_guest"),
        )
      }
    }
  }
}

@Composable
private fun FeatureHighlightItem(
  icon: ImageVector,
  title: String,
  desc: String,
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Box(
      modifier = Modifier
        .size(38.dp)
        .clip(CircleShape)
        .background(HoggarColorTokens.ObsidianBase),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = HoggarColorTokens.InteractiveAmber,
        modifier = Modifier.size(20.dp),
      )
    }
    Spacer(modifier = Modifier.width(12.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        color = HoggarColorTokens.TextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
      )
      Text(
        text = desc,
        color = HoggarColorTokens.TextSecondary,
        fontSize = 11.sp,
        lineHeight = 16.sp,
      )
    }
  }
}
