package com.example.ui.feed

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.interaction.model.NotificationType
import com.example.interaction.model.ReportTargetType
import com.example.interaction.repository.CommentRepository
import com.example.interaction.repository.InteractionRepository
import com.example.interaction.repository.NotificationRepository
import com.example.interaction.repository.ReportRepository
import com.example.model.CreatorModel
import com.example.model.VideoItem
import com.example.player.HoggarPlayerView
import com.example.ui.components.HoggarEmptyState
import com.example.ui.components.HoggarLoadingIndicator
import com.example.ui.components.HoggarOfflineScreen
import com.example.ui.interaction.CommentsBottomSheet
import com.example.ui.interaction.ReportDialog
import com.example.ui.interaction.ShareBottomSheet
import com.example.ui.interaction.VideoMoreOptionsBottomSheet
import com.example.ui.theme.HoggarColorTokens
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VerticalVideoFeed(
  viewModel: FeedViewModel,
  commentRepository: CommentRepository,
  reportRepository: ReportRepository,
  interactionRepository: InteractionRepository,
  notificationRepository: NotificationRepository,
  currentUser: CreatorModel,
  onSearchClick: () -> Unit,
  onCreatorClick: (creatorId: String) -> Unit = {},
  onHashtagClick: (String) -> Unit = {},
  onSoundClick: (soundTitle: String, soundAuthor: String) -> Unit = { _, _ -> },
  isGuest: Boolean = false,
  onRequestAuth: ((reason: String, pendingAction: (() -> Unit)?) -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val uiState by viewModel.uiState.collectAsState()
  val activeIndex by viewModel.activePageIndex.collectAsState()
  val isFollowingTab by viewModel.isFollowingTab.collectAsState()
  val isMuted by viewModel.playerManager.isMuted.collectAsState()
  val playbackProgress by viewModel.playerManager.playbackProgress.collectAsState()

  val lifecycleOwner = LocalLifecycleOwner.current
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  // Clear / Immersive Mode State
  var isClearMode by remember { mutableStateOf(false) }

  // Interaction Sheets & Dialogs State
  var activeCommentsVideo by remember { mutableStateOf<VideoItem?>(null) }
  var activeShareVideo by remember { mutableStateOf<VideoItem?>(null) }
  var activeMoreVideo by remember { mutableStateOf<VideoItem?>(null) }
  var activeReportTarget by remember { mutableStateOf<Pair<ReportTargetType, String>?>(null) }

  val commentsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val shareSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val moreSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  // Manage activity lifecycle (pause on background, resume on foreground)
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> viewModel.onAppPause()
        Lifecycle.Event.ON_RESUME -> viewModel.onAppResume()
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .testTag("vertical_video_feed"),
    contentAlignment = Alignment.Center,
  ) {
    when (val state = uiState) {
      is FeedUiState.Loading -> {
        HoggarLoadingIndicator(size = 64.dp)
      }

      is FeedUiState.Empty -> {
        HoggarEmptyState(
          title = "لا توجد فيديوهات حتى الآن",
          description = "تابع صُنّاع المحتوى لاكتشاف أحدث اللحظات العمودية الحصرية في الهڨار.",
          actionText = "تحديث الخلاصة",
          onActionClick = { viewModel.loadFeed() },
        )
      }

      is FeedUiState.Error -> {
        if (state.isNetworkError) {
          HoggarOfflineScreen(
            onRetry = { viewModel.loadFeed() },
            customMessage = state.message,
          )
        } else {
          HoggarEmptyState(
            title = "تعذر تحميل الفيديوهات",
            description = state.message,
            actionText = "إعادة المحاولة",
            onActionClick = { viewModel.loadFeed() },
          )
        }
      }

      is FeedUiState.Success -> {
        val items = state.items
        val pagerState = rememberPagerState(
          initialPage = 0,
          pageCount = { items.size },
        )

        // Listen to settled page changes and trigger auto-play
        LaunchedEffect(pagerState) {
          snapshotFlow { pagerState.settledPage }.collect { settledPage ->
            viewModel.onPageChanged(settledPage)
          }
        }

        // View Counter Logic: Requires minimum 3.0s continuous playback threshold
        LaunchedEffect(pagerState.currentPage) {
          delay(3000)
          if (pagerState.currentPage in items.indices) {
            val activeVideo = items[pagerState.currentPage].video
            interactionRepository.recordView(activeVideo.id, currentUser.id, 3.5f)
          }
        }

        VerticalPager(
          state = pagerState,
          modifier = Modifier.fillMaxSize(),
          key = { index -> items[index].video.id },
        ) { pageIndex ->
          val feedItem = items[pageIndex]
          val videoItem = feedItem.video
          val isCurrentActive = pageIndex == pagerState.currentPage
          val player = viewModel.playerManager.primaryPlayer

          Box(modifier = Modifier.fillMaxSize()) {
            // Real Video Player Layer (ExoPlayer)
            HoggarPlayerView(
              videoItem = videoItem,
              player = player,
              isActive = isCurrentActive,
              onDoubleTapLike = {
                if (isGuest) {
                  onRequestAuth?.invoke("سجل دخولك للإعجاب بهذا الفيديو") {
                    viewModel.toggleLike(videoItem)
                  }
                } else {
                  if (interactionRepository.canLike(currentUser.id, videoItem.id)) {
                    interactionRepository.recordLikeAction(currentUser.id, videoItem.id)
                    val wasLiked = videoItem.isLiked
                    viewModel.toggleLike(videoItem)
                    if (!wasLiked) {
                      notificationRepository.dispatchNotification(
                        recipientUserId = videoItem.ownerId,
                        actor = currentUser,
                        type = NotificationType.Like,
                        targetVideoId = videoItem.id,
                        previewText = "أعجب بفيديو: ${videoItem.title}",
                      )
                    }
                  }
                }
              },
            )

            // Interaction and Meta Overlay Layer
            VideoOverlay(
              videoItem = videoItem,
              isFollowingTab = isFollowingTab,
              isMuted = isMuted,
              playbackProgress = if (isCurrentActive) playbackProgress else 0f,
              recommendationReason = feedItem.reason,
              isGuest = isGuest,
              onGuestLoginClick = {
                onRequestAuth?.invoke("سجل دخولك إلى الهڨار للانضمام للمجتمع والتفاعل", null)
              },
              onToggleLike = {
                if (isGuest) {
                  onRequestAuth?.invoke("سجل دخولك للإعجاب بهذا الفيديو") {
                    viewModel.toggleLike(videoItem)
                  }
                } else {
                  if (interactionRepository.canLike(currentUser.id, videoItem.id)) {
                    interactionRepository.recordLikeAction(currentUser.id, videoItem.id)
                    val wasLiked = videoItem.isLiked
                    viewModel.toggleLike(videoItem)
                    if (!wasLiked) {
                      notificationRepository.dispatchNotification(
                        recipientUserId = videoItem.ownerId,
                        actor = currentUser,
                        type = NotificationType.Like,
                        targetVideoId = videoItem.id,
                        previewText = "أعجب بفيديو: ${videoItem.title}",
                      )
                    }
                  }
                }
              },
              onToggleBookmark = {
                if (isGuest) {
                  onRequestAuth?.invoke("سجل دخولك لحفظ الفيديو في مفضلاتك") {
                    viewModel.toggleBookmark(videoItem)
                  }
                } else {
                  viewModel.toggleBookmark(videoItem)
                }
              },
              onToggleFollow = {
                if (isGuest) {
                  onRequestAuth?.invoke("سجل دخولك لمتابعة صناع المحتوى") {
                    viewModel.toggleFollow(videoItem.creator)
                  }
                } else {
                  val wasFollowing = videoItem.isFollowing
                  viewModel.toggleFollow(videoItem.creator)
                  if (!wasFollowing) {
                    notificationRepository.dispatchNotification(
                      recipientUserId = videoItem.creator.id,
                      actor = currentUser,
                      type = NotificationType.Follow,
                      targetVideoId = videoItem.id,
                      previewText = "بدأ بمتابعتك",
                    )
                  }
                }
              },
              onToggleMute = { viewModel.playerManager.toggleMute() },
              onSelectTab = { isFollowing -> viewModel.selectFeedTab(isFollowing) },
              onCommentClick = {
                activeCommentsVideo = videoItem
              },
              onShareClick = {
                activeShareVideo = videoItem
              },
              onMoreClick = {
                activeMoreVideo = videoItem
              },
              onSearchClick = onSearchClick,
              onCreatorClick = onCreatorClick,
              onHashtagClick = onHashtagClick,
              onSoundClick = onSoundClick,
              onSeek = { fraction -> viewModel.playerManager.seekTo(fraction) },
              isClearMode = isClearMode,
              onToggleClearMode = { isClearMode = !isClearMode },
            )

            // Dynamic Recommendation Reason Pill Overlay
            Box(
              modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(top = 56.dp, start = 16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x99000000))
                .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp),
            ) {
              Text(
                text = feedItem.reason.labelAr,
                color = HoggarColorTokens.InteractiveAmber,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
              )
            }
          }
        }
      }
    }

    // 1. Comments Bottom Sheet over playing video
    activeCommentsVideo?.let { video ->
      CommentsBottomSheet(
        videoId = video.id,
        videoOwnerId = video.ownerId,
        currentUser = currentUser,
        repository = commentRepository,
        sheetState = commentsSheetState,
        onDismiss = { activeCommentsVideo = null },
        onReportComment = { comment ->
          activeReportTarget = Pair(ReportTargetType.Comment, comment.id)
        },
        isGuest = isGuest,
        onRequestAuth = {
          activeCommentsVideo = null
          onRequestAuth?.invoke("سجل دخولك لكتابة تعليق والمشاركة في النقاش", null)
        },
      )
    }

    // 2. Share Bottom Sheet
    activeShareVideo?.let { video ->
      ShareBottomSheet(
        video = video,
        shareUrl = interactionRepository.getVideoShareUrl(video.id),
        sheetState = shareSheetState,
        onDismiss = { activeShareVideo = null },
        onShareCompleted = {
          interactionRepository.recordShare(video.id)
          scope.launch {
            snackbarHostState.showSnackbar("تمت مشاركة رابط الفيديو")
          }
        },
      )
    }

    // 3. More Options Bottom Sheet
    activeMoreVideo?.let { video ->
      VideoMoreOptionsBottomSheet(
        video = video,
        sheetState = moreSheetState,
        onDismiss = { activeMoreVideo = null },
        onNotInterested = {
          viewModel.markNotInterested(video)
        },
        onToggleBookmark = {
          if (isGuest) {
            onRequestAuth?.invoke("سجل دخولك لحفظ الفيديو في مفضلاتك") {
              viewModel.toggleBookmark(video)
            }
          } else {
            viewModel.toggleBookmark(video)
          }
        },
        onShare = {
          activeShareVideo = video
        },
        onReport = {
          if (isGuest) {
            onRequestAuth?.invoke("سجل دخولك للإبلاغ عن المحتوى", null)
          } else {
            activeReportTarget = Pair(ReportTargetType.Video, video.id)
          }
        },
        onBlockCreator = {
          if (isGuest) {
            onRequestAuth?.invoke("سجل دخولك لحظر المستخدمين", null)
          } else {
            viewModel.blockCreator(video.creator.id)
          }
        },
        onToggleClearMode = {
          isClearMode = true
        },
      )
    }

    // 4. Report Content Dialog
    activeReportTarget?.let { (targetType, targetId) ->
      ReportDialog(
        targetType = targetType,
        targetId = targetId,
        reporterId = currentUser.id,
        onSubmitReport = { report ->
          scope.launch {
            reportRepository.submitReport(report)
            activeReportTarget = null
            snackbarHostState.showSnackbar("تم استلام البلاغ وسيقوم فريق المراجعة بالتحقق منه")
          }
        },
        onDismiss = { activeReportTarget = null },
      )
    }

    SnackbarHost(
      hostState = snackbarHostState,
      modifier = Modifier.align(Alignment.BottomCenter),
    )
  }
}
