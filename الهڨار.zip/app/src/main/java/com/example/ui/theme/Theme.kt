package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable

private val HoggarDarkColorScheme = darkColorScheme(
  primary = HoggarColorTokens.CopperPrimary,
  onPrimary = HoggarColorTokens.TextPrimary,
  primaryContainer = HoggarColorTokens.CopperDark,
  onPrimaryContainer = HoggarColorTokens.TextPrimary,
  secondary = HoggarColorTokens.InteractiveAmber,
  onSecondary = HoggarColorTokens.ObsidianBase,
  secondaryContainer = HoggarColorTokens.SlateContainer,
  onSecondaryContainer = HoggarColorTokens.TextPrimary,
  tertiary = HoggarColorTokens.CopperLight,
  onTertiary = HoggarColorTokens.ObsidianBase,
  background = HoggarColorTokens.ObsidianBase,
  onBackground = HoggarColorTokens.TextPrimary,
  surface = HoggarColorTokens.BasaltSurface,
  onSurface = HoggarColorTokens.TextPrimary,
  surfaceVariant = HoggarColorTokens.SlateContainer,
  onSurfaceVariant = HoggarColorTokens.TextSecondary,
  outline = HoggarColorTokens.BorderSubtle,
  outlineVariant = HoggarColorTokens.TextDisabled,
  error = HoggarColorTokens.ErrorCoral,
  onError = HoggarColorTokens.TextPrimary,
)

@Composable
fun ElHoggarTheme(
  content: @Composable () -> Unit,
) {
  val hoggarColors = HoggarColors()
  val hoggarSpacing = HoggarSpacing()
  val hoggarShapes = HoggarShapesTokens()
  val brandTypography = HoggarBrandTypography()

  CompositionLocalProvider(
    LocalHoggarColors provides hoggarColors,
    LocalHoggarSpacing provides hoggarSpacing,
    LocalHoggarShapes provides hoggarShapes,
    LocalHoggarBrandTypography provides brandTypography,
  ) {
    MaterialTheme(
      colorScheme = HoggarDarkColorScheme,
      typography = HoggarTypography,
      shapes = MaterialThemeShapes,
      content = content,
    )
  }
}

/**
 * Convenience accessor for Hoggar Design Tokens
 */
object HoggarTheme {
  val colors: HoggarColors
    @Composable
    @ReadOnlyComposable
    get() = LocalHoggarColors.current

  val spacing: HoggarSpacing
    @Composable
    @ReadOnlyComposable
    get() = LocalHoggarSpacing.current

  val shapes: HoggarShapesTokens
    @Composable
    @ReadOnlyComposable
    get() = LocalHoggarShapes.current

  val brandTypography: HoggarBrandTypography
    @Composable
    @ReadOnlyComposable
    get() = LocalHoggarBrandTypography.current
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(content: @Composable () -> Unit) = ElHoggarTheme(content = content)
