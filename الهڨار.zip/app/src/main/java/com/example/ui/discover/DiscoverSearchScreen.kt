package com.example.ui.discover

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.CreatorModel
import com.example.model.VideoItem
import com.example.recommendation.model.CreatorSuggestion
import com.example.recommendation.model.SearchResult
import com.example.recommendation.model.TrendingSound
import com.example.recommendation.repository.RecommendationRepository
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarCard
import com.example.ui.components.HoggarDurationBadge
import com.example.ui.components.HoggarEmptyState
import com.example.ui.components.HoggarTag
import com.example.ui.components.HoggarVerifiedBadge
import com.example.ui.theme.HoggarColorTokens

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DiscoverSearchScreen(
  repository: RecommendationRepository,
  onOpenCreatorProfile: (creatorId: String) -> Unit,
  onOpenHashtag: (tag: String) -> Unit,
  onOpenVideo: (VideoItem) -> Unit,
  modifier: Modifier = Modifier,
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedTab by remember { mutableIntStateOf(0) } // 0: الكل, 1: الحسابات, 2: الفيديوهات, 3: الوسوم, 4: الأصوات

  val searchResult by repository.searchAll(searchQuery).collectAsState(initial = SearchResult(query = ""))
  val suggestedCreatorDetails by repository.getSuggestedCreatorDetails().collectAsState(initial = emptyList())
  val trendingHashtags by repository.getTrendingHashtags().collectAsState(initial = emptyList())
  val trendingSounds by repository.getTrendingSounds().collectAsState(initial = emptyList())

  val isSearching = searchQuery.trim().isNotEmpty()

  val displayTrendingTags = if (trendingHashtags.isNotEmpty()) {
    trendingHashtags.take(12).map { it.first }
  } else {
    listOf(
      "#الهڨار",
      "#قمة_تاهات",
      "#تمنراست",
      "#صناعة_الفضة",
      "#تيناريوين",
      "#أسكرام",
      "#شاي_صحراوي",
      "#طاسيلي_ناجر",
      "#موسيقى_الطيندي",
    )
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .padding(horizontal = 16.dp)
      .testTag("discover_search_screen"),
  ) {
    Spacer(modifier = Modifier.height(12.dp))

    // Search Input Bar
    TextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp))
        .testTag("input_search"),
      placeholder = {
        Text(
          text = "ابحث عن @حسابات، فيديوهات، أو #وسوم...",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 13.sp,
        )
      },
      leadingIcon = {
        Icon(
          imageVector = Icons.Filled.Search,
          contentDescription = "Search",
          tint = HoggarColorTokens.InteractiveAmber,
        )
      },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Clear",
            tint = HoggarColorTokens.TextSecondary,
            modifier = Modifier.clickable { searchQuery = "" },
          )
        }
      },
      singleLine = true,
      colors = TextFieldDefaults.colors(
        focusedContainerColor = HoggarColorTokens.SlateContainer,
        unfocusedContainerColor = HoggarColorTokens.SlateContainer,
        focusedTextColor = HoggarColorTokens.TextPrimary,
        unfocusedTextColor = HoggarColorTokens.TextPrimary,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
      ),
    )

    Spacer(modifier = Modifier.height(14.dp))

    if (!isSearching) {
      // Default Discovery View: Trending Hashtags + Suggested Creators + Trending Sounds
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(22.dp),
      ) {
        // 1. Trending Tags Section
        item {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.TrendingUp,
              contentDescription = null,
              tint = HoggarColorTokens.InteractiveAmber,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "الوسوم الأكثر رواجًا في الهڨار",
              color = HoggarColorTokens.TextPrimary,
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            displayTrendingTags.forEach { tag ->
              HoggarTag(
                text = tag,
                isInteractive = true,
                modifier = Modifier.clickable { onOpenHashtag(tag) },
              )
            }
          }
        }

        // 2. Personalized Suggested Sahara Creators Section
        item {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Filled.AutoAwesome,
              contentDescription = null,
              tint = HoggarColorTokens.InteractiveAmber,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "صُنّاع محتوى ومستكشفون مقترحون لك",
              color = HoggarColorTokens.TextPrimary,
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            suggestedCreatorDetails.forEach { suggestion ->
              CreatorRowCard(
                creator = suggestion.creator,
                recommendationReason = suggestion.reasonAr,
                onClick = { onOpenCreatorProfile(suggestion.creator.id) },
              )
            }
          }
        }

        // 3. Trending Desert Sounds & Music Section
        if (trendingSounds.isNotEmpty()) {
          item {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.MusicNote,
                contentDescription = null,
                tint = HoggarColorTokens.InteractiveAmber,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "أصوات وموسيقى صحراوية رائجة",
                color = HoggarColorTokens.TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              trendingSounds.take(4).forEach { sound ->
                SoundCard(sound = sound)
              }
            }
          }
        }

        item {
          Spacer(modifier = Modifier.height(30.dp))
        }
      }
    } else {
      // Live Search Results with Filter Tabs
      val tabs = listOf("الكل", "الحسابات", "الفيديوهات", "الوسوم", "الأصوات")
      ScrollableTabRow(
        selectedTabIndex = selectedTab,
        containerColor = Color.Transparent,
        contentColor = HoggarColorTokens.TextPrimary,
        edgePadding = 0.dp,
        indicator = { tabPositions ->
          SecondaryIndicator(
            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
            color = HoggarColorTokens.InteractiveAmber,
          )
        },
      ) {
        tabs.forEachIndexed { index, title ->
          Tab(
            selected = selectedTab == index,
            onClick = { selectedTab = index },
            text = {
              Text(
                text = title,
                color = if (selectedTab == index) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextSecondary,
                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                fontSize = 13.sp,
              )
            },
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        // 1. Matched Accounts (الحسابات)
        if (selectedTab == 0 || selectedTab == 1) {
          if (searchResult.matchedCreators.isNotEmpty()) {
            item {
              SectionHeader(title = "الحسابات المطابقة", icon = Icons.Filled.Person)
            }
            items(searchResult.matchedCreators) { creator ->
              CreatorRowCard(creator = creator, onClick = { onOpenCreatorProfile(creator.id) })
            }
          }
        }

        // 2. Matched Videos (الفيديوهات)
        if (selectedTab == 0 || selectedTab == 2) {
          if (searchResult.matchedVideos.isNotEmpty()) {
            item {
              SectionHeader(title = "الفيديوهات المطابقة", icon = Icons.Filled.Videocam)
            }
            items(searchResult.matchedVideos) { video ->
              VideoSearchCard(video = video, onClick = { onOpenVideo(video) })
            }
          }
        }

        // 3. Matched Hashtags (الوسوم)
        if (selectedTab == 0 || selectedTab == 3) {
          if (searchResult.matchedHashtags.isNotEmpty()) {
            item {
              SectionHeader(title = "الوسوم المطابقة", icon = Icons.Filled.Tag)
            }
            items(searchResult.matchedHashtags) { (tag, count) ->
              HashtagRowCard(
                tag = tag,
                count = count,
                onClick = { onOpenHashtag(tag) },
              )
            }
          }
        }

        // 4. Matched Sounds (الأصوات)
        if (selectedTab == 0 || selectedTab == 4) {
          val matchedSounds = trendingSounds.filter {
            it.title.contains(searchQuery.trim(), ignoreCase = true) ||
              it.artist.contains(searchQuery.trim(), ignoreCase = true)
          }
          if (matchedSounds.isNotEmpty()) {
            item {
              SectionHeader(title = "الموسيقى والأصوات المطابقة", icon = Icons.Filled.MusicNote)
            }
            items(matchedSounds) { sound ->
              SoundCard(sound = sound)
            }
          }
        }

        // Empty state when no matches found
        val totalMatches = searchResult.matchedCreators.size + searchResult.matchedVideos.size + searchResult.matchedHashtags.size
        if (totalMatches == 0) {
          item {
            HoggarEmptyState(
              title = "لا توجد نتائج بحث مطابقة",
              description = "جرّب البحث بكلمات أخرى أو تصفح وسوم الهڨار الرائجة",
              actionText = "مسح البحث",
              onActionClick = { searchQuery = "" },
            )
          }
        }

        item {
          Spacer(modifier = Modifier.height(30.dp))
        }
      }
    }
  }
}

@Composable
private fun SectionHeader(title: String, icon: ImageVector) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier.padding(vertical = 4.dp),
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = HoggarColorTokens.InteractiveAmber,
      modifier = Modifier.size(18.dp),
    )
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = title,
      color = HoggarColorTokens.TextPrimary,
      fontSize = 15.sp,
      fontWeight = FontWeight.Bold,
    )
  }
}

@Composable
private fun CreatorRowCard(
  creator: CreatorModel,
  recommendationReason: String? = null,
  onClick: () -> Unit,
) {
  HoggarCard(
    contentPadding = 12.dp,
    modifier = Modifier.clickable(onClick = onClick),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f),
      ) {
        Box(
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(HoggarColorTokens.SlateContainer),
          contentAlignment = Alignment.Center,
        ) {
          if (creator.avatarUrl.isNotEmpty()) {
            AsyncImage(model = creator.avatarUrl, contentDescription = null, modifier = Modifier.fillMaxSize().clip(CircleShape))
          } else {
            Text(text = creator.displayName.take(1), color = HoggarColorTokens.InteractiveAmber, fontSize = 18.sp, fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = creator.displayName, color = HoggarColorTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            if (creator.isVerified) {
              Spacer(modifier = Modifier.width(4.dp))
              HoggarVerifiedBadge(size = 14.dp)
            }
          }
          Text(text = "@${creator.username}", color = HoggarColorTokens.TextSecondary, fontSize = 12.sp)
          if (!recommendationReason.isNullOrEmpty()) {
            Spacer(modifier = Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = null,
                tint = HoggarColorTokens.InteractiveAmber,
                modifier = Modifier.size(11.dp),
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = recommendationReason,
                color = HoggarColorTokens.InteractiveAmber,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
              )
            }
          } else if (creator.bio.isNotEmpty()) {
            Text(text = creator.bio, color = HoggarColorTokens.TextTertiary, fontSize = 11.sp, maxLines = 1)
          }
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(HoggarColorTokens.CopperPrimary)
          .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
      ) {
        Text(text = "عرض الحساب", color = HoggarColorTokens.TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
private fun SoundCard(
  sound: TrendingSound,
  onClick: () -> Unit = {},
) {
  HoggarCard(
    contentPadding = 12.dp,
    modifier = Modifier.clickable(onClick = onClick),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f),
      ) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(HoggarColorTokens.SlateContainer)
            .border(1.dp, HoggarColorTokens.CopperPrimary.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.MusicNote,
            contentDescription = null,
            tint = HoggarColorTokens.InteractiveAmber,
            modifier = Modifier.size(22.dp),
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Text(text = sound.title, color = HoggarColorTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(2.dp))
          Text(text = sound.artist, color = HoggarColorTokens.TextSecondary, fontSize = 12.sp)
        }
      }

      Text(
        text = "${sound.usageCount} فيديو",
        color = HoggarColorTokens.InteractiveAmber,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
      )
    }
  }
}

@Composable
private fun HashtagRowCard(
  tag: String,
  count: Long,
  onClick: () -> Unit,
) {
  HoggarCard(
    contentPadding = 12.dp,
    modifier = Modifier.clickable(onClick = onClick),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(HoggarColorTokens.SlateContainer),
          contentAlignment = Alignment.Center,
        ) {
          Icon(imageVector = Icons.Filled.Tag, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(20.dp))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Text(text = tag, color = HoggarColorTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text(text = "$count فيديوهات مرتبطة", color = HoggarColorTokens.TextTertiary, fontSize = 11.sp)
        }
      }

      Text(text = "استكشاف ←", color = HoggarColorTokens.InteractiveAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
  }
}

@Composable
private fun VideoSearchCard(
  video: VideoItem,
  onClick: () -> Unit,
) {
  HoggarCard(
    contentPadding = 10.dp,
    modifier = Modifier.clickable(onClick = onClick),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .width(70.dp)
          .aspectRatio(9f / 14f)
          .clip(RoundedCornerShape(6.dp))
          .background(HoggarColorTokens.BasaltSurface),
      ) {
        AsyncImage(model = video.thumbnailUrl, contentDescription = video.title, modifier = Modifier.fillMaxSize())
        HoggarDurationBadge(durationText = "${video.durationSeconds}s", modifier = Modifier.align(Alignment.BottomEnd).padding(3.dp))
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(text = video.title, color = HoggarColorTokens.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = video.description, color = HoggarColorTokens.TextSecondary, fontSize = 11.sp, maxLines = 2, lineHeight = 15.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "بواسطة @${video.creator.username}", color = HoggarColorTokens.InteractiveAmber, fontSize = 11.sp)
      }
    }
  }
}
