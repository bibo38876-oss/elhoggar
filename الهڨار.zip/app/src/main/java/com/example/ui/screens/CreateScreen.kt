package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HoggarLogoMark
import com.example.ui.theme.HoggarColorTokens

@Composable
fun CreateScreen(
  onClose: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedDuration by remember { mutableIntStateOf(60) } // 15 or 60 seconds

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF07080A))
      .statusBarsPadding()
      .testTag("create_screen"),
  ) {
    // 1. Top Controls Bar: Close, Add Sound, Flip
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp)
        .align(Alignment.TopCenter),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(Color(0x33000000))
          .clickable(onClick = onClose)
          .testTag("btn_close_create"),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.Close,
          contentDescription = "Close",
          tint = HoggarColorTokens.TextPrimary,
        )
      }

      // Add Sound Pill
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(Color(0x44000000))
          .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(20.dp))
          .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(
          imageVector = Icons.Filled.MusicNote,
          contentDescription = null,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "إضافة صوت أو موسيقى",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
        )
      }

      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(Color(0x33000000)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.Cameraswitch,
          contentDescription = "Flip Camera",
          tint = HoggarColorTokens.TextPrimary,
        )
      }
    }

    // 2. Right Camera Utilities
    Column(
      modifier = Modifier
        .align(Alignment.CenterEnd)
        .padding(end = 16.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      CameraToolItem(icon = Icons.Filled.Speed, label = "السرعة")
      CameraToolItem(icon = Icons.Filled.Timer, label = "المؤقت")
      CameraToolItem(icon = Icons.Filled.FlashOn, label = "الفلاش")
    }

    // 3. Center Camera Framing Placeholder
    Box(
      modifier = Modifier
        .align(Alignment.Center)
        .size(240.dp)
        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(24.dp)),
      contentAlignment = Alignment.Center,
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        HoggarLogoMark(size = 56.dp, showGlow = true)
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "استوديو الهڨار",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = "جاهز لتسجيل فيديو عمودي حتى 60 ثانية",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
        )
      }
    }

    // 4. Bottom Controls: Duration Switcher & Shutter Trigger
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.BottomCenter)
        .padding(bottom = 36.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      // 15s vs 60s max duration pill
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(HoggarColorTokens.SlateContainer)
          .padding(4.dp),
      ) {
        DurationOption(
          label = "15 ثانية",
          isSelected = selectedDuration == 15,
          onClick = { selectedDuration = 15 },
        )
        DurationOption(
          label = "60 ثانية (أقصى)",
          isSelected = selectedDuration == 60,
          onClick = { selectedDuration = 60 },
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Center Record Crest Shutter Button
      Box(
        modifier = Modifier
          .size(80.dp)
          .clip(CircleShape)
          .background(Color(0x33FF6926))
          .border(3.dp, HoggarColorTokens.InteractiveAmber, CircleShape)
          .padding(8.dp)
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = ripple(bounded = false, radius = 40.dp),
            onClick = {},
          )
          .testTag("btn_shutter_record"),
        contentAlignment = Alignment.Center,
      ) {
        Box(
          modifier = Modifier
            .size(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(HoggarColorTokens.CopperPrimary),
          contentAlignment = Alignment.Center,
        ) {
          HoggarLogoMark(size = 30.dp)
        }
      }
    }
  }
}

@Composable
private fun CameraToolItem(icon: ImageVector, label: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Box(
      modifier = Modifier
        .size(40.dp)
        .clip(CircleShape)
        .background(Color(0x44000000)),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = HoggarColorTokens.TextPrimary,
        modifier = Modifier.size(20.dp),
      )
    }
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = label,
      color = HoggarColorTokens.TextPrimary,
      fontSize = 11.sp,
    )
  }
}

@Composable
private fun DurationOption(label: String, isSelected: Boolean, onClick: () -> Unit) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(16.dp))
      .background(if (isSelected) HoggarColorTokens.InteractiveAmber else Color.Transparent)
      .clickable(onClick = onClick)
      .padding(horizontal = 14.dp, vertical = 6.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = label,
      color = if (isSelected) HoggarColorTokens.ObsidianBase else HoggarColorTokens.TextSecondary,
      fontSize = 12.sp,
      fontWeight = FontWeight.Bold,
    )
  }
}
