package com.example.ui.feed

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.VideoItem
import com.example.recommendation.model.FeedItemReason
import com.example.ui.components.HoggarDurationBadge
import com.example.ui.components.HoggarLogoMark
import com.example.ui.components.HoggarVerifiedBadge
import com.example.ui.components.HoggarVideoAction
import com.example.ui.components.HoggarWatermark
import com.example.ui.theme.HoggarColorTokens

@Composable
fun VideoOverlay(
  videoItem: VideoItem,
  isFollowingTab: Boolean,
  isMuted: Boolean,
  playbackProgress: Float,
  onToggleLike: () -> Unit,
  onToggleBookmark: () -> Unit,
  onToggleFollow: () -> Unit,
  onToggleMute: () -> Unit,
  onSelectTab: (Boolean) -> Unit,
  onCommentClick: () -> Unit,
  onShareClick: () -> Unit,
  onMoreClick: () -> Unit,
  onSearchClick: () -> Unit,
  onCreatorClick: (creatorId: String) -> Unit = {},
  onHashtagClick: (String) -> Unit = {},
  onSoundClick: (soundTitle: String, soundAuthor: String) -> Unit = { _, _ -> },
  onSeek: (Float) -> Unit = {},
  isClearMode: Boolean = false,
  onToggleClearMode: () -> Unit = {},
  recommendationReason: FeedItemReason? = null,
  isGuest: Boolean = false,
  onGuestLoginClick: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  var isDescriptionExpanded by remember { mutableStateOf(false) }
  var isScrubbing by remember { mutableStateOf(false) }
  var scrubFraction by remember { mutableStateOf(0f) }

  val effectiveProgress = if (isScrubbing) scrubFraction else playbackProgress

  // Rotating disc animation for music
  val discTransition = rememberInfiniteTransition(label = "music_disc_rotation")
  val discRotation by discTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(4000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "disc_rotation",
  )

  Box(modifier = modifier.fillMaxSize()) {
    // 1. Regular Interactive Overlays (Hidden in Clear Mode)
    AnimatedVisibility(
      visible = !isClearMode,
      enter = fadeIn(tween(250)),
      exit = fadeOut(tween(250)),
      modifier = Modifier.fillMaxSize(),
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        // Top and Bottom Scrim Gradients for text and action legibility
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .align(Alignment.TopCenter)
            .background(
              Brush.verticalGradient(
                listOf(HoggarColorTokens.ScrimTop, Color.Transparent),
              ),
            ),
        )
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(260.dp)
            .align(Alignment.BottomCenter)
            .background(
              Brush.verticalGradient(
                listOf(Color.Transparent, HoggarColorTokens.ScrimBottom),
              ),
            ),
        )

        // Top Header: Watermark logo + Following/For You tabs + Search icon
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .align(Alignment.TopCenter),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          // Discrete El Hoggar Watermark in the corner
          HoggarWatermark()

          // Feed Tabs: "Following" / "For You"
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
          ) {
            Text(
              text = "أتابعه",
              color = if (isFollowingTab) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
              fontSize = 16.sp,
              fontWeight = if (isFollowingTab) FontWeight.Bold else FontWeight.Medium,
              modifier = Modifier
                .clickable(
                  interactionSource = remember { MutableInteractionSource() },
                  indication = null,
                  onClick = { onSelectTab(true) },
                )
                .padding(horizontal = 8.dp, vertical = 4.dp)
                .testTag("tab_following"),
            )

            Box(
              modifier = Modifier
                .size(4.dp)
                .clip(CircleShape)
                .background(HoggarColorTokens.TextSecondary),
            )

            Text(
              text = "لك",
              color = if (!isFollowingTab) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
              fontSize = 16.sp,
              fontWeight = if (!isFollowingTab) FontWeight.Bold else FontWeight.Medium,
              modifier = Modifier
                .clickable(
                  interactionSource = remember { MutableInteractionSource() },
                  indication = null,
                  onClick = { onSelectTab(false) },
                )
                .padding(horizontal = 8.dp, vertical = 4.dp)
                .testTag("tab_for_you"),
            )
          }

          // Search, Duration badge & Guest Login
          Row(verticalAlignment = Alignment.CenterVertically) {
            if (isGuest && onGuestLoginClick != null) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(16.dp))
                  .background(HoggarColorTokens.SlateContainer.copy(alpha = 0.85f))
                  .border(1.dp, HoggarColorTokens.InteractiveAmber.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                  .clickable(onClick = onGuestLoginClick)
                  .padding(horizontal = 10.dp, vertical = 5.dp)
                  .testTag("btn_guest_chip_login"),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = "تسجيل الدخول",
                  color = HoggarColorTokens.InteractiveAmber,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
            }

            HoggarDurationBadge("${videoItem.durationSeconds}s")
            Spacer(modifier = Modifier.width(8.dp))

            // Clear Mode Toggle Button
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x33000000))
                .clickable(
                  interactionSource = remember { MutableInteractionSource() },
                  indication = ripple(bounded = false, radius = 20.dp),
                  onClick = onToggleClearMode,
                )
                .testTag("btn_toggle_clear_mode_top"),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.Visibility,
                contentDescription = "وضع الشاشة النظيفة",
                tint = HoggarColorTokens.TextSecondary,
                modifier = Modifier.size(18.dp),
              )
            }

            Spacer(modifier = Modifier.width(8.dp))
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x33000000))
                .clickable(
                  interactionSource = remember { MutableInteractionSource() },
                  indication = ripple(bounded = false, radius = 20.dp),
                  onClick = onSearchClick,
                ),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = "Search",
                tint = HoggarColorTokens.TextPrimary,
                modifier = Modifier.size(20.dp),
              )
            }
          }
        }

        // Right-side Clean Action Column: Like, Comment, Share, More, Music Disc
        Column(
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(end = 12.dp, bottom = 60.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          // 1. Like Button with formatted count & active tint
          HoggarVideoAction(
            icon = if (videoItem.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
            label = formatStatCount(videoItem.stats.likesCount),
            onClick = onToggleLike,
            isActive = videoItem.isLiked,
            activeTint = HoggarColorTokens.InteractiveAmber,
            testTag = "btn_like_${videoItem.id}",
          )

          // 2. Comments Button
          HoggarVideoAction(
            icon = Icons.Outlined.ChatBubbleOutline,
            label = formatStatCount(videoItem.stats.commentsCount),
            onClick = onCommentClick,
            testTag = "btn_comments_${videoItem.id}",
          )

          // 3. Share Button
          HoggarVideoAction(
            icon = Icons.Outlined.Share,
            label = formatStatCount(videoItem.stats.sharesCount),
            onClick = onShareClick,
            testTag = "btn_share_${videoItem.id}",
          )

          // 4. More Options Button
          HoggarVideoAction(
            icon = Icons.Filled.MoreVert,
            label = "",
            onClick = onMoreClick,
            testTag = "btn_more_${videoItem.id}",
          )

          // Rotating Music Disc with Hoggar Copper Ring (Clickable to open Sound detail)
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(HoggarColorTokens.SlateContainer)
              .border(1.5.dp, HoggarColorTokens.CopperPrimary, CircleShape)
              .rotate(discRotation)
              .clickable {
                onSoundClick(
                  videoItem.soundTitle,
                  videoItem.soundAuthor.ifEmpty { videoItem.creator.displayName },
                )
              },
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.MusicNote,
              contentDescription = null,
              tint = HoggarColorTokens.InteractiveAmber,
              modifier = Modifier.size(20.dp),
            )
          }
        }

        // Bottom Video Info Overlay: Avatar + @username + Follow button, Description, Hashtags, Audio
        Column(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(start = 16.dp, end = 76.dp, bottom = 24.dp),
        ) {
          // Explainable Algorithm Tag ("لماذا هذا الفيديو؟")
          if (recommendationReason != null && !isFollowingTab) {
            Box(
              modifier = Modifier
                .padding(bottom = 6.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0x33FF6926))
                .border(0.5.dp, HoggarColorTokens.InteractiveAmber.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp),
              contentAlignment = Alignment.Center,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Filled.AutoAwesome,
                  contentDescription = null,
                  tint = HoggarColorTokens.InteractiveAmber,
                  modifier = Modifier.size(12.dp),
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = recommendationReason.labelAr,
                  color = HoggarColorTokens.InteractiveAmber,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.SemiBold,
                )
              }
            }
          }

          // Bottom Row: Avatar + Username + Verified + Small Follow Button
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            // Creator Avatar (38dp circular with copper border)
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(HoggarColorTokens.BasaltSurface)
                .border(1.5.dp, HoggarColorTokens.CopperPrimary, CircleShape)
                .clickable(
                  interactionSource = remember { MutableInteractionSource() },
                  indication = ripple(bounded = false, radius = 20.dp),
                  onClick = { onCreatorClick(videoItem.creator.id) },
                ),
              contentAlignment = Alignment.Center,
            ) {
              AsyncImage(
                model = videoItem.creator.avatarUrl,
                contentDescription = videoItem.creator.displayName,
                modifier = Modifier.fillMaxSize().clip(CircleShape),
              )
            }

            // Username
            Text(
              text = "@${videoItem.creator.username}",
              color = HoggarColorTokens.TextPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.clickable { onCreatorClick(videoItem.creator.id) },
            )

            // Verified Badge
            if (videoItem.creator.isVerified) {
              HoggarVerifiedBadge(size = 16.dp)
            }

            // Small, Crisp Follow Button
            if (!videoItem.isFollowing) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(12.dp))
                  .border(1.dp, HoggarColorTokens.CopperPrimary, RoundedCornerShape(12.dp))
                  .background(HoggarColorTokens.CopperPrimary.copy(alpha = 0.25f))
                  .clickable(onClick = onToggleFollow)
                  .padding(horizontal = 8.dp, vertical = 3.dp)
                  .testTag("btn_follow_creator_${videoItem.creator.id}"),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = "متابعة",
                  color = HoggarColorTokens.TextPrimary,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.SemiBold,
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Video Description (Tap to expand/collapse)
          Text(
            text = videoItem.description,
            color = HoggarColorTokens.TextPrimary,
            fontSize = 13.sp,
            lineHeight = 19.sp,
            maxLines = if (isDescriptionExpanded) 6 else 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.clickable { isDescriptionExpanded = !isDescriptionExpanded },
          )

          // Clickable Hashtags
          if (videoItem.tags.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              videoItem.tags.take(3).forEach { tag ->
                val formattedTag = if (tag.startsWith("#")) tag else "#$tag"
                Text(
                  text = formattedTag,
                  color = HoggarColorTokens.InteractiveAmber,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier
                    .clickable { onHashtagClick(formattedTag) }
                    .padding(vertical = 2.dp),
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Audio Track Information (Clickable to open Sound Detail)
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable {
              onSoundClick(
                videoItem.soundTitle,
                videoItem.soundAuthor.ifEmpty { videoItem.creator.displayName },
              )
            },
          ) {
            Icon(
              imageVector = Icons.Filled.MusicNote,
              contentDescription = null,
              tint = HoggarColorTokens.TextSecondary,
              modifier = Modifier.size(13.dp),
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
              text = "${videoItem.soundTitle} - ${videoItem.soundAuthor.ifEmpty { videoItem.creator.displayName }}",
              color = HoggarColorTokens.TextSecondary,
              fontSize = 11.sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }

    // 2. Floating Exit Clear Mode Button (Visible ONLY when in Clear Mode)
    if (isClearMode) {
      Box(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .padding(bottom = 36.dp)
          .clip(RoundedCornerShape(20.dp))
          .background(Color(0xDD0D0F12))
          .border(1.dp, HoggarColorTokens.CopperPrimary, RoundedCornerShape(20.dp))
          .clickable(onClick = onToggleClearMode)
          .padding(horizontal = 14.dp, vertical = 8.dp)
          .testTag("btn_exit_clear_mode"),
        contentAlignment = Alignment.Center,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Visibility,
            contentDescription = null,
            tint = HoggarColorTokens.InteractiveAmber,
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = "خروج من وضع الشاشة النظيفة",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
          )
        }
      }
    }

    // 5. Interactive 60-Second Video Scrubber / Progress Line
    // Floating Time Badge when Scrubbing
    if (isScrubbing) {
      val totalSecs = videoItem.durationSeconds.coerceAtLeast(1)
      val currentSecs = (effectiveProgress * totalSecs).toInt()
      val formattedCurr = String.format("%02d:%02d", currentSecs / 60, currentSecs % 60)
      val formattedTot = String.format("%02d:%02d", totalSecs / 60, totalSecs % 60)

      Box(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .padding(bottom = 32.dp)
          .clip(RoundedCornerShape(14.dp))
          .background(Color(0xEE0D0F12))
          .border(1.dp, HoggarColorTokens.InteractiveAmber, RoundedCornerShape(14.dp))
          .padding(horizontal = 16.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = "$formattedCurr / $formattedTot",
          color = HoggarColorTokens.InteractiveAmber,
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
        )
      }
    }

    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(if (isScrubbing) 24.dp else 6.dp)
        .align(Alignment.BottomCenter)
        .pointerInput(videoItem.id) {
          detectTapGestures(
            onPress = { offset ->
              isScrubbing = true
              val fraction = (offset.x / size.width).coerceIn(0f, 1f)
              scrubFraction = fraction
              onSeek(fraction)
              tryAwaitRelease()
              isScrubbing = false
            }
          )
        }
        .pointerInput(videoItem.id) {
          detectHorizontalDragGestures(
            onDragStart = { offset ->
              isScrubbing = true
              val fraction = (offset.x / size.width).coerceIn(0f, 1f)
              scrubFraction = fraction
              onSeek(fraction)
            },
            onDragEnd = { isScrubbing = false },
            onDragCancel = { isScrubbing = false },
            onHorizontalDrag = { change, _ ->
              val fraction = (change.position.x / size.width).coerceIn(0f, 1f)
              scrubFraction = fraction
              onSeek(fraction)
            }
          )
        },
      contentAlignment = Alignment.BottomStart,
    ) {
      // Base track
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(if (isScrubbing) 5.dp else 2.5.dp)
          .background(Color(0x44FFFFFF)),
      )
      // Progress fill with glow
      Box(
        modifier = Modifier
          .fillMaxWidth(effectiveProgress.coerceIn(0f, 1f))
          .height(if (isScrubbing) 5.dp else 2.5.dp)
          .background(HoggarColorTokens.InteractiveAmber),
      )
    }
  }
}

private fun formatStatCount(count: Long): String {
  return when {
    count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
    count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
    else -> count.toString()
  }
}
