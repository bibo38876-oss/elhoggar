package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DataSaverOn
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.theme.HoggarColorTokens

enum class VideoDataMode(val title: String, val subtitle: String) {
  Auto("تلقائي (مستحسن)", "يتم ضبط الدقة تلقائيًا وفقًا لسرعة الشبكة الحالية"),
  DataSaver("توفير البيانات", "تقليل جودة الفيديو عند استخدام بيانات الهاتف الجوال"),
  HighQuality("أعلى جودة", "تشغيل الفيديو بأعلى دقة متوفرة على شبكة Wi-Fi"),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DataSaverSettingsDialog(
  onDismiss: () -> Unit,
) {
  var selectedMode by remember { mutableStateOf(VideoDataMode.Auto) }
  var cacheSizeMb by remember { mutableStateOf(18.4) }
  var isCacheCleared by remember { mutableStateOf(false) }

  BasicAlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier
      .clip(RoundedCornerShape(16.dp))
      .background(HoggarColorTokens.BasaltSurface)
      .padding(20.dp),
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.DataSaverOn,
            contentDescription = null,
            tint = HoggarColorTokens.InteractiveAmber,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "استهلاك البيانات والذاكرة",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
          )
        }
        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Close",
            tint = HoggarColorTokens.TextSecondary,
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
      Text(
        text = "إعدادات جودة البث واستهلاك الإنترنت:",
        color = HoggarColorTokens.TextSecondary,
        fontSize = 12.sp,
      )
      Spacer(modifier = Modifier.height(12.dp))

      VideoDataMode.values().forEach { mode ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { selectedMode = mode }
            .padding(vertical = 8.dp, horizontal = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          RadioButton(
            selected = selectedMode == mode,
            onClick = { selectedMode = mode },
            colors = RadioButtonDefaults.colors(
              selectedColor = HoggarColorTokens.InteractiveAmber,
              unselectedColor = HoggarColorTokens.TextTertiary,
            ),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Column {
            Text(
              text = mode.title,
              color = HoggarColorTokens.TextPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold,
            )
            Text(
              text = mode.subtitle,
              color = HoggarColorTokens.TextTertiary,
              fontSize = 11.sp,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(1.dp)
          .background(HoggarColorTokens.BorderSubtle),
      )
      Spacer(modifier = Modifier.height(14.dp))

      // Cache Management Section
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "الذاكرة المؤقتة (Cache)",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = if (isCacheCleared) "تم تفريغ الذاكرة المؤقتة بنجاح" else "الحجم المستهلك: ${String.format("%.1f", cacheSizeMb)} MB",
            color = if (isCacheCleared) HoggarColorTokens.SuccessOasis else HoggarColorTokens.TextTertiary,
            fontSize = 11.sp,
          )
        }

        HoggarButton(
          text = if (isCacheCleared) "تم المسح" else "مسح الذاكرة",
          icon = Icons.Filled.CleaningServices,
          onClick = {
            cacheSizeMb = 0.0
            isCacheCleared = true
          },
          variant = HoggarButtonVariant.Outlined,
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      HoggarButton(
        text = "إغلاق",
        onClick = onDismiss,
        variant = HoggarButtonVariant.PrimaryCopper,
        modifier = Modifier.fillMaxWidth(),
      )
    }
  }
}
