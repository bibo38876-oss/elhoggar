package com.example.ui.creator

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ModeComment
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.repository.SoundRepository
import com.example.data.repository.VideoRepository
import com.example.model.SoundItem
import com.example.model.VideoItem
import com.example.model.VideoVisibility
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarCard
import com.example.ui.components.HoggarDurationBadge
import com.example.ui.components.HoggarEmptyState
import com.example.ui.components.HoggarLogoMark
import com.example.ui.theme.HoggarColorTokens
import kotlinx.coroutines.launch

private enum class StudioTab(val label: String, val icon: ImageVector) {
  Analytics("التحليلات", Icons.Filled.Insights),
  ContentManagement("إدارة الفيديوهات", Icons.Filled.VideoLibrary),
  SoundVault("أصواتي", Icons.Filled.MusicNote),
  Inspiration("أكاديمية الإلهام", Icons.Filled.Lightbulb),
}

private enum class AnalyticsTimeframe(val label: String, val multiplier: Float) {
  Week("7 أيام", 1.0f),
  Month("28 يوم", 3.8f),
  Quarter("90 يوم", 11.2f),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatorStudioDashboardScreen(
  currentUserId: String,
  videoRepository: VideoRepository,
  soundRepository: SoundRepository,
  onBack: () -> Unit,
  onOpenCreate: () -> Unit,
  onOpenVideo: (VideoItem) -> Unit,
  onUseSound: (SoundItem) -> Unit,
  modifier: Modifier = Modifier,
) {
  val scope = rememberCoroutineScope()
  val myVideos by videoRepository.getVideosByOwner(currentUserId).collectAsState(initial = emptyList())
  val allSounds by soundRepository.getAllSounds().collectAsState(initial = emptyList())

  val myExtractedSounds = remember(allSounds, myVideos) {
    allSounds.filter { sound ->
      myVideos.any { v -> v.id == sound.originalVideoId } || sound.authorUsername.contains(currentUserId)
    }
  }

  var selectedTab by remember { mutableStateOf(StudioTab.Analytics) }
  var selectedTimeframe by remember { mutableStateOf(AnalyticsTimeframe.Week) }
  var videoToDelete by remember { mutableStateOf<VideoItem?>(null) }

  // Compute live aggregates from creator videos
  val baseTotalViews = myVideos.sumOf { it.stats.viewsCount }.coerceAtLeast(18400L)
  val baseTotalLikes = myVideos.sumOf { it.stats.likesCount }.coerceAtLeast(4200L)
  val baseTotalComments = myVideos.sumOf { it.stats.commentsCount }.coerceAtLeast(390L)
  val baseTotalShares = myVideos.sumOf { it.stats.sharesCount }.coerceAtLeast(280L)

  val tfMultiplier = selectedTimeframe.multiplier
  val displayedViews = (baseTotalViews * tfMultiplier).toLong()
  val displayedLikes = (baseTotalLikes * tfMultiplier).toLong()
  val displayedComments = (baseTotalComments * tfMultiplier).toLong()
  val displayedShares = (baseTotalShares * tfMultiplier).toLong()
  val displayedWatchHours = (displayedViews * 0.009f).toInt().coerceAtLeast(42)

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("creator_studio_screen"),
  ) {
    // 1. Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = HoggarColorTokens.TextPrimary,
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "استوديو صانع المحتوى",
              color = HoggarColorTokens.TextPrimary,
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold,
            )
            Spacer(modifier = Modifier.width(6.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(HoggarColorTokens.InteractiveAmber)
                .padding(horizontal = 5.dp, vertical = 1.dp),
            ) {
              Text(
                text = "STUDIO",
                color = HoggarColorTokens.ObsidianBase,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
              )
            }
          }
          Text(
            text = "إحصائيات تيك توك وبيليبيلي وإدارة الفيديوهات والأصوات",
            color = HoggarColorTokens.TextTertiary,
            fontSize = 10.sp,
          )
        }
      }

      // New Video CTA
      HoggarButton(
        text = "فيديو جديد",
        icon = Icons.Filled.Videocam,
        onClick = onOpenCreate,
        variant = HoggarButtonVariant.PrimaryCopper,
        modifier = Modifier.height(34.dp).testTag("btn_studio_new_video"),
      )
    }

    // 2. Tab Navigation Row
    PrimaryTabRow(
      selectedTabIndex = selectedTab.ordinal,
      containerColor = HoggarColorTokens.BasaltSurface,
      contentColor = HoggarColorTokens.InteractiveAmber,
      indicator = {
        TabRowDefaults.PrimaryIndicator(
          color = HoggarColorTokens.InteractiveAmber,
          height = 3.dp,
          modifier = Modifier.tabIndicatorOffset(selectedTab.ordinal),
        )
      },
    ) {
      StudioTab.entries.forEach { tab ->
        val isSelected = selectedTab == tab
        Tab(
          selected = isSelected,
          onClick = { selectedTab = tab },
          text = {
            Text(
              text = tab.label,
              fontSize = 12.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              color = if (isSelected) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextSecondary,
            )
          },
          icon = {
            Icon(
              imageVector = tab.icon,
              contentDescription = null,
              tint = if (isSelected) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextTertiary,
              modifier = Modifier.size(16.dp),
            )
          },
        )
      }
    }

    // 3. Tab Body
    when (selectedTab) {
      StudioTab.Analytics -> {
        AnalyticsTabContent(
          selectedTimeframe = selectedTimeframe,
          onSelectTimeframe = { selectedTimeframe = it },
          totalViews = displayedViews,
          watchHours = displayedWatchHours,
          totalLikes = displayedLikes,
          totalComments = displayedComments,
          totalShares = displayedShares,
          videosCount = myVideos.size,
        )
      }

      StudioTab.ContentManagement -> {
        ContentManagementTabContent(
          videos = myVideos,
          onOpenVideo = onOpenVideo,
          onToggleVisibility = { video ->
            scope.launch {
              val newVis = if (video.visibility == VideoVisibility.Public) VideoVisibility.Private else VideoVisibility.Public
              videoRepository.updateVideoVisibility(video.id, currentUserId, newVis)
            }
          },
          onRequestDelete = { video -> videoToDelete = video },
        )
      }

      StudioTab.SoundVault -> {
        SoundVaultTabContent(
          sounds = myExtractedSounds,
          onUseSound = onUseSound,
          onOpenCreate = onOpenCreate,
        )
      }

      StudioTab.Inspiration -> {
        InspirationTabContent(
          onOpenCreate = onOpenCreate,
        )
      }
    }
  }

  // Delete Confirmation Dialog
  videoToDelete?.let { targetVideo ->
    AlertDialog(
      onDismissRequest = { videoToDelete = null },
      containerColor = HoggarColorTokens.BasaltSurface,
      title = {
        Text(
          text = "حذف الفيديو",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )
      },
      text = {
        Text(
          text = "هل أنت متأكد من رغبتك في حذف \"${targetVideo.title.take(30)}\"؟ لا يمكن التراجع عن هذا الإجراء.",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 13.sp,
        )
      },
      confirmButton = {
        TextButton(
          onClick = {
            scope.launch {
              videoRepository.deleteVideo(targetVideo.id, currentUserId)
              videoToDelete = null
            }
          },
          colors = ButtonDefaults.textButtonColors(contentColor = HoggarColorTokens.ErrorCoral),
        ) {
          Text("حذف نهائي", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { videoToDelete = null }) {
          Text("إلغاء", color = HoggarColorTokens.TextSecondary)
        }
      },
    )
  }
}

// -------------------------------------------------------------
// TAB 1: ANALYTICS (TIKTOK & BILIBILI INSIGHTS)
// -------------------------------------------------------------
@Composable
private fun AnalyticsTabContent(
  selectedTimeframe: AnalyticsTimeframe,
  onSelectTimeframe: (AnalyticsTimeframe) -> Unit,
  totalViews: Long,
  watchHours: Int,
  totalLikes: Long,
  totalComments: Long,
  totalShares: Long,
  videosCount: Int,
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
  ) {
    // Timeframe Selector
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "نظرة عامة على الأداء",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
      )

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        AnalyticsTimeframe.entries.forEach { tf ->
          val isSelected = selectedTimeframe == tf
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) HoggarColorTokens.CopperPrimary else HoggarColorTokens.SlateContainer)
              .clickable { onSelectTimeframe(tf) }
              .padding(horizontal = 10.dp, vertical = 5.dp),
          ) {
            Text(
              text = tf.label,
              color = if (isSelected) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // 4 KPI Metric Cards (2x2 Grid)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      MetricCard(
        title = "المشاهدات",
        value = formatStatNumber(totalViews),
        trend = "+18.4%",
        icon = Icons.Filled.Visibility,
        modifier = Modifier.weight(1f),
      )
      MetricCard(
        title = "ساعات المشاهدة",
        value = "${watchHours}h",
        trend = "+24.1%",
        icon = Icons.Filled.Schedule,
        modifier = Modifier.weight(1f),
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      MetricCard(
        title = "الإعجابات",
        value = formatStatNumber(totalLikes),
        trend = "+12.7%",
        icon = Icons.Filled.Favorite,
        modifier = Modifier.weight(1f),
      )
      MetricCard(
        title = "التفاعل الكلي",
        value = formatStatNumber(totalComments + totalShares),
        trend = "+9.2%",
        icon = Icons.AutoMirrored.Filled.TrendingUp,
        modifier = Modifier.weight(1f),
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Weekly Retention & Views Simulated Chart (Bilibili Style)
    HoggarCard(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "منحنى تدفق المشاهدات اليومي",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = "متوسط نسبة الإكمال: 68.4% (أعلى من 82% من صُنّاع المحتوى)",
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 11.sp,
          )
        }
        Icon(
          imageVector = Icons.Filled.Insights,
          contentDescription = null,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(20.dp),
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Visual Weekly Histogram / Bar distribution
      val days = listOf("السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")
      val heights = listOf(0.45f, 0.60f, 0.55f, 0.75f, 0.85f, 1.0f, 0.90f)

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .height(100.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom,
      ) {
        days.forEachIndexed { idx, day ->
          val fraction = heights[idx]
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.weight(1f),
          ) {
            Box(
              modifier = Modifier
                .width(18.dp)
                .height((80 * fraction).dp)
                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                .background(
                  Brush.verticalGradient(
                    listOf(HoggarColorTokens.InteractiveAmber, HoggarColorTokens.CopperPrimary),
                  ),
                ),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = day.take(2),
              color = HoggarColorTokens.TextTertiary,
              fontSize = 9.sp,
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Traffic Source Distribution (TikTok Style)
    HoggarCard(modifier = Modifier.fillMaxWidth()) {
      Text(
        text = "مصادر وصول المشاهدين إلى فيديوهاتك:",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
      )

      Spacer(modifier = Modifier.height(12.dp))

      TrafficSourceRow("خلاصة التوصيات (لك - For You)", 0.72f, "72%")
      Spacer(modifier = Modifier.height(8.dp))
      TrafficSourceRow("صفحة الصوت والموسيقى المشتركة", 0.16f, "16%")
      Spacer(modifier = Modifier.height(8.dp))
      TrafficSourceRow("ملفات المستخدمين والوسوم", 0.12f, "12%")
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Audience Peak Times (Bilibili / TikTok Feature)
    HoggarCard(modifier = Modifier.fillMaxWidth()) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.Schedule,
          contentDescription = null,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "أوقات الذروة لنشر الفيديوهات:",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = "جمهورك يكون أكثر نشاطًا بين 8:30 م إلى 11:30 م بتوقيت الجزائر (GMT+1).",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 11.sp,
          )
        }
      }
    }
  }
}

@Composable
private fun MetricCard(
  title: String,
  value: String,
  trend: String,
  icon: ImageVector,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .background(HoggarColorTokens.BasaltSurface)
      .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp))
      .padding(12.dp),
  ) {
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(text = title, color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
        Icon(imageVector = icon, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(16.dp))
      }
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = value,
        color = HoggarColorTokens.TextPrimary,
        fontSize = 20.sp,
        fontWeight = FontWeight.ExtraBold,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = Icons.AutoMirrored.Filled.TrendingUp, contentDescription = null, tint = HoggarColorTokens.SuccessOasis, modifier = Modifier.size(12.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = trend, color = HoggarColorTokens.SuccessOasis, fontSize = 10.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
private fun TrafficSourceRow(title: String, fraction: Float, percentage: String) {
  Column {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text(text = title, color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
      Text(text = percentage, color = HoggarColorTokens.TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
    Spacer(modifier = Modifier.height(4.dp))
    LinearProgressIndicator(
      progress = { fraction },
      modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
      color = HoggarColorTokens.InteractiveAmber,
      trackColor = HoggarColorTokens.SlateContainer,
    )
  }
}

// -------------------------------------------------------------
// TAB 2: CONTENT MANAGEMENT (BILIBILI 稿件管理)
// -------------------------------------------------------------
@Composable
private fun ContentManagementTabContent(
  videos: List<VideoItem>,
  onOpenVideo: (VideoItem) -> Unit,
  onToggleVisibility: (VideoItem) -> Unit,
  onRequestDelete: (VideoItem) -> Unit,
) {
  var filterCategory by remember { mutableStateOf("الكل") }

  val filteredVideos = remember(videos, filterCategory) {
    when (filterCategory) {
      "عام" -> videos.filter { it.visibility == VideoVisibility.Public }
      "خاص" -> videos.filter { it.visibility == VideoVisibility.Private }
      "الأكثر مشاهدة" -> videos.sortedByDescending { it.stats.viewsCount }
      else -> videos
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
  ) {
    // Filter Row
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      items(listOf("الكل", "عام", "خاص", "الأكثر مشاهدة")) { cat ->
        val isSelected = filterCategory == cat
        FilterChip(
          selected = isSelected,
          onClick = { filterCategory = cat },
          label = { Text(text = cat, fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = HoggarColorTokens.CopperPrimary,
            selectedLabelColor = HoggarColorTokens.TextPrimary,
            containerColor = HoggarColorTokens.SlateContainer,
            labelColor = HoggarColorTokens.TextSecondary,
          ),
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    if (filteredVideos.isEmpty()) {
      Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
      ) {
        HoggarEmptyState(
          title = "لا توجد فيديوهات في هذا القسم",
          description = "يمكنك نشر فيديو جديد وسيظهر مباشرة في استوديو الإدارة.",
        )
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize(),
      ) {
        items(filteredVideos, key = { it.id }) { video ->
          VideoManagementRow(
            video = video,
            onOpenVideo = { onOpenVideo(video) },
            onToggleVisibility = { onToggleVisibility(video) },
            onDelete = { onRequestDelete(video) },
          )
        }
      }
    }
  }
}

@Composable
private fun VideoManagementRow(
  video: VideoItem,
  onOpenVideo: () -> Unit,
  onToggleVisibility: () -> Unit,
  onDelete: () -> Unit,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(HoggarColorTokens.BasaltSurface)
      .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp))
      .padding(10.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    // Video Thumbnail
    Box(
      modifier = Modifier
        .width(60.dp)
        .aspectRatio(9f / 14f)
        .clip(RoundedCornerShape(8.dp))
        .clickable(onClick = onOpenVideo),
    ) {
      AsyncImage(
        model = video.thumbnailUrl,
        contentDescription = video.title,
        modifier = Modifier.fillMaxSize(),
      )
      HoggarDurationBadge(
        durationText = "${video.durationSeconds}s",
        modifier = Modifier.align(Alignment.BottomEnd).padding(2.dp),
      )
    }

    Spacer(modifier = Modifier.width(12.dp))

    // Video Meta & Stats
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = video.title,
        color = HoggarColorTokens.TextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )

      Spacer(modifier = Modifier.height(4.dp))

      // Stats Pills
      Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.Visibility, contentDescription = null, tint = HoggarColorTokens.TextTertiary, modifier = Modifier.size(12.dp))
          Spacer(modifier = Modifier.width(3.dp))
          Text(text = formatStatNumber(video.stats.viewsCount), color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.Favorite, contentDescription = null, tint = HoggarColorTokens.TextTertiary, modifier = Modifier.size(12.dp))
          Spacer(modifier = Modifier.width(3.dp))
          Text(text = formatStatNumber(video.stats.likesCount), color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.ModeComment, contentDescription = null, tint = HoggarColorTokens.TextTertiary, modifier = Modifier.size(12.dp))
          Spacer(modifier = Modifier.width(3.dp))
          Text(text = formatStatNumber(video.stats.commentsCount), color = HoggarColorTokens.TextSecondary, fontSize = 11.sp)
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Audio Tag Pill
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.MusicNote, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(11.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = video.soundTitle, color = HoggarColorTokens.InteractiveAmber, fontSize = 10.sp, maxLines = 1)
      }
    }

    Spacer(modifier = Modifier.width(8.dp))

    // Quick Actions
    Column(horizontalAlignment = Alignment.End) {
      // Visibility Toggle Button
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(if (video.visibility == VideoVisibility.Public) Color(0x3334D399) else HoggarColorTokens.SlateContainer)
          .clickable(onClick = onToggleVisibility)
          .padding(horizontal = 6.dp, vertical = 3.dp),
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = if (video.visibility == VideoVisibility.Public) Icons.Filled.Public else Icons.Filled.Lock,
            contentDescription = null,
            tint = if (video.visibility == VideoVisibility.Public) HoggarColorTokens.SuccessOasis else HoggarColorTokens.TextSecondary,
            modifier = Modifier.size(12.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (video.visibility == VideoVisibility.Public) "عام" else "خاص",
            color = if (video.visibility == VideoVisibility.Public) HoggarColorTokens.SuccessOasis else HoggarColorTokens.TextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      IconButton(
        onClick = onDelete,
        modifier = Modifier.size(28.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.Delete,
          contentDescription = "Delete Video",
          tint = HoggarColorTokens.ErrorCoral,
          modifier = Modifier.size(16.dp),
        )
      }
    }
  }
}

// -------------------------------------------------------------
// TAB 3: SOUND VAULT (CREATOR SOUNDS)
// -------------------------------------------------------------
@Composable
private fun SoundVaultTabContent(
  sounds: List<SoundItem>,
  onUseSound: (SoundItem) -> Unit,
  onOpenCreate: () -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
  ) {
    HoggarCard(modifier = Modifier.fillMaxWidth()) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.AutoAwesome,
          contentDescription = null,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "نظام استخراج الأصوات التلقائي في الهڨار",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = "كل فيديو تنشره يستخرج صوته تلقائيًا ويصبح متاحًا لجميع صناع المحتوى في المنصة لإنشاء فيديوهات جديدة باستخدامه.",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 11.sp,
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    Text(
      text = "الأصوات المستخرجة من فيديوهاتك (${sounds.size}):",
      color = HoggarColorTokens.TextPrimary,
      fontSize = 14.sp,
      fontWeight = FontWeight.Bold,
    )

    Spacer(modifier = Modifier.height(10.dp))

    if (sounds.isEmpty()) {
      Box(
        modifier = Modifier.weight(1f).fillMaxWidth(),
        contentAlignment = Alignment.Center,
      ) {
        HoggarEmptyState(
          title = "لم يتم استخراج أصوات بعد",
          description = "انشر أول فيديو لك بصوت أصلي وسيتم استخراجه تلقائيًا وعرضه هنا لمشاركته مع المجتمع.",
          actionText = "إنشاء فيديو الآن",
          onActionClick = onOpenCreate,
        )
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.weight(1f),
      ) {
        items(sounds, key = { it.id }) { sound ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(HoggarColorTokens.BasaltSurface)
              .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp))
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(HoggarColorTokens.SlateContainer)
                  .border(1.5.dp, HoggarColorTokens.CopperPrimary, CircleShape),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Filled.MusicNote,
                  contentDescription = null,
                  tint = HoggarColorTokens.InteractiveAmber,
                  modifier = Modifier.size(20.dp),
                )
              }

              Spacer(modifier = Modifier.width(12.dp))

              Column {
                Text(
                  text = sound.title,
                  color = HoggarColorTokens.TextPrimary,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "${sound.usageCount} مقطع في الهڨار",
                    color = HoggarColorTokens.InteractiveAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = "• ${sound.durationSeconds}s", color = HoggarColorTokens.TextTertiary, fontSize = 11.sp)
                }
              }
            }

            Spacer(modifier = Modifier.width(8.dp))

            HoggarButton(
              text = "استخدام",
              icon = Icons.Filled.Videocam,
              onClick = { onUseSound(sound) },
              variant = HoggarButtonVariant.PrimaryCopper,
              modifier = Modifier.height(32.dp),
            )
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// TAB 4: INSPIRATION & VIRAL PLAYBOOK (TIKTOK / BILIBILI CREATOR HUB)
// -------------------------------------------------------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun InspirationTabContent(
  onOpenCreate: () -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
  ) {
    // Trending Topics Banner
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(14.dp))
        .background(
          Brush.horizontalGradient(
            listOf(Color(0xFF2E190E), Color(0xFF1B2028)),
          ),
        )
        .border(1.dp, HoggarColorTokens.CopperPrimary.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
        .padding(16.dp),
    ) {
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "الوسوم الأكثر انتشارًا في الجزائر اليوم",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
          )
        }
        Spacer(modifier = Modifier.height(10.dp))
        val topics = listOf(
          "#الهڨار" to "1.2M مشاهدة",
          "#سياحة_صحراوية" to "840K مشاهدة",
          "#صياغة_الفضة" to "420K مشاهدة",
          "#قمة_تاهات" to "310K مشاهدة",
          "#تيناريوين" to "650K مشاهدة",
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          topics.forEach { (tag, views) ->
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(HoggarColorTokens.BasaltSurface)
                .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = tag, color = HoggarColorTokens.InteractiveAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "($views)", color = HoggarColorTokens.TextTertiary, fontSize = 10.sp)
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Viral Playbook Tips (TikTok & Bilibili standards)
    Text(
      text = "أسرار الفيديوهات سريعة الانتشار في الهڨار:",
      color = HoggarColorTokens.TextPrimary,
      fontSize = 14.sp,
      fontWeight = FontWeight.Bold,
    )

    Spacer(modifier = Modifier.height(10.dp))

    ViralTipCard(
      title = "الخطاف البصري (First 2 Seconds Hook)",
      description = "ابدأ الفيديو بحركة سريعة، مشهد صحراوي مبهر، أو جملة تشد الانتباه مباشرة قبل أن يسحب المستخدم للأعلى.",
    )

    Spacer(modifier = Modifier.height(8.dp))

    ViralTipCard(
      title = "استخدام الموسيقى والأصوات الرائجة",
      description = "استخدم الأصوات المستخرجة المتصدرة في مكتبة أصوات الهڨار لأن خوارزمية المنصة تعطيها أولوية في التوصيات.",
    )

    Spacer(modifier = Modifier.height(8.dp))

    ViralTipCard(
      title = "جودة الأبعاد والوضوح (9:16 Full Screen)",
      description = "تأكد من التصوير العمودي التام بدون أشرطة سوداء، واستخدم الإضاءة الطبيعية لغروب وشروق الشمس في الصحراء.",
    )

    Spacer(modifier = Modifier.height(20.dp))

    HoggarButton(
      text = "تطبيق النصائح وتصوير فيديو جديد الآن",
      onClick = onOpenCreate,
      variant = HoggarButtonVariant.PrimaryCopper,
      icon = Icons.Filled.Videocam,
      modifier = Modifier.fillMaxWidth(),
    )
  }
}

@Composable
private fun ViralTipCard(title: String, description: String) {
  HoggarCard(modifier = Modifier.fillMaxWidth()) {
    Row(verticalAlignment = Alignment.Top) {
      Box(
        modifier = Modifier
          .size(24.dp)
          .clip(CircleShape)
          .background(HoggarColorTokens.InteractiveAmber.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.Check, contentDescription = null, tint = HoggarColorTokens.InteractiveAmber, modifier = Modifier.size(14.dp))
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(text = title, color = HoggarColorTokens.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(3.dp))
        Text(text = description, color = HoggarColorTokens.TextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
      }
    }
  }
}

private fun formatStatNumber(num: Long): String {
  return when {
    num >= 1_000_000 -> String.format("%.1fM", num / 1_000_000.0)
    num >= 1_000 -> String.format("%.1fK", num / 1_000.0)
    else -> num.toString()
  }
}
