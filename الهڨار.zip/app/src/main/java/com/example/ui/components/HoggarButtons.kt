package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HoggarColorTokens

enum class HoggarButtonVariant {
  PrimaryCopper,
  InteractiveAmber,
  Outlined,
  Ghost
}

@Composable
fun HoggarButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  variant: HoggarButtonVariant = HoggarButtonVariant.PrimaryCopper,
  icon: ImageVector? = null,
  isLoading: Boolean = false,
  enabled: Boolean = true,
  shape: Shape = RoundedCornerShape(10.dp),
  testTag: String = "hoggar_button",
) {
  val minHeight = 48.dp

  when (variant) {
    HoggarButtonVariant.PrimaryCopper -> {
      Button(
        onClick = onClick,
        modifier = modifier
          .defaultMinSize(minHeight = minHeight)
          .minimumInteractiveComponentSize()
          .testTag(testTag),
        enabled = enabled && !isLoading,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
          containerColor = HoggarColorTokens.CopperPrimary,
          contentColor = HoggarColorTokens.TextPrimary,
          disabledContainerColor = HoggarColorTokens.TextDisabled,
          disabledContentColor = HoggarColorTokens.TextSecondary,
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
      ) {
        ButtonContent(text = text, icon = icon, isLoading = isLoading, contentColor = HoggarColorTokens.TextPrimary)
      }
    }
    HoggarButtonVariant.InteractiveAmber -> {
      Button(
        onClick = onClick,
        modifier = modifier
          .defaultMinSize(minHeight = minHeight)
          .minimumInteractiveComponentSize()
          .testTag(testTag),
        enabled = enabled && !isLoading,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
          containerColor = HoggarColorTokens.InteractiveAmber,
          contentColor = HoggarColorTokens.ObsidianBase,
          disabledContainerColor = HoggarColorTokens.TextDisabled,
          disabledContentColor = HoggarColorTokens.TextSecondary,
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
      ) {
        ButtonContent(text = text, icon = icon, isLoading = isLoading, contentColor = HoggarColorTokens.TextPrimary)
      }
    }
    HoggarButtonVariant.Outlined -> {
      OutlinedButton(
        onClick = onClick,
        modifier = modifier
          .defaultMinSize(minHeight = minHeight)
          .minimumInteractiveComponentSize()
          .testTag(testTag),
        enabled = enabled && !isLoading,
        shape = shape,
        border = BorderStroke(1.dp, HoggarColorTokens.BorderSubtle),
        colors = ButtonDefaults.outlinedButtonColors(
          containerColor = Color.Transparent,
          contentColor = HoggarColorTokens.TextPrimary,
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
      ) {
        ButtonContent(text = text, icon = icon, isLoading = isLoading, contentColor = HoggarColorTokens.TextPrimary)
      }
    }
    HoggarButtonVariant.Ghost -> {
      Button(
        onClick = onClick,
        modifier = modifier
          .defaultMinSize(minHeight = minHeight)
          .minimumInteractiveComponentSize()
          .testTag(testTag),
        enabled = enabled && !isLoading,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
          containerColor = Color.Transparent,
          contentColor = HoggarColorTokens.TextSecondary,
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
      ) {
        ButtonContent(text = text, icon = icon, isLoading = isLoading, contentColor = HoggarColorTokens.TextSecondary)
      }
    }
  }
}

@Composable
private fun ButtonContent(
  text: String,
  icon: ImageVector?,
  isLoading: Boolean,
  contentColor: Color,
) {
  if (isLoading) {
    CircularProgressIndicator(
      modifier = Modifier.size(20.dp),
      color = contentColor,
      strokeWidth = 2.dp,
    )
  } else {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
    ) {
      if (icon != null) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
          tint = contentColor,
        )
        Spacer(modifier = Modifier.width(8.dp))
      }
      Text(
        text = text,
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold,
        color = contentColor,
      )
    }
  }
}

/**
 * Hoggar Floating Icon Action Button
 * Engineered for high-contrast video overlay interactions (Like, Comment, Share, Sound).
 */
@Composable
fun HoggarVideoAction(
  icon: ImageVector,
  label: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  tint: Color = HoggarColorTokens.TextPrimary,
  activeTint: Color? = null,
  isActive: Boolean = false,
  testTag: String = "video_action_button",
) {
  val currentTint = if (isActive && activeTint != null) activeTint else tint

  Column(
    modifier = modifier
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = ripple(bounded = false, radius = 24.dp),
        onClick = onClick,
      )
      .minimumInteractiveComponentSize()
      .testTag(testTag),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Box(
      modifier = Modifier
        .size(46.dp)
        .clip(CircleShape)
        .background(Color(0x33000000)),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = currentTint,
        modifier = Modifier.size(26.dp),
      )
    }
    if (label.isNotEmpty()) {
      Spacer(modifier = Modifier.size(4.dp))
      Text(
        text = label,
        color = HoggarColorTokens.TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
      )
    }
  }
}
