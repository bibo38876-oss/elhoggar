package com.example.ui.create

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HoggarColorTokens

@Composable
fun DeleteVideoDialog(
  onConfirmDelete: () -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = HoggarColorTokens.BasaltSurface,
    title = {
      Text(
        text = "حذف هذا الفيديو؟",
        color = HoggarColorTokens.ErrorCoral,
        fontSize = 17.sp,
        fontWeight = FontWeight.Bold,
      )
    },
    text = {
      Column {
        Text(
          text = "هل أنت متأكد من رغبتك في حذف الفيديو نهائيًا؟ لن يعود الفيديو ظاهرًا في الخلاصة أو في ملفك الشخصي.",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 13.sp,
          lineHeight = 19.sp,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "لا يمكن التراجع عن هذا الإجراء بعد الحذف.",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
        )
      }
    },
    confirmButton = {
      TextButton(
        onClick = onConfirmDelete,
        modifier = Modifier.testTag("btn_confirm_delete_video"),
      ) {
        Text(
          text = "حذف الفيديو",
          color = HoggarColorTokens.ErrorCoral,
          fontWeight = FontWeight.Bold,
        )
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(
          text = "إلغاء",
          color = HoggarColorTokens.TextPrimary,
        )
      }
    },
  )
}
