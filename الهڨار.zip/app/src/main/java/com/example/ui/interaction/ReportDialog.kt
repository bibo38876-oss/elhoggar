package com.example.ui.interaction

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.interaction.model.ReportItem
import com.example.interaction.model.ReportReason
import com.example.interaction.model.ReportTargetType
import com.example.ui.theme.HoggarColorTokens

@Composable
fun ReportDialog(
  targetType: ReportTargetType,
  targetId: String,
  reporterId: String,
  onSubmitReport: (ReportItem) -> Unit,
  onDismiss: () -> Unit,
) {
  var selectedReason by remember { mutableStateOf(ReportReason.InappropriateContent) }
  var detailsInput by remember { mutableStateOf("") }

  val targetLabel = when (targetType) {
    ReportTargetType.Video -> "هذا الفيديو"
    ReportTargetType.Comment -> "هذا التعليق"
    ReportTargetType.User -> "هذا الحساب"
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = HoggarColorTokens.BasaltSurface,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.Flag,
          contentDescription = null,
          tint = HoggarColorTokens.WarningDune,
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "إبلاغ عن $targetLabel",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 17.sp,
          fontWeight = FontWeight.Bold,
        )
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "اختر سبب البلاغ لإرساله إلى فريق مراجعة الهڨار:",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 13.sp,
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Structured Reasons Radio List
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          ReportReason.entries.forEach { reason ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable { selectedReason = reason }
                .padding(vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RadioButton(
                selected = selectedReason == reason,
                onClick = { selectedReason = reason },
                colors = RadioButtonDefaults.colors(
                  selectedColor = HoggarColorTokens.InteractiveAmber,
                  unselectedColor = HoggarColorTokens.TextTertiary,
                ),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = reason.labelAr,
                color = HoggarColorTokens.TextPrimary,
                fontSize = 13.sp,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Optional details field
        TextField(
          value = detailsInput,
          onValueChange = { detailsInput = it },
          placeholder = { Text("تفاصيل إضافية اختيارية...", color = HoggarColorTokens.TextTertiary, fontSize = 12.sp) },
          maxLines = 2,
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(8.dp)),
          colors = TextFieldDefaults.colors(
            focusedContainerColor = HoggarColorTokens.SlateContainer,
            unfocusedContainerColor = HoggarColorTokens.SlateContainer,
            focusedTextColor = HoggarColorTokens.TextPrimary,
            unfocusedTextColor = HoggarColorTokens.TextPrimary,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
          ),
        )
      }
    },
    confirmButton = {
      TextButton(
        onClick = {
          val report = ReportItem(
            id = "rep_${System.currentTimeMillis()}",
            targetType = targetType,
            targetId = targetId,
            reporterId = reporterId,
            reason = selectedReason,
            details = detailsInput.trim(),
          )
          onSubmitReport(report)
        },
        modifier = Modifier.testTag("btn_submit_report"),
      ) {
        Text(
          text = "إرسال البلاغ",
          color = HoggarColorTokens.InteractiveAmber,
          fontWeight = FontWeight.Bold,
        )
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(text = "إلغاء", color = HoggarColorTokens.TextSecondary)
      }
    },
  )
}
