package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HoggarLogoMark
import com.example.ui.theme.HoggarColorTokens
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
  onFinish: () -> Unit,
  modifier: Modifier = Modifier,
  autoAdvanceDelayMs: Long = 1800L,
) {
  var isVisible by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    isVisible = true
    delay(autoAdvanceDelayMs)
    onFinish()
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onFinish,
      )
      .testTag("splash_screen"),
    contentAlignment = Alignment.Center,
  ) {
    AnimatedVisibility(
      visible = isVisible,
      enter = fadeIn(animationSpec = tween(700, easing = FastOutSlowInEasing)) +
          scaleIn(initialScale = 0.88f, animationSpec = tween(700, easing = FastOutSlowInEasing)),
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.padding(24.dp),
      ) {
        // Central Sacred Geometric Emblem of El Hoggar
        HoggarLogoMark(
          size = 100.dp,
          showGlow = true,
          isPulsing = false,
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Pure Official Wordmark
        Text(
          text = "الهڨار",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 42.sp,
          fontWeight = FontWeight.ExtraBold,
          fontFamily = FontFamily.SansSerif,
          letterSpacing = 1.sp,
        )
      }
    }
  }
}
