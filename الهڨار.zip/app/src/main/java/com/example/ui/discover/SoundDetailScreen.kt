package com.example.ui.discover

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.VideoItem
import com.example.recommendation.repository.RecommendationRepository
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarCard
import com.example.ui.components.HoggarDurationBadge
import com.example.ui.components.HoggarEmptyState
import com.example.ui.theme.HoggarColorTokens

@Composable
fun SoundDetailScreen(
  soundTitle: String,
  soundAuthor: String,
  repository: RecommendationRepository,
  onBack: () -> Unit,
  onVideoClick: (VideoItem) -> Unit,
  onUseSound: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val videos by repository.getVideosBySound(soundTitle).collectAsState(initial = emptyList())

  val discTransition = rememberInfiniteTransition(label = "sound_screen_disc")
  val discRotation by discTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(6000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "disc_rotation",
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("sound_detail_screen"),
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Back",
          tint = HoggarColorTokens.TextPrimary,
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "المسار الصوتي",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
      )
    }

    LazyVerticalGrid(
      columns = GridCells.Fixed(3),
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(4.dp),
      horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      // Hero Header Card
      item(span = { GridItemSpan(3) }) {
        HoggarCard(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        ) {
          Column(modifier = Modifier.fillMaxWidth()) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              // Rotating Vinyl Disc
              Box(
                modifier = Modifier
                  .size(68.dp)
                  .clip(CircleShape)
                  .background(HoggarColorTokens.SlateContainer)
                  .border(2.dp, HoggarColorTokens.CopperPrimary, CircleShape)
                  .rotate(discRotation),
                contentAlignment = Alignment.Center,
              ) {
                // Vinyl grooves rings
                Box(
                  modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .border(1.dp, HoggarColorTokens.ObsidianBase, CircleShape),
                )
                Icon(
                  imageVector = Icons.Filled.MusicNote,
                  contentDescription = null,
                  tint = HoggarColorTokens.InteractiveAmber,
                  modifier = Modifier.size(28.dp),
                )
              }

              Spacer(modifier = Modifier.width(16.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = soundTitle,
                  color = HoggarColorTokens.TextPrimary,
                  fontSize = 18.sp,
                  fontWeight = FontWeight.ExtraBold,
                  maxLines = 2,
                  overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = soundAuthor.ifEmpty { "صوت أصلي - الهڨار" },
                  color = HoggarColorTokens.TextSecondary,
                  fontSize = 13.sp,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = "${videos.size} مقاطع تستخدم هذا الصوت",
                  color = HoggarColorTokens.InteractiveAmber,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold,
                )
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Use Sound Button
            HoggarButton(
              text = "استخدام هذا الصوت في فيديو جديد",
              icon = Icons.Filled.Videocam,
              onClick = onUseSound,
              variant = HoggarButtonVariant.PrimaryCopper,
              modifier = Modifier.fillMaxWidth().testTag("btn_use_sound"),
            )
          }
        }
      }

      // Section Header
      item(span = { GridItemSpan(3) }) {
        Text(
          text = "الفيديوهات المقترنة بهذا المسار",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
      }

      if (videos.isEmpty()) {
        item(span = { GridItemSpan(3) }) {
          HoggarEmptyState(
            title = "لا توجد فيديوهات بعد",
            description = "كن أول من ينشئ مقطعاً عمودياً باستخدام هذه النغمة.",
          )
        }
      } else {
        items(videos, key = { it.id }) { video ->
          Box(
            modifier = Modifier
              .aspectRatio(9f / 16f)
              .clip(RoundedCornerShape(6.dp))
              .background(HoggarColorTokens.BasaltSurface)
              .clickable { onVideoClick(video) },
          ) {
            AsyncImage(
              model = video.thumbnailUrl,
              contentDescription = video.title,
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop,
            )

            // Scrim overlay at bottom
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))),
            )

            // Duration badge at top
            HoggarDurationBadge(
              durationText = "${video.durationSeconds}s",
              modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(4.dp),
            )

            // Views count at bottom
            Row(
              modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Filled.PlayArrow,
                contentDescription = null,
                tint = HoggarColorTokens.TextPrimary,
                modifier = Modifier.size(14.dp),
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = "${video.stats.viewsCount}",
                color = HoggarColorTokens.TextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
              )
            }
          }
        }
      }
    }
  }
}
