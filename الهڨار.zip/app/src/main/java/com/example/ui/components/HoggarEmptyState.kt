package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.HoggarColorTokens

@Composable
fun HoggarEmptyState(
  title: String,
  description: String,
  modifier: Modifier = Modifier,
  actionText: String? = null,
  onActionClick: (() -> Unit)? = null,
  testTag: String = "hoggar_empty_state",
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(32.dp)
      .testTag(testTag),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    HoggarLogoMark(
      size = 64.dp,
      showGlow = false,
      modifier = Modifier.alpha(0.6f),
    )

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = title,
      color = HoggarColorTokens.TextPrimary,
      fontSize = 18.sp,
      fontWeight = FontWeight.Bold,
      textAlign = TextAlign.Center,
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
      text = description,
      color = HoggarColorTokens.TextSecondary,
      fontSize = 14.sp,
      lineHeight = 20.sp,
      textAlign = TextAlign.Center,
    )

    if (actionText != null && onActionClick != null) {
      Spacer(modifier = Modifier.height(24.dp))
      HoggarButton(
        text = actionText,
        onClick = onActionClick,
        variant = HoggarButtonVariant.PrimaryCopper,
      )
    }
  }
}
