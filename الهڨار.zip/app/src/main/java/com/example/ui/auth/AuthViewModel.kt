package com.example.ui.auth

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.auth.AuthRepository
import com.example.auth.AuthState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(
  private val authRepository: AuthRepository,
) : ViewModel() {

  val authState: StateFlow<AuthState> = authRepository.authState

  private val _recoveryMessage = MutableStateFlow<String?>(null)
  val recoveryMessage: StateFlow<String?> = _recoveryMessage.asStateFlow()

  fun loginWithGoogle(context: Context, onComplete: (() -> Unit)? = null) {
    viewModelScope.launch {
      val result = authRepository.loginWithGoogle(context)
      if (result.isSuccess) {
        onComplete?.invoke()
      }
    }
  }

  fun loginWithGoogleDirect(email: String, displayName: String, onComplete: (() -> Unit)? = null) {
    viewModelScope.launch {
      val result = authRepository.loginWithGoogleDirect(email, displayName)
      if (result.isSuccess) {
        onComplete?.invoke()
      }
    }
  }

  fun login(identifier: String, pass: String, onComplete: (() -> Unit)? = null) {
    viewModelScope.launch {
      val result = authRepository.login(identifier, pass)
      if (result.isSuccess) {
        onComplete?.invoke()
      }
    }
  }

  fun register(username: String, displayName: String, email: String, pass: String, onComplete: (() -> Unit)? = null) {
    viewModelScope.launch {
      val result = authRepository.register(username, displayName, email, pass)
      if (result.isSuccess) {
        onComplete?.invoke()
      }
    }
  }

  fun recoverPassword(email: String) {
    viewModelScope.launch {
      authRepository.recoverPassword(email)
        .onSuccess { msg -> _recoveryMessage.value = msg }
        .onFailure { e -> _recoveryMessage.value = e.message }
    }
  }

  fun clearRecoveryMessage() {
    _recoveryMessage.value = null
  }

  fun logout() {
    viewModelScope.launch {
      authRepository.logout()
    }
  }

  fun deleteAccount(userId: String) {
    viewModelScope.launch {
      authRepository.deleteAccount(userId)
    }
  }
}
