package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Custom El Hoggar Brand Loading Indicator
 * An animated geometric pulse and rotation of the Saharan emblem.
 */
@Composable
fun HoggarLoadingIndicator(
  modifier: Modifier = Modifier,
  size: Dp = 48.dp,
  testTag: String = "hoggar_loading_indicator",
) {
  val transition = rememberInfiniteTransition(label = "hoggar_loader")
  val rotation by transition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(2400, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "loader_rotation",
  )

  val scale by transition.animateFloat(
    initialValue = 0.85f,
    targetValue = 1.15f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "loader_scale",
  )

  Box(
    modifier = modifier
      .size(size)
      .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    HoggarLogoMark(
      size = size,
      showGlow = true,
      modifier = Modifier
        .scale(scale)
        .rotate(rotation),
    )
  }
}
