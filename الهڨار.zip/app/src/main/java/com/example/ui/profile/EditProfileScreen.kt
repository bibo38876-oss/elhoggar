package com.example.ui.profile

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarLogoMark
import com.example.ui.theme.HoggarColorTokens
import com.example.user.UserProfile
import kotlinx.coroutines.launch

@Composable
fun EditProfileScreen(
  profile: UserProfile,
  onSave: (displayName: String, bio: String, avatarUrl: String) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var displayName by remember { mutableStateOf(profile.displayName) }
  var bio by remember { mutableStateOf(profile.bio) }
  var avatarUrl by remember { mutableStateOf(profile.avatarUrl) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var isSaving by remember { mutableStateOf(false) }

  val maxDisplayNameLength = 50
  val maxBioLength = 150
  val scope = rememberCoroutineScope()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .padding(horizontal = 16.dp),
  ) {
    // 1. Top Header Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = HoggarColorTokens.TextPrimary,
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "تعديل الملف الشخصي",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
        )
      }

      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(HoggarColorTokens.CopperPrimary)
          .clickable {
            if (displayName.trim().isEmpty()) {
              errorMessage = "اسم العرض لا يمكن أن يكون فارغًا"
              return@clickable
            }
            if (displayName.length > maxDisplayNameLength) {
              errorMessage = "اسم العرض يجب ألا يتجاوز $maxDisplayNameLength حرفًا"
              return@clickable
            }
            if (bio.length > maxBioLength) {
              errorMessage = "النبذة التعريفية يجب ألا تتجاوز $maxBioLength حرفًا"
              return@clickable
            }
            isSaving = true
            onSave(displayName.trim(), bio.trim(), avatarUrl.trim())
          }
          .padding(horizontal = 14.dp, vertical = 6.dp)
          .testTag("btn_save_profile"),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = "حفظ",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // 2. Avatar Picker with preset selections
    Column(
      modifier = Modifier.fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Box(
        modifier = Modifier
          .size(92.dp)
          .clip(CircleShape)
          .background(HoggarColorTokens.BasaltSurface)
          .border(2.dp, HoggarColorTokens.CopperPrimary, CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        if (avatarUrl.isNotEmpty()) {
          AsyncImage(
            model = avatarUrl,
            contentDescription = displayName,
            modifier = Modifier.fillMaxSize().clip(CircleShape),
          )
        } else {
          HoggarLogoMark(size = 46.dp)
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "اختر صورة شخصية جاهزة:",
        color = HoggarColorTokens.TextSecondary,
        fontSize = 12.sp,
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Preset avatar seeds
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        val presets = listOf("avatar1", "avatar2", "avatar3", "avatar4")
        presets.forEach { seed ->
          val url = "https://picsum.photos/seed/$seed/200/200"
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .border(
                if (avatarUrl == url) 2.dp else 1.dp,
                if (avatarUrl == url) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.BorderSubtle,
                CircleShape,
              )
              .clickable { avatarUrl = url },
          ) {
            AsyncImage(
              model = url,
              contentDescription = null,
              modifier = Modifier.fillMaxSize().clip(CircleShape),
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // 3. Error Banner
    AnimatedVisibility(visible = errorMessage != null) {
      errorMessage?.let { err ->
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(HoggarColorTokens.ErrorCoral.copy(alpha = 0.15f))
            .border(1.dp, HoggarColorTokens.ErrorCoral.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(10.dp),
        ) {
          Text(text = err, color = HoggarColorTokens.ErrorCoral, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(14.dp))
      }
    }

    // 4. Form Fields
    // Username (read-only with rule notice)
    Column {
      Text(
        text = "اسم المستخدم (Username)",
        color = HoggarColorTokens.TextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(HoggarColorTokens.SlateContainer)
          .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
          .padding(14.dp),
      ) {
        Text(
          text = "@${profile.username}",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
        )
      }
      Text(
        text = "اسم المستخدم فريد وثابت لحماية هويتك من الانتحال",
        color = HoggarColorTokens.TextTertiary,
        fontSize = 11.sp,
        modifier = Modifier.padding(top = 4.dp),
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Display Name
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = "اسم العرض (Display Name)",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
        )
        Text(
          text = "${displayName.length}/$maxDisplayNameLength",
          color = if (displayName.length > maxDisplayNameLength) HoggarColorTokens.ErrorCoral else HoggarColorTokens.TextTertiary,
          fontSize = 11.sp,
        )
      }
      Spacer(modifier = Modifier.height(6.dp))
      TextField(
        value = displayName,
        onValueChange = {
          if (it.length <= maxDisplayNameLength) {
            displayName = it
            errorMessage = null
          }
        },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
          .testTag("input_edit_display_name"),
        colors = TextFieldDefaults.colors(
          focusedContainerColor = HoggarColorTokens.SlateContainer,
          unfocusedContainerColor = HoggarColorTokens.SlateContainer,
          focusedTextColor = HoggarColorTokens.TextPrimary,
          unfocusedTextColor = HoggarColorTokens.TextPrimary,
          focusedIndicatorColor = Color.Transparent,
          unfocusedIndicatorColor = Color.Transparent,
        ),
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Bio
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = "النبذة التعريفية (Bio)",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
        )
        Text(
          text = "${bio.length}/$maxBioLength",
          color = if (bio.length > maxBioLength) HoggarColorTokens.ErrorCoral else HoggarColorTokens.TextTertiary,
          fontSize = 11.sp,
        )
      }
      Spacer(modifier = Modifier.height(6.dp))
      TextField(
        value = bio,
        onValueChange = {
          if (it.length <= maxBioLength) {
            bio = it
            errorMessage = null
          }
        },
        minLines = 3,
        maxLines = 4,
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp))
          .testTag("input_edit_bio"),
        placeholder = { Text("أخبر مجتمع الهڨار عن اهتماماتك وشغفك...", color = HoggarColorTokens.TextTertiary, fontSize = 13.sp) },
        colors = TextFieldDefaults.colors(
          focusedContainerColor = HoggarColorTokens.SlateContainer,
          unfocusedContainerColor = HoggarColorTokens.SlateContainer,
          focusedTextColor = HoggarColorTokens.TextPrimary,
          unfocusedTextColor = HoggarColorTokens.TextPrimary,
          focusedIndicatorColor = Color.Transparent,
          unfocusedIndicatorColor = Color.Transparent,
        ),
      )
    }
  }
}
