package com.example.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.auth.AuthRepository
import com.example.follow.FollowRepository
import com.example.model.VideoItem
import com.example.user.UserProfile
import com.example.user.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

sealed interface ProfileUiState {
  data object Loading : ProfileUiState
  data object Guest : ProfileUiState
  data class Success(val profile: UserProfile) : ProfileUiState
  data class Error(val message: String) : ProfileUiState
}

class ProfileViewModel(
  private val userRepository: UserRepository,
  private val followRepository: FollowRepository,
  private val authRepository: AuthRepository,
) : ViewModel() {

  private val _uiState = MutableStateFlow<ProfileUiState>(ProfileUiState.Loading)
  val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

  private val _userVideos = MutableStateFlow<List<VideoItem>>(emptyList())
  val userVideos: StateFlow<List<VideoItem>> = _userVideos.asStateFlow()

  private var activeUserId: String? = null

  fun loadProfile(targetUserId: String?) {
    val currentAuthUser = authRepository.authState.value.currentUser
    if (targetUserId == null && currentAuthUser == null) {
      _uiState.value = ProfileUiState.Guest
      _userVideos.value = emptyList()
      return
    }

    val resolvedId = targetUserId ?: currentAuthUser?.id ?: "creator_hoggar"
    activeUserId = resolvedId

    viewModelScope.launch {
      _uiState.value = ProfileUiState.Loading
      userRepository.getUserById(resolvedId, currentAuthUser?.id)
        .catch { e ->
          _uiState.value = ProfileUiState.Error(e.message ?: "فشل في تحميل الملف الشخصي")
        }
        .collect { profile ->
          if (profile != null) {
            _uiState.value = ProfileUiState.Success(profile)
          } else {
            _uiState.value = ProfileUiState.Error("المستخدم غير موجود")
          }
        }
    }

    // Load user video creations
    viewModelScope.launch {
      userRepository.getUserVideos(resolvedId).collect { videos ->
        _userVideos.value = videos
      }
    }
  }

  fun toggleFollow(targetUserId: String) {
    val currentUserId = authRepository.authState.value.currentUser?.id ?: return
    viewModelScope.launch {
      val isFollowing = followRepository.isFollowing(currentUserId, targetUserId)
      if (isFollowing) {
        followRepository.unfollow(currentUserId, targetUserId)
      } else {
        followRepository.follow(currentUserId, targetUserId)
      }
      // Reload profile to refresh follower counts and state
      loadProfile(targetUserId)
    }
  }

  suspend fun updateProfile(displayName: String, bio: String, avatarUrl: String): Result<UserProfile> {
    val currentUserId = authRepository.authState.value.currentUser?.id
      ?: return Result.failure(IllegalStateException("يجب تسجيل الدخول أولاً"))

    val result = userRepository.updateProfile(currentUserId, displayName, bio, avatarUrl)
    if (result.isSuccess) {
      val updatedProfile = result.getOrThrow()
      _uiState.value = ProfileUiState.Success(updatedProfile)
      // Also update auth state user object
      authRepository.authState.value.currentUser?.let { user ->
        authRepository.updateCurrentUser(
          user.copy(
            displayName = updatedProfile.displayName,
            bio = updatedProfile.bio,
            avatarUrl = updatedProfile.avatarUrl,
          ),
        )
      }
    }
    return result
  }
}
