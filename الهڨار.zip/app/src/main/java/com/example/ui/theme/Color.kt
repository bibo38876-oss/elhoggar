package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * El Hoggar Brand & System Colors
 * Dark Mode First, inspired by Saharan volcanic peaks, deep basalt rock,
 * and burnished copper/terracotta craftsmanship.
 */
object HoggarColorTokens {
  // Brand Copper & Terracotta (Primary)
  val CopperPrimary = Color(0xFFD8571F)       // Official brand copper
  val CopperDark = Color(0xFFA63C0D)          // Deep burnished copper
  val CopperLight = Color(0xFFFF7A42)         // Sunlit copper

  // Interactive Accent (Electric Amber / Bright Orange)
  val InteractiveAmber = Color(0xFFFF6926)    // High-visibility interactive triggers
  val InteractiveAmberGlow = Color(0x33FF6926)// Subtle glow halo

  // Dark Obsidian Backgrounds (Deep Charcoal Black)
  val ObsidianBase = Color(0xFF0D0E11)        // Root background
  val ObsidianElevated = Color(0xFF13151A)    // Secondary backdrop
  val BasaltSurface = Color(0xFF181A22)       // Cards and containers
  val SlateContainer = Color(0xFF20232E)      // Active pills and input fields
  val SlateHover = Color(0xFF282C3A)          // Pressed / hovered states

  // Typography & Content Contrast
  val TextPrimary = Color(0xFFFCFCFD)         // Pure crisp high-contrast white
  val TextSecondary = Color(0xFFA2A7B8)       // Balanced steel gray
  val TextTertiary = Color(0xFF6B7082)        // Subtle hint / metadata
  val TextDisabled = Color(0xFF454957)        // Disabled state

  // Structure & Dividers
  val BorderSubtle = Color(0xFF222530)        // 1.dp structural borders
  val BorderFocused = Color(0xFFD8571F)       // Focused / highlighted boundary

  // Functional Semantic Accents
  val SuccessOasis = Color(0xFF10B981)        // Emerald green
  val ErrorCoral = Color(0xFFEF4444)          // Alert / error coral red
  val WarningDune = Color(0xFFF59E0B)         // Dune amber warning
  val SaharanGold = Color(0xFFE5A93C)         // Heritage gold accent

  // Overlay & Scrims (for vertical video overlay)
  val ScrimTop = Color(0x99000000)            // Top gradient overlay for video
  val ScrimBottom = Color(0xB3000000)         // Bottom gradient overlay for video
  val GlassSurface = Color(0x26FFFFFF)        // Frosted glass effect
}

@Immutable
data class HoggarColors(
  val primary: Color = HoggarColorTokens.CopperPrimary,
  val primaryDark: Color = HoggarColorTokens.CopperDark,
  val primaryLight: Color = HoggarColorTokens.CopperLight,
  val interactive: Color = HoggarColorTokens.InteractiveAmber,
  val background: Color = HoggarColorTokens.ObsidianBase,
  val surface: Color = HoggarColorTokens.BasaltSurface,
  val surfaceElevated: Color = HoggarColorTokens.SlateContainer,
  val textPrimary: Color = HoggarColorTokens.TextPrimary,
  val textSecondary: Color = HoggarColorTokens.TextSecondary,
  val textTertiary: Color = HoggarColorTokens.TextTertiary,
  val border: Color = HoggarColorTokens.BorderSubtle,
  val success: Color = HoggarColorTokens.SuccessOasis,
  val error: Color = HoggarColorTokens.ErrorCoral,
  val warning: Color = HoggarColorTokens.WarningDune,
  val gold: Color = HoggarColorTokens.SaharanGold,
)

val LocalHoggarColors = staticCompositionLocalOf { HoggarColors() }
