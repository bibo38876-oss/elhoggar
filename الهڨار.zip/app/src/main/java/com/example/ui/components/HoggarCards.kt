package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.HoggarColorTokens

@Composable
fun HoggarCard(
  modifier: Modifier = Modifier,
  shape: Shape = RoundedCornerShape(14.dp),
  backgroundColor: Color = HoggarColorTokens.BasaltSurface,
  borderColor: Color = HoggarColorTokens.BorderSubtle,
  borderWidth: Dp = 1.dp,
  contentPadding: Dp = 16.dp,
  testTag: String = "hoggar_card",
  content: @Composable ColumnScope.() -> Unit,
) {
  Surface(
    modifier = modifier
      .clip(shape)
      .border(BorderStroke(borderWidth, borderColor), shape)
      .testTag(testTag),
    color = backgroundColor,
    shape = shape,
  ) {
    Column(
      modifier = Modifier.padding(contentPadding),
      content = content,
    )
  }
}
