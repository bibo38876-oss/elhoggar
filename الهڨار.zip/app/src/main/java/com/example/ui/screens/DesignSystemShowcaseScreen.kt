package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HoggarBadge
import com.example.ui.components.HoggarBrandLockup
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarCameraCrest
import com.example.ui.components.HoggarCard
import com.example.ui.components.HoggarDurationBadge
import com.example.ui.components.HoggarEmptyState
import com.example.ui.components.HoggarLoadingIndicator
import com.example.ui.components.HoggarLogoMark
import com.example.ui.components.HoggarTag
import com.example.ui.components.HoggarVerifiedBadge
import com.example.ui.components.HoggarVideoAction
import com.example.ui.components.HoggarWatermark
import com.example.ui.components.HoggarWordmark
import com.example.ui.components.WordmarkSize
import com.example.ui.theme.HoggarColorTokens

enum class ShowcaseTab {
  Identity,
  Colors,
  Components,
  VideoPreview
}

@Composable
fun DesignSystemShowcaseScreen(
  onReplaySplash: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var currentTab by remember { mutableStateOf(ShowcaseTab.Identity) }
  var isArabic by remember { mutableStateOf(true) }

  // Set RTL or LTR layout direction dynamically
  val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

  CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
    Scaffold(
      modifier = modifier
        .fillMaxSize()
        .background(HoggarColorTokens.ObsidianBase),
      containerColor = HoggarColorTokens.ObsidianBase,
      topBar = {
        ShowcaseTopBar(
          isArabic = isArabic,
          onToggleLanguage = { isArabic = !isArabic },
          onReplaySplash = onReplaySplash,
        )
      },
      bottomBar = {
        ShowcaseBottomNav(
          currentTab = currentTab,
          onSelectTab = { currentTab = it },
          isArabic = isArabic,
        )
      },
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding),
      ) {
        when (currentTab) {
          ShowcaseTab.Identity -> IdentitySection(isArabic = isArabic)
          ShowcaseTab.Colors -> ColorsSection(isArabic = isArabic)
          ShowcaseTab.Components -> ComponentsSection(isArabic = isArabic)
          ShowcaseTab.VideoPreview -> VideoPreviewSection(isArabic = isArabic)
        }
      }
    }
  }
}

@Composable
private fun ShowcaseTopBar(
  isArabic: Boolean,
  onToggleLanguage: () -> Unit,
  onReplaySplash: () -> Unit,
) {
  val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

  Surface(
    color = HoggarColorTokens.ObsidianElevated,
    modifier = Modifier
      .fillMaxWidth()
      .border(BorderStroke(1.dp, HoggarColorTokens.BorderSubtle)),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = statusBarPadding + 8.dp, bottom = 12.dp, start = 16.dp, end = 16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        HoggarLogoMark(size = 30.dp)
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = if (isArabic) "الهڨار" else "El Hoggar",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
          )
          Text(
            text = if (isArabic) "نظام الهوية والتصميم" else "Design System & Identity",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 11.sp,
          )
        }
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        // Replay splash trigger
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(HoggarColorTokens.SlateContainer)
            .clickable(onClick = onReplaySplash)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("btn_replay_splash"),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = if (isArabic) "شاشة البداية" else "Splash",
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Language toggle (RTL/LTR)
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(HoggarColorTokens.SlateContainer)
            .clickable(onClick = onToggleLanguage)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("btn_toggle_lang"),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = if (isArabic) "English" else "العربية",
            color = HoggarColorTokens.TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
          )
        }
      }
    }
  }
}

@Composable
private fun ShowcaseBottomNav(
  currentTab: ShowcaseTab,
  onSelectTab: (ShowcaseTab) -> Unit,
  isArabic: Boolean,
) {
  val navBarPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  Surface(
    color = HoggarColorTokens.ObsidianElevated,
    modifier = Modifier
      .fillMaxWidth()
      .border(BorderStroke(1.dp, HoggarColorTokens.BorderSubtle)),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 10.dp, bottom = navBarPadding + 8.dp, start = 12.dp, end = 12.dp),
      horizontalArrangement = Arrangement.SpaceAround,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      NavTabItem(
        label = if (isArabic) "الهوية والرمز" else "Identity",
        isSelected = currentTab == ShowcaseTab.Identity,
        onClick = { onSelectTab(ShowcaseTab.Identity) },
      )
      NavTabItem(
        label = if (isArabic) "الألوان" else "Palette",
        isSelected = currentTab == ShowcaseTab.Colors,
        onClick = { onSelectTab(ShowcaseTab.Colors) },
      )
      NavTabItem(
        label = if (isArabic) "المكونات" else "Components",
        isSelected = currentTab == ShowcaseTab.Components,
        onClick = { onSelectTab(ShowcaseTab.Components) },
      )
      NavTabItem(
        label = if (isArabic) "شاشة الفيديو" else "Video UI",
        isSelected = currentTab == ShowcaseTab.VideoPreview,
        onClick = { onSelectTab(ShowcaseTab.VideoPreview) },
      )
    }
  }
}

@Composable
private fun NavTabItem(
  label: String,
  isSelected: Boolean,
  onClick: () -> Unit,
) {
  val textColor by animateColorAsState(
    targetValue = if (isSelected) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextSecondary,
    label = "tab_color",
  )

  Column(
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = ripple(radius = 32.dp),
        onClick = onClick,
      )
      .padding(horizontal = 10.dp, vertical = 6.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Text(
      text = label,
      color = textColor,
      fontSize = 13.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
    )
    Spacer(modifier = Modifier.height(4.dp))
    Box(
      modifier = Modifier
        .size(width = 16.dp, height = 2.dp)
        .background(if (isSelected) HoggarColorTokens.InteractiveAmber else Color.Transparent),
    )
  }
}

// -------------------------------------------------------------
// TAB 1: IDENTITY & GEOMETRIC EMBLEM
// -------------------------------------------------------------
@Composable
private fun IdentitySection(isArabic: Boolean) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // Hero Card: The Geometric Symbol of El Hoggar
    item {
      HoggarCard {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Text(
            text = if (isArabic) "الرمز الهندسي الأصلي" else "Original Geometric Symbol",
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
          )

          Spacer(modifier = Modifier.height(18.dp))

          HoggarLogoMark(
            size = 110.dp,
            showGlow = true,
            isPulsing = true,
          )

          Spacer(modifier = Modifier.height(18.dp))

          HoggarWordmark(
            size = WordmarkSize.Large,
            showLatinSubtitle = true,
          )

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = if (isArabic)
              "تجريد هندسي معاصر مستوحى من قمم جبال تاهات الصخرية في الهڨار والأنماط الهندسية الأمازيغية. شكل المعين المتوازن يمنح العلامة هوية بصرية قوية قابلة للتذكر وتعمل بوضوح تام حتى في أصغر الأحجام."
            else
              "A contemporary geometric abstraction inspired by Mount Tahat volcanic granite peaks in Hoggar and Amazigh Saharan talismanic patterns. The balanced lozenge gives the brand a memorable identity that remains razor-sharp even at microscopic icon sizes.",
            color = HoggarColorTokens.TextSecondary,
            fontSize = 13.sp,
            lineHeight = 20.sp,
            textAlign = TextAlign.Center,
          )
        }
      }
    }

    // Symbol Anatomy Card
    item {
      HoggarCard {
        Text(
          text = if (isArabic) "تشريح الرمز الهندسي" else "Emblem Anatomy",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )

        Spacer(modifier = Modifier.height(12.dp))

        AnatomyRow(
          stepNumber = "١",
          title = if (isArabic) "معين تاهات المركزي" else "Central Tahat Lozenge",
          desc = if (isArabic) "كتلة المعين الرئيسية مستوحاة من الصخور البركانية ورمز الحماية الأمازيغي." else "Main diamond core inspired by volcanic basalt and Amazigh protective talisman.",
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = HoggarColorTokens.BorderSubtle)

        AnatomyRow(
          stepNumber = "٢",
          title = if (isArabic) "الأجنحة الأيروديناميكية الصاعدة" else "Upward Aerodynamic Wings",
          desc = if (isArabic) "حواف جانبية ترمز لحركة التمرير العمودي السريعة للفيديو والصعود المستمر." else "Flanking dynamic chevrons evoking rapid vertical video swipe momentum.",
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = HoggarColorTokens.BorderSubtle)

        AnatomyRow(
          stepNumber = "٣",
          title = if (isArabic) "عدسة النواة المضيئة" else "Glowing Lens Aperture",
          desc = if (isArabic) "فراغ هندسي في المركز يمثل بؤرة الكاميرا وتوليد المحتوى البصري." else "Center negative-space aperture representing the camera focal point and video creation.",
        )
      }
    }

    // Sizing Matrix
    item {
      HoggarCard {
        Text(
          text = if (isArabic) "مقياس ووضوح الرمز بأحجام مختلفة" else "Symbol Sizing Matrix",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = if (isArabic) "يعمل الرمز بدقة متناهية من الأيقونة المصغرة إلى شاشات العرض الكبيرة" else "The mark maintains structural integrity from 16dp to hero sizes.",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
        )

        Spacer(modifier = Modifier.height(18.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceAround,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          SizingItem(size = 20.dp, label = "20dp\n(Watermark)")
          SizingItem(size = 32.dp, label = "32dp\n(Header)")
          SizingItem(size = 48.dp, label = "48dp\n(Card)")
          SizingItem(size = 72.dp, label = "72dp\n(Splash)")
        }
      }
    }

    // Official Brand Rules
    item {
      HoggarCard {
        Text(
          text = if (isArabic) "أين يُستخدم الرمز في التطبيق؟" else "Brand Application Matrix",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(10.dp))

        val usages = if (isArabic) listOf(
          "أيقونة التطبيق الرسمية في لانشر Android",
          "شاشة البداية الاحترافية (Splash Screen)",
          "رأس التطبيق عند الحاجة لتعزيز الحضور",
          "زر/شاشة إنشاء الفيديو (Camera Crest)",
          "مؤشر التحميل الهندسي المخصص",
          "حالات عدم وجود محتوى (Empty State)",
          "العلامة المائية الخفيفة في الفيديوهات المصدرة",
        ) else listOf(
          "Official Android Launcher Icon",
          "Professional Launch Splash Screen",
          "Minimalist Application Header",
          "Video Creation Trigger Crest",
          "Custom Geometric Loading Spinner",
          "Branded Empty States",
          "Discrete Exported Video Watermark",
        )

        usages.forEach { usage ->
          Row(
            modifier = Modifier.padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(HoggarColorTokens.InteractiveAmber),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = usage,
              color = HoggarColorTokens.TextSecondary,
              fontSize = 13.sp,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun AnatomyRow(stepNumber: String, title: String, desc: String) {
  Row(verticalAlignment = Alignment.Top) {
    Box(
      modifier = Modifier
        .size(24.dp)
        .clip(RoundedCornerShape(6.dp))
        .background(HoggarColorTokens.SlateContainer),
      contentAlignment = Alignment.Center,
    ) {
      Text(
        text = stepNumber,
        color = HoggarColorTokens.InteractiveAmber,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
      )
    }
    Spacer(modifier = Modifier.width(12.dp))
    Column {
      Text(
        text = title,
        color = HoggarColorTokens.TextPrimary,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = desc,
        color = HoggarColorTokens.TextSecondary,
        fontSize = 12.sp,
        lineHeight = 18.sp,
      )
    }
  }
}

@Composable
private fun SizingItem(size: androidx.compose.ui.unit.Dp, label: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    HoggarLogoMark(size = size)
    Spacer(modifier = Modifier.height(8.dp))
    Text(
      text = label,
      color = HoggarColorTokens.TextSecondary,
      fontSize = 11.sp,
      textAlign = TextAlign.Center,
      lineHeight = 14.sp,
    )
  }
}

// -------------------------------------------------------------
// TAB 2: COLOR PALETTE
// -------------------------------------------------------------
@Composable
private fun ColorsSection(isArabic: Boolean) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    item {
      HoggarCard {
        Text(
          text = if (isArabic) "فلسفة لوحة الألوان" else "Color Palette Philosophy",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = if (isArabic)
            "نظام ألوان مبني خصيصًا للوضع الداكن (Dark First). أسود فحمي مستوحى من ليل الصحراء وأحجار البازلت، مع درجات النحاس المحروق الأمازيغي والبرتقالي المتوهج للعناصر التفاعلية."
          else
            "Dark-first color system engineered for vertical video consumption. Obsidian charcoal inspired by Saharan basalt rocks, accented by burnished copper and electric amber triggers.",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 13.sp,
          lineHeight = 20.sp,
        )
      }
    }

    // Color Swatches
    item {
      Text(
        text = if (isArabic) "ألوان العلامة الأساسية والتفاعلية" else "Brand & Interactive Colors",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "النحاسي المحروق (Primary)" else "Burnt Copper (Primary)",
        hex = "#D8571F",
        color = HoggarColorTokens.CopperPrimary,
        role = if (isArabic) "لون العلامة الرسمي والأزرار الرئيسية" else "Official brand identity & core buttons",
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "البرتقالي المتوهج (Interactive Accent)" else "Electric Amber (Interactive)",
        hex = "#FF6926",
        color = HoggarColorTokens.InteractiveAmber,
        role = if (isArabic) "العناصر التفاعلية الأكثر أهمية ونقاط الجذب" else "High-priority interactive triggers & active pills",
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "نحاسي داكن (Primary Dark)" else "Deep Burnished Copper",
        hex = "#A63C0D",
        color = HoggarColorTokens.CopperDark,
        role = if (isArabic) "حالات الضغط والظلال الهندسية" else "Pressed states & faceted shadow gradients",
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "نحاسي مشمس (Primary Light)" else "Sunlit Copper",
        hex = "#FF7A42",
        color = HoggarColorTokens.CopperLight,
        role = if (isArabic) "الإنارات الدقيقة والحدود النشطة" else "Facet highlights & active outlines",
      )
    }

    item {
      Text(
        text = if (isArabic) "ألوان الخلفيات والأسطح (Dark First)" else "Backdrops & Surfaces",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "أسود فحمي عميق (Background)" else "Obsidian Base (Background)",
        hex = "#0D0E11",
        color = HoggarColorTokens.ObsidianBase,
        role = if (isArabic) "الخلفية الجذرية للتطبيق لتوفير طاقة الشاشة وراحة العين" else "Root screen backdrop for pure video immersion",
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "رمادي بازلتي (Surface)" else "Basalt Surface",
        hex = "#181A22",
        color = HoggarColorTokens.BasaltSurface,
        role = if (isArabic) "البطاقات، الحاويات، والقوائم السفلية" else "Cards, modal sheets, and toolbars",
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "رمادي صخري مرتفع (Elevated Surface)" else "Elevated Slate",
        hex = "#20232E",
        color = HoggarColorTokens.SlateContainer,
        role = if (isArabic) "الحقول، الأزرار الثانوية، وحبوب التصفح" else "Input fields, secondary chips, and active pills",
      )
    }

    item {
      Text(
        text = if (isArabic) "ألوان النصوص والدلالات" else "Typography & Semantics",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "أبيض نقي (Text Primary)" else "Crisp White (Text Primary)",
        hex = "#FCFCFD",
        color = HoggarColorTokens.TextPrimary,
        role = if (isArabic) "العناوين والنصوص ذات الأولوية القصوى (تباين 16:1)" else "High-contrast headings & titles (16:1 contrast)",
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "رمادي فولاذي (Text Secondary)" else "Steel Gray (Text Secondary)",
        hex = "#A2A7B8",
        color = HoggarColorTokens.TextSecondary,
        role = if (isArabic) "النصوص الوصفية ومعلومات الحساب" else "Captions, metadata, and handles",
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "أخضر الواحة (Success)" else "Oasis Green (Success)",
        hex = "#10B981",
        color = HoggarColorTokens.SuccessOasis,
        role = if (isArabic) "حالات النجاح والتأكيد" else "Confirmations & success notifications",
      )
    }

    item {
      ColorSwatchItem(
        name = if (isArabic) "أحمر مرجاني (Error)" else "Coral Red (Error)",
        hex = "#EF4444",
        color = HoggarColorTokens.ErrorCoral,
        role = if (isArabic) "رسائل الخطأ وتنبيهات الحذف" else "Alerts & destructive actions",
      )
    }
  }
}

@Composable
private fun ColorSwatchItem(
  name: String,
  hex: String,
  color: Color,
  role: String,
) {
  HoggarCard(contentPadding = 12.dp) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(color)
          .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(10.dp)),
      )

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = name,
            color = HoggarColorTokens.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = hex,
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace,
          )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = role,
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
          lineHeight = 16.sp,
        )
      }
    }
  }
}

// -------------------------------------------------------------
// TAB 3: REUSABLE COMPONENTS & TOKENS
// -------------------------------------------------------------
@Composable
private fun ComponentsSection(isArabic: Boolean) {
  var buttonLoading by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp),
  ) {
    // Buttons Showcase
    item {
      HoggarCard {
        Text(
          text = if (isArabic) "أزرار الهڨار (Hoggar Buttons)" else "Hoggar Buttons",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = if (isArabic) "أبعاد لمسية مدروسة لا تقل عن 48dp مع ردود فعل بصرية سريعة" else "Minimum 48dp touch targets with instant ripple feedback.",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
        )

        Spacer(modifier = Modifier.height(16.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          HoggarButton(
            text = if (isArabic) "نحاسي أساسي (Primary)" else "Primary Copper",
            onClick = { buttonLoading = !buttonLoading },
            variant = HoggarButtonVariant.PrimaryCopper,
            isLoading = buttonLoading,
            modifier = Modifier.fillMaxWidth(),
          )

          HoggarButton(
            text = if (isArabic) "برتقالي تفاعلي (Interactive Accent)" else "Interactive Amber",
            onClick = {},
            variant = HoggarButtonVariant.InteractiveAmber,
            modifier = Modifier.fillMaxWidth(),
          )

          HoggarButton(
            text = if (isArabic) "زر بحدود داكنة (Outlined)" else "Outlined Action",
            onClick = {},
            variant = HoggarButtonVariant.Outlined,
            modifier = Modifier.fillMaxWidth(),
          )

          HoggarButton(
            text = if (isArabic) "إجراء شفاف (Ghost Action)" else "Ghost Action",
            onClick = {},
            variant = HoggarButtonVariant.Ghost,
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }
    }

    // Video Overlay Actions
    item {
      HoggarCard {
        Text(
          text = if (isArabic) "أزرار التفاعل مع الفيديو العمودي" else "Video Overlay Actions",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )

        Spacer(modifier = Modifier.height(14.dp))

        var isLiked by remember { mutableStateOf(false) }
        var isBookmarked by remember { mutableStateOf(false) }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceAround,
        ) {
          HoggarVideoAction(
            icon = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
            label = if (isLiked) "14.3K" else "14.2K",
            onClick = { isLiked = !isLiked },
            isActive = isLiked,
            activeTint = HoggarColorTokens.InteractiveAmber,
          )

          HoggarVideoAction(
            icon = Icons.Outlined.ChatBubbleOutline,
            label = "682",
            onClick = {},
          )

          HoggarVideoAction(
            icon = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
            label = "1.8K",
            onClick = { isBookmarked = !isBookmarked },
            isActive = isBookmarked,
            activeTint = HoggarColorTokens.InteractiveAmber,
          )

          HoggarVideoAction(
            icon = Icons.Outlined.Share,
            label = if (isArabic) "مشاركة" else "Share",
            onClick = {},
          )
        }
      }
    }

    // Badges & Tags
    item {
      HoggarCard {
        Text(
          text = if (isArabic) "الشارات والوسوم (Badges & Tags)" else "Badges & Tags",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          HoggarDurationBadge("60s")
          HoggarDurationBadge("15s")
          HoggarVerifiedBadge()
          HoggarTag(text = "#الهڨار", isInteractive = true)
          HoggarTag(text = "#تمنراست")
        }
      }
    }

    // Loading Indicator Showcase
    item {
      HoggarCard {
        Text(
          text = if (isArabic) "مؤشر التحميل المخصص (Loading Spinner)" else "Custom Brand Loading Spinner",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = if (isArabic) "نبض هندسي متناسق مستوحى من دوران رمز الهڨار" else "Harmonic geometric pulse and rotation of the Hoggar emblem.",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
        )

        Spacer(modifier = Modifier.height(20.dp))

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(90.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(HoggarColorTokens.SlateContainer),
          contentAlignment = Alignment.Center,
        ) {
          HoggarLoadingIndicator(size = 52.dp)
        }
      }
    }

    // Watermark Showcase
    item {
      HoggarCard {
        Text(
          text = if (isArabic) "العلامة المائية للفيديو (Video Watermark)" else "Exported Video Watermark",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = if (isArabic) "تظهر بشكل خفيف وغير مشتت في زاوية الفيديو" else "Discrete, non-intrusive brand stamp for exported content.",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
        )

        Spacer(modifier = Modifier.height(16.dp))

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF2B1810), Color(0xFF13151A)))),
        ) {
          HoggarWatermark(
            modifier = Modifier
              .align(Alignment.TopStart)
              .padding(12.dp),
          )
        }
      }
    }

    // Empty State Showcase
    item {
      HoggarCard {
        Text(
          text = if (isArabic) "حالة عدم وجود محتوى (Empty State)" else "Empty State Pattern",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )

        Spacer(modifier = Modifier.height(10.dp))

        HoggarEmptyState(
          title = if (isArabic) "لا توجد فيديوهات حتى الآن" else "No Videos Yet",
          description = if (isArabic) "ابدأ بمتابعة صُنّاع المحتوى في تمنراست والهڨار لاكتشاف اللحظات الرائعة." else "Follow Sahara creators to discover stunning vertical moments.",
          actionText = if (isArabic) "استكشاف المبدعين" else "Explore Creators",
          onActionClick = {},
        )
      }
    }
  }
}

// -------------------------------------------------------------
// TAB 4: FUTURE VERTICAL VIDEO SCREEN PREVIEW
// -------------------------------------------------------------
@Composable
private fun VideoPreviewSection(isArabic: Boolean) {
  var isLiked by remember { mutableStateOf(false) }
  var isBookmarked by remember { mutableStateOf(false) }
  var isFollowing by remember { mutableStateOf(false) }
  var isPlaying by remember { mutableStateOf(true) }
  var activeFeedTab by remember { mutableIntStateOf(0) } // 0 = For You, 1 = Following

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = { isPlaying = !isPlaying },
      )
      .testTag("video_preview_screen"),
  ) {
    // 1. Simulated Full-Bleed Video Background (Atmospheric volcanic peaks of Ahaggar)
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(
              Color(0xFF1F100B),
              Color(0xFF381A0F),
              Color(0xFF1C1318),
              Color(0xFF0D0E11),
            ),
          ),
        ),
    ) {
      // Subtle mountain peak geometric silhouettes in background
      HoggarLogoMark(
        size = 280.dp,
        showGlow = false,
        modifier = Modifier
          .align(Alignment.Center)
          .padding(bottom = 60.dp),
      )
    }

    // Top and Bottom Scrim Gradients for text readability
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(140.dp)
        .align(Alignment.TopCenter)
        .background(Brush.verticalGradient(listOf(HoggarColorTokens.ScrimTop, Color.Transparent))),
    )
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(220.dp)
        .align(Alignment.BottomCenter)
        .background(Brush.verticalGradient(listOf(Color.Transparent, HoggarColorTokens.ScrimBottom))),
    )

    // 2. Top Header Overlay (Minimalist Brand & Tabs)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp)
        .align(Alignment.TopCenter),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      // Subtle discrete watermark / logo in corner
      HoggarWatermark()

      // Center Tabs: "Following" / "For You"
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
      ) {
        Text(
          text = if (isArabic) "أتابعه" else "Following",
          color = if (activeFeedTab == 1) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
          fontSize = 15.sp,
          fontWeight = if (activeFeedTab == 1) FontWeight.Bold else FontWeight.Normal,
          modifier = Modifier
            .clickable { activeFeedTab = 1 }
            .padding(horizontal = 8.dp, vertical = 4.dp),
        )

        Box(
          modifier = Modifier
            .size(4.dp)
            .clip(CircleShape)
            .background(HoggarColorTokens.TextSecondary),
        )

        Text(
          text = if (isArabic) "لك" else "For You",
          color = if (activeFeedTab == 0) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
          fontSize = 15.sp,
          fontWeight = if (activeFeedTab == 0) FontWeight.Bold else FontWeight.Normal,
          modifier = Modifier
            .clickable { activeFeedTab = 0 }
            .padding(horizontal = 8.dp, vertical = 4.dp),
        )
      }

      // Max duration indicator badge
      HoggarDurationBadge("60s")
    }

    // 3. Right Action Column (Avatar, Like, Comment, Share, Bookmark)
    Column(
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(bottom = 70.dp, end = 12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Creator Avatar with Follow '+' Badge
      Box(
        contentAlignment = Alignment.BottomCenter,
        modifier = Modifier.padding(bottom = 6.dp),
      ) {
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(HoggarColorTokens.BasaltSurface)
            .border(1.5.dp, HoggarColorTokens.CopperPrimary, CircleShape),
          contentAlignment = Alignment.Center,
        ) {
          HoggarLogoMark(size = 26.dp)
        }

        if (!isFollowing) {
          Box(
            modifier = Modifier
              .size(20.dp)
              .clip(CircleShape)
              .background(HoggarColorTokens.InteractiveAmber)
              .clickable { isFollowing = true }
              .align(Alignment.BottomCenter),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = "+",
              color = HoggarColorTokens.TextPrimary,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }

      // Like
      HoggarVideoAction(
        icon = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
        label = if (isLiked) "38.5K" else "38.4K",
        onClick = { isLiked = !isLiked },
        isActive = isLiked,
        activeTint = HoggarColorTokens.InteractiveAmber,
      )

      // Comment
      HoggarVideoAction(
        icon = Icons.Outlined.ChatBubbleOutline,
        label = "1.2K",
        onClick = {},
      )

      // Bookmark
      HoggarVideoAction(
        icon = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
        label = "4.9K",
        onClick = { isBookmarked = !isBookmarked },
        isActive = isBookmarked,
        activeTint = HoggarColorTokens.InteractiveAmber,
      )

      // Share
      HoggarVideoAction(
        icon = Icons.Outlined.Share,
        label = if (isArabic) "مشاركة" else "Share",
        onClick = {},
      )

      // Audio Disc with Hoggar Accent
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(CircleShape)
          .background(HoggarColorTokens.SlateContainer)
          .border(1.dp, HoggarColorTokens.CopperPrimary, CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.MusicNote,
          contentDescription = null,
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(20.dp),
        )
      }
    }

    // 4. Bottom Video Info Overlay (Creator handle, Description, Sound, Tags)
    Column(
      modifier = Modifier
        .align(Alignment.BottomStart)
        .padding(start = 16.dp, end = 80.dp, bottom = 24.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = if (isArabic) "@مستكشف_الهڨار" else "@hoggar_explorer",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.width(6.dp))
        HoggarVerifiedBadge()

        if (isFollowing) {
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isArabic) "يتابع" else "Following",
            color = HoggarColorTokens.InteractiveAmber,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = if (isArabic)
          "غروب الشمس الساحر فوق قمم الغرانيت البركانية في الهڨار. تجربة المشاهدة العمودية أصبحت فائقة السرعة! #الهڨار #الجزائر #سياحة"
        else
          "Golden sunset over the majestic volcanic towers of Ahaggar. Lightning-fast vertical video experience! #Hoggar #Sahara #Algeria",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 13.sp,
        lineHeight = 19.sp,
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Audio Track Marquee
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.MusicNote,
          contentDescription = null,
          tint = HoggarColorTokens.TextSecondary,
          modifier = Modifier.size(14.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = if (isArabic) "الصوت الأصلي - رياح أسكرام الذهبية" else "Original Sound - Golden Winds of Assekrem",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 12.sp,
        )
      }
    }

    // 5. 60-Second Video Scrubber / Progress Line
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(3.dp)
        .align(Alignment.BottomCenter)
        .background(Color(0x33FFFFFF)),
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth(0.42f)
          .height(3.dp)
          .background(HoggarColorTokens.InteractiveAmber),
      )
    }

    // 6. Play / Pause Overlay Feedback
    AnimatedVisibility(
      visible = !isPlaying,
      modifier = Modifier.align(Alignment.Center),
    ) {
      Box(
        modifier = Modifier
          .size(68.dp)
          .clip(CircleShape)
          .background(Color(0x66000000)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.PlayArrow,
          contentDescription = "Paused",
          tint = HoggarColorTokens.TextPrimary,
          modifier = Modifier.size(40.dp),
        )
      }
    }
  }
}
