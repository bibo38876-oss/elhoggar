package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.interaction.model.NotificationItem
import com.example.interaction.model.NotificationPreferences
import com.example.interaction.model.NotificationType
import com.example.interaction.repository.NotificationRepository
import com.example.ui.components.HoggarCard
import com.example.ui.components.HoggarEmptyState
import com.example.ui.components.HoggarLogoMark
import com.example.ui.components.HoggarVerifiedBadge
import com.example.ui.theme.HoggarColorTokens

@Composable
fun ActivityScreen(
  userId: String,
  repository: NotificationRepository,
  onOpenVideo: ((String) -> Unit)? = null,
  onOpenProfile: ((String) -> Unit)? = null,
  isGuest: Boolean = false,
  onRequestAuth: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val notifications by repository.getNotifications(userId).collectAsState(initial = emptyList())
  val preferences by repository.getPreferences(userId).collectAsState(initial = NotificationPreferences())

  var selectedFilterTab by remember { mutableIntStateOf(0) } // 0: الكل, 1: التفاعلات, 2: المتابعات, 3: النظام والمحتوى
  var showSettingsDialog by remember { mutableStateOf(false) }

  val unreadCount = notifications.count { !it.isRead }

  val filteredNotifications = remember(notifications, selectedFilterTab) {
    when (selectedFilterTab) {
      1 -> notifications.filter { it.type == NotificationType.Like || it.type == NotificationType.Comment || it.type == NotificationType.Reply }
      2 -> notifications.filter { it.type == NotificationType.Follow }
      3 -> notifications.filter { it.type == NotificationType.System || it.type == NotificationType.Content }
      else -> notifications
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("activity_notifications_screen"),
  ) {
    if (isGuest) {
      // Header Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "الإشعارات والنشاط",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
        )
      }

      Box(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center,
      ) {
        HoggarEmptyState(
          title = "لا توجد إشعارات في وضع الزائر",
          description = "سجل دخولك لتصلك تنبيهات الإعجابات والمتابعين والتعليقات على فيديوهاتك في مجتمع الهڨار.",
          actionText = "تسجيل الدخول / إنشاء حساب",
          onActionClick = { onRequestAuth?.invoke() },
        )
      }
      return
    }
    // Header Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "الإشعارات والنشاط",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
        )
        if (unreadCount > 0) {
          Spacer(modifier = Modifier.width(8.dp))
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(HoggarColorTokens.InteractiveAmber)
              .padding(horizontal = 8.dp, vertical = 2.dp),
          ) {
            Text(
              text = "$unreadCount جديد",
              color = HoggarColorTokens.ObsidianBase,
              fontSize = 11.sp,
              fontWeight = FontWeight.ExtraBold,
            )
          }
        }
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        if (unreadCount > 0) {
          IconButton(
            onClick = { repository.markAllAsRead(userId) },
            modifier = Modifier.size(36.dp).testTag("btn_mark_all_read"),
          ) {
            Icon(
              imageVector = Icons.Filled.DoneAll,
              contentDescription = "Mark all read",
              tint = HoggarColorTokens.InteractiveAmber,
              modifier = Modifier.size(20.dp),
            )
          }
        }

        IconButton(
          onClick = { showSettingsDialog = true },
          modifier = Modifier.size(36.dp).testTag("btn_notification_settings"),
        ) {
          Icon(
            imageVector = Icons.Filled.Settings,
            contentDescription = "Notification Settings",
            tint = HoggarColorTokens.TextSecondary,
            modifier = Modifier.size(20.dp),
          )
        }
      }
    }

    // Filter Tabs
    val filterTabs = listOf("الكل", "التفاعلات", "المتابعات", "النظام والمحتوى")
    ScrollableTabRow(
      selectedTabIndex = selectedFilterTab,
      containerColor = HoggarColorTokens.BasaltSurface,
      contentColor = HoggarColorTokens.TextPrimary,
      edgePadding = 16.dp,
      indicator = { tabPositions ->
        SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedFilterTab]),
          color = HoggarColorTokens.InteractiveAmber,
        )
      },
    ) {
      filterTabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedFilterTab == index,
          onClick = { selectedFilterTab = index },
          text = {
            Text(
              text = title,
              color = if (selectedFilterTab == index) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextSecondary,
              fontWeight = if (selectedFilterTab == index) FontWeight.Bold else FontWeight.Normal,
              fontSize = 13.sp,
            )
          },
        )
      }
    }

    // List of Notifications
    if (filteredNotifications.isEmpty()) {
      HoggarEmptyState(
        title = "لا توجد إشعارات في هذا القسم",
        description = "ستظهر هنا تنبيهات المتابعين والتفاعلات ورسائل النظام فور وصولها.",
      )
    } else {
      val now = System.currentTimeMillis()
      val oneDayMs = 24 * 60 * 60 * 1000L
      val todayNotifications = filteredNotifications.filter { now - it.timestampMs < oneDayMs }
      val earlierNotifications = filteredNotifications.filter { now - it.timestampMs >= oneDayMs }

      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp, vertical = 8.dp),
      ) {
        if (todayNotifications.isNotEmpty()) {
          item {
            Text(
              text = "اليوم",
              color = HoggarColorTokens.TextSecondary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(top = 4.dp, bottom = 2.dp),
            )
          }
          items(todayNotifications, key = { it.id }) { item ->
            NotificationRowItem(
              item = item,
              onClick = {
                repository.markAsRead(item.id, userId)
                if (item.targetVideoId != null && onOpenVideo != null) {
                  onOpenVideo(item.targetVideoId)
                } else if (item.actor != null && onOpenProfile != null) {
                  onOpenProfile(item.actor.id)
                }
              },
            )
          }
        }

        if (earlierNotifications.isNotEmpty()) {
          item {
            Text(
              text = "سابقاً",
              color = HoggarColorTokens.TextSecondary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(top = 10.dp, bottom = 2.dp),
            )
          }
          items(earlierNotifications, key = { it.id }) { item ->
            NotificationRowItem(
              item = item,
              onClick = {
                repository.markAsRead(item.id, userId)
                if (item.targetVideoId != null && onOpenVideo != null) {
                  onOpenVideo(item.targetVideoId)
                } else if (item.actor != null && onOpenProfile != null) {
                  onOpenProfile(item.actor.id)
                }
              },
            )
          }
        }
      }
    }
  }

  // Settings Dialog
  if (showSettingsDialog) {
    NotificationSettingsDialog(
      initialPreferences = preferences,
      onSave = { updated -> repository.updatePreferences(userId, updated) },
      onDismiss = { showSettingsDialog = false },
    )
  }
}

@Composable
private fun NotificationRowItem(
  item: NotificationItem,
  onClick: () -> Unit,
) {
  HoggarCard(
    contentPadding = 12.dp,
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("notif_item_${item.id}"),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      // Left Emblem / Avatar with type badge
      Box(
        modifier = Modifier.size(46.dp),
        contentAlignment = Alignment.BottomEnd,
      ) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(HoggarColorTokens.SlateContainer),
          contentAlignment = Alignment.Center,
        ) {
          if (item.actor != null) {
            if (item.actor.avatarUrl.isNotEmpty()) {
              AsyncImage(
                model = item.actor.avatarUrl,
                contentDescription = item.actor.displayName,
                modifier = Modifier.fillMaxSize().clip(CircleShape),
                contentScale = ContentScale.Crop,
              )
            } else {
              Text(
                text = item.actor.displayName.take(1),
                color = HoggarColorTokens.InteractiveAmber,
                fontWeight = FontWeight.Bold,
              )
            }
          } else {
            // System / Content Logo
            HoggarLogoMark(size = 24.dp)
          }
        }

        // Mini Type Badge
        val badgeColor = when (item.type) {
          NotificationType.Like -> HoggarColorTokens.InteractiveAmber
          NotificationType.Comment, NotificationType.Reply -> HoggarColorTokens.CopperPrimary
          NotificationType.Follow -> HoggarColorTokens.SuccessOasis
          NotificationType.Content -> Color(0xFF42A5F5)
          NotificationType.System -> HoggarColorTokens.InteractiveAmber
        }

        Box(
          modifier = Modifier
            .size(18.dp)
            .clip(CircleShape)
            .background(badgeColor),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = when (item.type) {
              NotificationType.Like -> Icons.Filled.Favorite
              NotificationType.Comment -> Icons.Filled.ChatBubble
              NotificationType.Reply -> Icons.AutoMirrored.Filled.Reply
              NotificationType.Follow -> Icons.Filled.PersonAdd
              NotificationType.Content -> Icons.Filled.Videocam
              NotificationType.System -> Icons.Filled.Campaign
            },
            contentDescription = null,
            tint = HoggarColorTokens.ObsidianBase,
            modifier = Modifier.size(11.dp),
          )
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      // Content description & timestamp
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = item.actor?.displayName ?: item.title,
            color = HoggarColorTokens.TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
          )
          if (item.actor?.isVerified == true) {
            Spacer(modifier = Modifier.width(4.dp))
            HoggarVerifiedBadge()
          }
          if (item.batchCount > 1) {
            Spacer(modifier = Modifier.width(6.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(HoggarColorTokens.SlateContainer)
                .padding(horizontal = 4.dp, vertical = 1.dp),
            ) {
              Text(
                text = "+${item.batchCount}",
                color = HoggarColorTokens.InteractiveAmber,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
          text = item.previewText,
          color = if (item.isRead) HoggarColorTokens.TextSecondary else HoggarColorTokens.TextPrimary,
          fontSize = 12.sp,
          maxLines = 2,
        )

        Spacer(modifier = Modifier.height(3.dp))

        Text(
          text = formatRelativeTime(item.timestampMs),
          color = HoggarColorTokens.TextTertiary,
          fontSize = 10.sp,
        )
      }

      // Right: Video Thumbnail (if linked) & Unread indicator dot
      if (item.targetThumbnailUrl != null) {
        Spacer(modifier = Modifier.width(10.dp))
        Box(
          modifier = Modifier
            .width(42.dp)
            .aspectRatio(9f / 14f)
            .clip(RoundedCornerShape(6.dp))
            .background(HoggarColorTokens.BasaltSurface),
        ) {
          AsyncImage(
            model = item.targetThumbnailUrl,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
          )
        }
      }

      if (!item.isRead) {
        Spacer(modifier = Modifier.width(8.dp))
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(HoggarColorTokens.InteractiveAmber),
        )
      }
    }
  }
}

private fun formatRelativeTime(timestampMs: Long): String {
  val diffMs = System.currentTimeMillis() - timestampMs
  val minutes = diffMs / 60000L
  val hours = minutes / 60L
  val days = hours / 24L

  return when {
    minutes < 1L -> "الآن"
    minutes < 60L -> "منذ $minutes دقيقة"
    hours < 24L -> "منذ $hours ساعة"
    else -> "منذ $days يوم"
  }
}
