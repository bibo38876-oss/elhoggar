package com.example.ui.profile

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Share
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Settings
import com.example.localization.hoggarString
import com.example.ui.screens.AboutAndLegalSheet
import com.example.ui.screens.LegalTab
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.VideoItem
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarDurationBadge
import com.example.ui.components.HoggarEmptyState
import com.example.ui.components.HoggarLoadingIndicator
import com.example.ui.components.HoggarLogoMark
import com.example.ui.components.HoggarVerifiedBadge
import com.example.ui.screens.DataSaverSettingsDialog
import com.example.ui.theme.HoggarColorTokens
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Shield
import com.example.ui.create.DeleteVideoDialog
import com.example.user.UserProfile
import com.example.user.UserRole

@Composable
fun ProfileScreen(
  targetUserId: String?,
  viewModel: ProfileViewModel,
  onBack: (() -> Unit)? = null,
  onEditProfile: (UserProfile) -> Unit,
  onOpenDesignSystem: () -> Unit,
  onLogout: () -> Unit,
  onDeleteAccount: (String) -> Unit,
  onVideoClick: (VideoItem) -> Unit,
  onDeleteVideo: ((videoId: String) -> Unit)? = null,
  onOpenCreatorStudio: (() -> Unit)? = null,
  onOpenAdmin: (() -> Unit)? = null,
  onOpenSettings: (() -> Unit)? = null,
  onRequestAuth: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val uiState by viewModel.uiState.collectAsState()
  val userVideos by viewModel.userVideos.collectAsState()

  var showDeleteDialog by remember { mutableStateOf(false) }
  var videoToDelete by remember { mutableStateOf<VideoItem?>(null) }
  var selectedTab by remember { mutableIntStateOf(0) } // 0: Videos, 1: Liked, 2: Saved

  LaunchedEffect(targetUserId) {
    viewModel.loadProfile(targetUserId)
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("profile_screen"),
  ) {
    when (val state = uiState) {
      is ProfileUiState.Loading -> {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          HoggarLoadingIndicator(size = 56.dp)
        }
      }

      is ProfileUiState.Guest -> {
        GuestProfileView(
          onRequestAuth = { onRequestAuth?.invoke() },
          onOpenSettings = onOpenSettings,
          onOpenDesignSystem = onOpenDesignSystem,
        )
      }

      is ProfileUiState.Error -> {
        HoggarEmptyState(
          title = "تعذر تحميل الملف الشخصي",
          description = state.message,
          actionText = "إعادة المحاولة",
          onActionClick = { viewModel.loadProfile(targetUserId) },
        )
      }

      is ProfileUiState.Success -> {
        val profile = state.profile

        LazyVerticalGrid(
          columns = GridCells.Fixed(3),
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(bottom = 24.dp),
          horizontalArrangement = Arrangement.spacedBy(2.dp),
          verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
          // Profile Header Span (Full Width)
          item(span = { GridItemSpan(3) }) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              // Top Action Row
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                if (onBack != null) {
                  IconButton(onClick = onBack) {
                    Icon(
                      imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                      contentDescription = "Back",
                      tint = HoggarColorTokens.TextPrimary,
                    )
                  }
                } else {
                  Spacer(modifier = Modifier.width(48.dp))
                }

                Text(
                  text = "@${profile.username}",
                  color = HoggarColorTokens.TextPrimary,
                  fontSize = 17.sp,
                  fontWeight = FontWeight.Bold,
                )

                if (profile.isCurrentUser && onOpenSettings != null) {
                  IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.testTag("profile_settings_button"),
                  ) {
                    Icon(
                      imageVector = Icons.Filled.Settings,
                      contentDescription = hoggarString("settings"),
                      tint = HoggarColorTokens.TextPrimary,
                    )
                  }
                } else {
                  Spacer(modifier = Modifier.width(48.dp))
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              // Avatar with Hoggar Copper Rim
              Box(
                modifier = Modifier
                  .size(90.dp)
                  .clip(CircleShape)
                  .background(HoggarColorTokens.BasaltSurface)
                  .border(
                    2.5.dp,
                    if (profile.role == UserRole.OfficialBrand) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.CopperPrimary,
                    CircleShape,
                  ),
                contentAlignment = Alignment.Center,
              ) {
                if (profile.avatarUrl.isNotEmpty()) {
                  AsyncImage(
                    model = profile.avatarUrl,
                    contentDescription = profile.displayName,
                    modifier = Modifier.fillMaxSize().clip(CircleShape),
                  )
                } else {
                  HoggarLogoMark(size = 48.dp, showGlow = profile.role == UserRole.OfficialBrand)
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              // Display Name & Verified Crest
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = profile.displayName,
                  color = HoggarColorTokens.TextPrimary,
                  fontSize = 19.sp,
                  fontWeight = FontWeight.Bold,
                )
                Spacer(modifier = Modifier.width(6.dp))
                if (profile.role == UserRole.OfficialBrand) {
                  // Official Brand Emblem Badge
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(6.dp))
                      .background(HoggarColorTokens.InteractiveAmber)
                      .padding(horizontal = 6.dp, vertical = 2.dp),
                    contentAlignment = Alignment.Center,
                  ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      HoggarLogoMark(size = 12.dp)
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = "رسمي",
                        color = HoggarColorTokens.ObsidianBase,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                      )
                    }
                  }
                } else if (profile.isVerified) {
                  HoggarVerifiedBadge()
                }
              }

              Spacer(modifier = Modifier.height(4.dp))

              // Bio
              if (profile.bio.isNotEmpty()) {
                Text(
                  text = profile.bio,
                  color = HoggarColorTokens.TextSecondary,
                  fontSize = 13.sp,
                  lineHeight = 19.sp,
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(horizontal = 16.dp),
                )
              }

              Spacer(modifier = Modifier.height(18.dp))

              // Stats Row (Followers, Following, Likes)
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .background(HoggarColorTokens.SlateContainer)
                  .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                StatColumn(count = formatNumber(profile.followingCount), label = "أتابعه")
                Box(modifier = Modifier.width(1.dp).height(24.dp).background(HoggarColorTokens.BorderSubtle))
                StatColumn(count = formatNumber(profile.followersCount), label = "المتابعون")
                Box(modifier = Modifier.width(1.dp).height(24.dp).background(HoggarColorTokens.BorderSubtle))
                StatColumn(count = formatNumber(profile.totalLikesCount), label = "الإعجابات")
              }

              Spacer(modifier = Modifier.height(16.dp))

              // Primary Action: Edit Profile vs Follow/Unfollow
              val context = LocalContext.current
              val shareProfile = {
                val profileUrl = "https://elhoggar.dz/@${profile.username}"
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                  type = "text/plain"
                  putExtra(Intent.EXTRA_SUBJECT, "الملف الشخصي لـ ${profile.displayName} على الهڨار")
                  putExtra(Intent.EXTRA_TEXT, "شاهد فيديوهات ${profile.displayName} (@${profile.username}) على منصة الهڨار:\n$profileUrl")
                }
                context.startActivity(Intent.createChooser(sendIntent, "مشاركة الملف الشخصي"))
              }

              if (profile.isCurrentUser) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  HoggarButton(
                    text = "تعديل الملف",
                    onClick = { onEditProfile(profile) },
                    variant = HoggarButtonVariant.Outlined,
                    modifier = Modifier.weight(1.2f).testTag("btn_edit_profile"),
                  )
                  HoggarButton(
                    text = "مشاركة",
                    icon = Icons.Filled.Share,
                    onClick = shareProfile,
                    variant = HoggarButtonVariant.Outlined,
                    modifier = Modifier.weight(1f).testTag("btn_share_my_profile"),
                  )
                  if (onOpenSettings != null) {
                    IconButton(
                      onClick = onOpenSettings,
                      modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(HoggarColorTokens.SlateContainer)
                        .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp))
                        .testTag("btn_profile_settings"),
                    ) {
                      Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = "الإعدادات",
                        tint = HoggarColorTokens.TextPrimary,
                      )
                    }
                  }
                }

                if (onOpenCreatorStudio != null) {
                  Spacer(modifier = Modifier.height(10.dp))
                  Box(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(12.dp))
                      .background(
                        Brush.horizontalGradient(
                          listOf(Color(0xFF2E190E), Color(0xFF1F242C)),
                        ),
                      )
                      .border(1.dp, HoggarColorTokens.CopperPrimary.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                      .clickable(onClick = onOpenCreatorStudio)
                      .padding(horizontal = 14.dp, vertical = 10.dp)
                      .testTag("btn_creator_studio_banner"),
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                          modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(HoggarColorTokens.CopperPrimary.copy(alpha = 0.25f)),
                          contentAlignment = Alignment.Center,
                        ) {
                          Icon(
                            imageVector = Icons.Filled.Insights,
                            contentDescription = null,
                            tint = HoggarColorTokens.InteractiveAmber,
                            modifier = Modifier.size(18.dp),
                          )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                          Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                              text = "استوديو صانع المحتوى",
                              color = HoggarColorTokens.TextPrimary,
                              fontSize = 13.sp,
                              fontWeight = FontWeight.Bold,
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                              modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(HoggarColorTokens.InteractiveAmber)
                                .padding(horizontal = 4.dp, vertical = 1.dp),
                            ) {
                              Text(
                                text = "PRO",
                                color = HoggarColorTokens.ObsidianBase,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black,
                              )
                            }
                          }
                          Text(
                            text = "تحليلات تيك توك، إدارة الفيديوهات وخزينة الأصوات",
                            color = HoggarColorTokens.TextSecondary,
                            fontSize = 10.sp,
                          )
                        }
                      }
                      Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = null,
                        tint = HoggarColorTokens.InteractiveAmber,
                        modifier = Modifier.size(16.dp),
                      )
                    }
                  }
                }
              } else {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  HoggarButton(
                    text = if (profile.isFollowing) "أتابعه" else "متابعة",
                    onClick = { viewModel.toggleFollow(profile.id) },
                    variant = if (profile.isFollowing) HoggarButtonVariant.Outlined else HoggarButtonVariant.PrimaryCopper,
                    modifier = Modifier.weight(1.5f).testTag("btn_toggle_follow_profile"),
                  )
                  HoggarButton(
                    text = "مشاركة",
                    icon = Icons.Filled.Share,
                    onClick = shareProfile,
                    variant = HoggarButtonVariant.Outlined,
                    modifier = Modifier.weight(1f).testTag("btn_share_other_profile"),
                  )
                }
              }

              Spacer(modifier = Modifier.height(20.dp))

              // Tabs: الفيديوهات، خاص (لصاحب الحساب فقط)
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(10.dp))
                  .background(HoggarColorTokens.SlateContainer)
                  .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceAround,
              ) {
                ProfileTabPill(
                  label = "الفيديوهات (${userVideos.size})",
                  isSelected = selectedTab == 0,
                  onClick = { selectedTab = 0 },
                )
                if (profile.isCurrentUser) {
                  ProfileTabPill(
                    label = "خاص",
                    isSelected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))
            }
          }

          // If Private Account and not followed
          if (profile.isPrivate && !profile.isFollowing && !profile.isCurrentUser) {
            item(span = { GridItemSpan(3) }) {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(40.dp),
                contentAlignment = Alignment.Center,
              ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = null,
                    tint = HoggarColorTokens.TextSecondary,
                    modifier = Modifier.size(48.dp),
                  )
                  Spacer(modifier = Modifier.height(12.dp))
                  Text(
                    text = "هذا الحساب خاص",
                    color = HoggarColorTokens.TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                  )
                  Text(
                    text = "تابع هذا المستخدم لرؤية فيديوهاته وقصصه العمودية.",
                    color = HoggarColorTokens.TextSecondary,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                  )
                }
              }
            }
          } else {
            // Videos Grid based on Tab
            val displayedVideos = if (selectedTab == 1) {
              userVideos.filter { it.visibility == com.example.model.VideoVisibility.Private }
            } else {
              userVideos.filter { it.visibility != com.example.model.VideoVisibility.Private || profile.isCurrentUser }
            }

            if (displayedVideos.isEmpty()) {
              item(span = { GridItemSpan(3) }) {
                HoggarEmptyState(
                  title = if (selectedTab == 1) "لا توجد فيديوهات خاصة" else "لم تنشر أي فيديوهات بعد",
                  description = if (selectedTab == 1) "الفيديوهات التي تضبطها كخاصة تظهر لك وحدك هنا." else "شارك لحظاتك في الهڨار لنشر أول فيديو عمودي.",
                )
              }
            } else {
              items(displayedVideos, key = { it.id }) { video ->
                VideoGridThumbnail(
                  video = video,
                  isOwner = profile.isCurrentUser,
                  onClick = { onVideoClick(video) },
                  onDeleteClick = if (profile.isCurrentUser) { { videoToDelete = video } } else null,
                )
              }
            }
          }
        }

        // Delete Video Confirmation Dialog
        videoToDelete?.let { video ->
          DeleteVideoDialog(
            onConfirmDelete = {
              onDeleteVideo?.invoke(video.id)
              videoToDelete = null
            },
            onDismiss = { videoToDelete = null },
          )
        }

        // Delete Account Confirmation Dialog
        if (showDeleteDialog) {
          DeleteAccountDialog(
            onConfirmDelete = {
              showDeleteDialog = false
              onDeleteAccount(profile.id)
            },
            onDismiss = { showDeleteDialog = false },
          )
        }
      }
    }
  }
}

@Composable
private fun StatColumn(count: String, label: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = count,
      color = HoggarColorTokens.TextPrimary,
      fontSize = 16.sp,
      fontWeight = FontWeight.Bold,
    )
    Text(
      text = label,
      color = HoggarColorTokens.TextSecondary,
      fontSize = 12.sp,
    )
  }
}

@Composable
private fun ProfileTabPill(label: String, isSelected: Boolean, onClick: () -> Unit) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .background(if (isSelected) HoggarColorTokens.CopperPrimary else Color.Transparent)
      .clickable(onClick = onClick)
      .padding(horizontal = 14.dp, vertical = 7.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = label,
      color = if (isSelected) HoggarColorTokens.TextPrimary else HoggarColorTokens.TextSecondary,
      fontSize = 12.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
    )
  }
}

@Composable
private fun VideoGridThumbnail(
  video: VideoItem,
  isOwner: Boolean = false,
  onClick: () -> Unit,
  onDeleteClick: (() -> Unit)? = null,
) {
  Box(
    modifier = Modifier
      .aspectRatio(9f / 14f)
      .clip(RoundedCornerShape(4.dp))
      .background(HoggarColorTokens.BasaltSurface)
      .clickable(onClick = onClick),
  ) {
    AsyncImage(
      model = video.thumbnailUrl,
      contentDescription = video.title,
      modifier = Modifier.fillMaxSize(),
    )

    // Gradient Scrim at bottom
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(44.dp)
        .align(Alignment.BottomCenter)
        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))),
    )

    // Duration Badge at Top End
    HoggarDurationBadge(
      durationText = "${video.durationSeconds}s",
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(4.dp),
    )

    // Delete Button at Top Start (Owner Only)
    if (isOwner && onDeleteClick != null) {
      Box(
        modifier = Modifier
          .align(Alignment.TopStart)
          .padding(4.dp)
          .size(24.dp)
          .clip(CircleShape)
          .background(Color(0x88000000))
          .clickable(onClick = onDeleteClick),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.Delete,
          contentDescription = "Delete Video",
          tint = HoggarColorTokens.ErrorCoral,
          modifier = Modifier.size(14.dp),
        )
      }
    }

    // Views Count at Bottom
    Row(
      modifier = Modifier
        .align(Alignment.BottomStart)
        .padding(6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Filled.PlayArrow,
        contentDescription = null,
        tint = HoggarColorTokens.TextPrimary,
        modifier = Modifier.size(14.dp),
      )
      Spacer(modifier = Modifier.width(3.dp))
      Text(
        text = formatNumber(video.stats.viewsCount),
        color = HoggarColorTokens.TextPrimary,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
      )
    }
  }
}

private fun formatNumber(count: Long): String {
  return when {
    count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
    count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
    else -> count.toString()
  }
}

@Composable
private fun GuestProfileView(
  onRequestAuth: () -> Unit,
  onOpenSettings: (() -> Unit)?,
  onOpenDesignSystem: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 20.dp, vertical = 16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    // Top Bar
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        HoggarLogoMark(size = 32.dp, showGlow = false)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "الملف الشخصي",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
        )
      }

      if (onOpenSettings != null) {
        IconButton(
          onClick = onOpenSettings,
          modifier = Modifier.size(40.dp).testTag("btn_guest_settings"),
        ) {
          Icon(
            imageVector = Icons.Filled.Settings,
            contentDescription = "Settings",
            tint = HoggarColorTokens.TextSecondary,
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Hero Desert Card
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(20.dp))
        .background(
          Brush.verticalGradient(
            colors = listOf(
              HoggarColorTokens.CopperPrimary.copy(alpha = 0.25f),
              HoggarColorTokens.BasaltSurface,
            ),
          ),
        )
        .border(1.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(20.dp))
        .padding(24.dp),
      contentAlignment = Alignment.Center,
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        HoggarLogoMark(size = 72.dp, showGlow = true)
        Spacer(modifier = Modifier.height(14.dp))
        Text(
          text = "انضم إلى مجتمع الهڨار",
          color = HoggarColorTokens.TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.ExtraBold,
          textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "أنت تتصفح التطبيق حالياً في وضع الزائر. سجل دخولك أو أنشئ حساباً جديداً لنشر فيديوهاتك، حفظ المفضلات، والتفاعل مع المبدعين.",
          color = HoggarColorTokens.TextSecondary,
          fontSize = 13.sp,
          lineHeight = 18.sp,
          textAlign = TextAlign.Center,
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Action CTA Buttons
    HoggarButton(
      text = "تسجيل الدخول / إنشاء حساب",
      variant = HoggarButtonVariant.PrimaryCopper,
      onClick = onRequestAuth,
      modifier = Modifier.fillMaxWidth().testTag("btn_guest_profile_auth"),
    )

    Spacer(modifier = Modifier.height(14.dp))

    HoggarButton(
      text = "استكشاف نظام التصميم والهوية",
      variant = HoggarButtonVariant.Ghost,
      onClick = onOpenDesignSystem,
      modifier = Modifier.fillMaxWidth(),
    )
  }
}
