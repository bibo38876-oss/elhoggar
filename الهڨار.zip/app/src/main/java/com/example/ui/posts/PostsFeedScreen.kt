package com.example.ui.posts

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.ModeComment
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.repository.PostRepository
import com.example.model.PostItem
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.components.HoggarEmptyState
import com.example.ui.components.HoggarLogoMark
import com.example.ui.components.HoggarVerifiedBadge
import com.example.ui.theme.HoggarColorTokens
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PostsFeedScreen(
  postRepository: PostRepository,
  currentUserId: String,
  onOpenCreatePost: () -> Unit,
  onOpenCreatorProfile: (String) -> Unit,
  onOpenHashtag: (String) -> Unit,
  onOpenSearch: () -> Unit,
  isGuest: Boolean = false,
  onRequestAuth: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val scope = rememberCoroutineScope()
  val allPosts by postRepository.getAllPosts().collectAsState(initial = emptyList())

  var selectedTab by remember { mutableIntStateOf(0) } // 0: لك (For You), 1: الأحدث (Latest), 2: وسائط وصور (Photos), 3: الرائجة (Trending)
  var selectedTagFilter by remember { mutableStateOf<String?>(null) }

  val trendingTags = listOf(
    "#الهڨار",
    "#أسكرام",
    "#تمنراست",
    "#تيناريوين",
    "#صناعة_الفضة",
    "#طاسيلي",
    "#شاي_صحراوي",
  )

  val filteredPosts = remember(allPosts, selectedTab, selectedTagFilter) {
    var list = if (selectedTagFilter != null) {
      allPosts.filter { it.tags.any { t -> t.equals(selectedTagFilter, ignoreCase = true) } || it.contentText.contains(selectedTagFilter!!) }
    } else {
      allPosts
    }

    when (selectedTab) {
      0 -> list // Default For You
      1 -> list.sortedByDescending { it.timestampMs } // Latest
      2 -> list.filter { it.imageUrls.isNotEmpty() } // Media with images
      3 -> list.sortedByDescending { it.likesCount + it.repostsCount * 2 } // Trending
      else -> list
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("posts_feed_screen"),
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // 1. Header Bar: Logo + Title + Search action + Create shortcut
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          HoggarLogoMark(size = 28.dp)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "مجتمع الهڨار",
                color = HoggarColorTokens.TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
              )
              Spacer(modifier = Modifier.width(6.dp))
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(HoggarColorTokens.InteractiveAmber)
                  .padding(horizontal = 5.dp, vertical = 1.dp),
              ) {
                Text(
                  text = "POSTS",
                  color = HoggarColorTokens.ObsidianBase,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Black,
                )
              }
            }
            Text(
              text = "تغريدات ومنشورات كتابية ومصورة من صناع المحتوى",
              color = HoggarColorTokens.TextTertiary,
              fontSize = 10.sp,
            )
          }
        }

        // Search action button (Quickly access Discover / Search)
        IconButton(
          onClick = onOpenSearch,
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(HoggarColorTokens.SlateContainer)
            .border(1.dp, HoggarColorTokens.BorderSubtle, CircleShape)
            .testTag("btn_posts_open_search"),
        ) {
          Icon(
            imageVector = Icons.Filled.Search,
            contentDescription = "Search & Discover",
            tint = HoggarColorTokens.InteractiveAmber,
            modifier = Modifier.size(18.dp),
          )
        }
      }

      // 2. Feed Filter Tabs (Twitter/X style: لك / الأحدث / وسائط / الرائجة)
      ScrollableTabRow(
        selectedTabIndex = selectedTab,
        containerColor = HoggarColorTokens.BasaltSurface,
        contentColor = HoggarColorTokens.InteractiveAmber,
        edgePadding = 16.dp,
        indicator = { tabPositions ->
          if (selectedTab < tabPositions.size) {
            TabRowDefaults.SecondaryIndicator(
              modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
              color = HoggarColorTokens.InteractiveAmber,
              height = 3.dp,
            )
          }
        },
      ) {
        listOf("لك (For You)", "الأحدث", "الصور والوسائط", "الأكثر تفاعلاً 🔥").forEachIndexed { index, title ->
          val isSelected = selectedTab == index
          Tab(
            selected = isSelected,
            onClick = {
              selectedTab = index
              selectedTagFilter = null
            },
            text = {
              Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextSecondary,
              )
            },
          )
        }
      }

      // 3. Trending Topics Quick Carousel Bar
      LazyRow(
        modifier = Modifier
          .fillMaxWidth()
          .background(HoggarColorTokens.ObsidianBase)
          .padding(vertical = 8.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        items(trendingTags) { tag ->
          val isSelected = selectedTagFilter == tag
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) HoggarColorTokens.CopperPrimary else HoggarColorTokens.SlateContainer)
              .border(0.5.dp, if (isSelected) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.BorderSubtle, RoundedCornerShape(8.dp))
              .clickable {
                selectedTagFilter = if (isSelected) null else tag
              }
              .padding(horizontal = 10.dp, vertical = 5.dp),
          ) {
            Text(
              text = tag,
              color = if (isSelected) HoggarColorTokens.TextPrimary else HoggarColorTokens.InteractiveAmber,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }

      // 4. Posts List / Timeline
      if (filteredPosts.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
          contentAlignment = Alignment.Center,
        ) {
          HoggarEmptyState(
            title = "لا توجد منشورات حالياً في هذا القسم",
            description = "كن أول من ينشر أفكاره وتغريداته في مجتمع الهڨار!",
            actionText = "كتابة منشور الآن",
            onActionClick = {
              if (isGuest) onRequestAuth?.invoke() else onOpenCreatePost()
            },
          )
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxSize()
            .testTag("posts_timeline_list"),
          contentPadding = PaddingValues(bottom = 90.dp),
        ) {
          items(filteredPosts, key = { it.id }) { post ->
            PostCardItem(
              post = post,
              currentUserId = currentUserId,
              onLikeClick = {
                scope.launch { postRepository.toggleLike(post.id) }
              },
              onRepostClick = {
                scope.launch { postRepository.toggleRepost(post.id) }
              },
              onBookmarkClick = {
                scope.launch { postRepository.toggleBookmark(post.id) }
              },
              onDeleteClick = {
                scope.launch { postRepository.deletePost(post.id, currentUserId) }
              },
              onAuthorClick = {
                onOpenCreatorProfile(post.author.id)
              },
              onHashtagClick = { tag ->
                selectedTagFilter = tag
                onOpenHashtag(tag)
              },
            )
            // Divider between tweets/posts
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(0.5.dp)
                .background(HoggarColorTokens.BorderSubtle.copy(alpha = 0.5f)),
            )
          }
        }
      }
    }

    // 5. Floating Action Button: New Post (Twitter / X style pen icon)
    FloatingActionButton(
      onClick = {
        if (isGuest) {
          onRequestAuth?.invoke()
        } else {
          onOpenCreatePost()
        }
      },
      containerColor = HoggarColorTokens.CopperPrimary,
      contentColor = HoggarColorTokens.TextPrimary,
      shape = CircleShape,
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(end = 18.dp, bottom = 80.dp)
        .size(56.dp)
        .testTag("fab_create_post"),
    ) {
      Icon(
        imageVector = Icons.Filled.Edit,
        contentDescription = "New Post",
        modifier = Modifier.size(24.dp),
      )
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PostCardItem(
  post: PostItem,
  currentUserId: String,
  onLikeClick: () -> Unit,
  onRepostClick: () -> Unit,
  onBookmarkClick: () -> Unit,
  onDeleteClick: () -> Unit,
  onAuthorClick: () -> Unit,
  onHashtagClick: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val isMyPost = post.author.id == currentUserId || currentUserId == "admin"

  val formattedTime = remember(post.timestampMs) {
    val diff = System.currentTimeMillis() - post.timestampMs
    val minutes = diff / (1000 * 60)
    val hours = diff / (1000 * 60 * 60)
    val days = diff / (1000 * 60 * 60 * 24)
    when {
      minutes < 1 -> "الآن"
      minutes < 60 -> "$minutes د"
      hours < 24 -> "$hours س"
      days < 7 -> "$days ي"
      else -> SimpleDateFormat("d MMM", Locale("ar")).format(Date(post.timestampMs))
    }
  }

  Row(
    modifier = modifier
      .fillMaxWidth()
      .background(HoggarColorTokens.ObsidianBase)
      .padding(horizontal = 16.dp, vertical = 14.dp)
      .testTag("post_item_${post.id}"),
    horizontalArrangement = Arrangement.Start,
  ) {
    // 1. Author Avatar
    AsyncImage(
      model = post.author.avatarUrl.ifEmpty { "https://picsum.photos/seed/user_avatar/200/200" },
      contentDescription = post.author.displayName,
      modifier = Modifier
        .size(42.dp)
        .clip(CircleShape)
        .border(1.dp, HoggarColorTokens.CopperPrimary.copy(alpha = 0.6f), CircleShape)
        .clickable(onClick = onAuthorClick),
    )

    Spacer(modifier = Modifier.width(12.dp))

    // 2. Post Body
    Column(modifier = Modifier.weight(1f)) {
      // Author display name + username + time + delete menu
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f, fill = false),
        ) {
          Text(
            text = post.author.displayName,
            color = HoggarColorTokens.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.clickable(onClick = onAuthorClick),
          )
          if (post.author.isVerified) {
            Spacer(modifier = Modifier.width(4.dp))
            HoggarVerifiedBadge(size = 14.dp)
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "@${post.author.username}",
            color = HoggarColorTokens.TextTertiary,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "· $formattedTime",
            color = HoggarColorTokens.TextTertiary,
            fontSize = 11.sp,
          )
        }

        if (isMyPost) {
          IconButton(
            onClick = onDeleteClick,
            modifier = Modifier.size(24.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Delete,
              contentDescription = "Delete",
              tint = HoggarColorTokens.TextTertiary,
              modifier = Modifier.size(16.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Content Text
      Text(
        text = post.contentText,
        color = HoggarColorTokens.TextPrimary,
        fontSize = 14.sp,
        lineHeight = 22.sp,
      )

      // Attached Images (1, 2, 3, or 4 images Twitter-style grid)
      if (post.imageUrls.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        PostImagesGrid(imageUrls = post.imageUrls)
      }

      // Hashtags chips
      if (post.tags.isNotEmpty()) {
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          post.tags.forEach { tag ->
            Text(
              text = tag,
              color = HoggarColorTokens.InteractiveAmber,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.clickable { onHashtagClick(tag) },
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Social Interactions Bar (Replies, Reposts, Likes, Views, Share)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        // 1. Comments / Replies
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.clickable { /* Reply handler */ },
        ) {
          Icon(
            imageVector = Icons.Filled.ModeComment,
            contentDescription = "Replies",
            tint = HoggarColorTokens.TextTertiary,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (post.repliesCount > 0) "${post.repliesCount}" else "",
            color = HoggarColorTokens.TextTertiary,
            fontSize = 11.sp,
          )
        }

        // 2. Repost / Retweet
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.clickable(onClick = onRepostClick),
        ) {
          Icon(
            imageVector = Icons.Filled.Repeat,
            contentDescription = "Repost",
            tint = if (post.isReposted) HoggarColorTokens.SuccessOasis else HoggarColorTokens.TextTertiary,
            modifier = Modifier.size(17.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (post.repostsCount > 0) "${post.repostsCount}" else "",
            color = if (post.isReposted) HoggarColorTokens.SuccessOasis else HoggarColorTokens.TextTertiary,
            fontSize = 11.sp,
          )
        }

        // 3. Like
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.clickable(onClick = onLikeClick),
        ) {
          Icon(
            imageVector = if (post.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            contentDescription = "Like",
            tint = if (post.isLiked) Color(0xFFFE2C55) else HoggarColorTokens.TextTertiary,
            modifier = Modifier.size(17.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (post.likesCount > 0) "${post.likesCount}" else "",
            color = if (post.isLiked) Color(0xFFFE2C55) else HoggarColorTokens.TextTertiary,
            fontSize = 11.sp,
          )
        }

        // 4. Bookmark
        IconButton(
          onClick = onBookmarkClick,
          modifier = Modifier.size(24.dp),
        ) {
          Icon(
            imageVector = if (post.isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
            contentDescription = "Bookmark",
            tint = if (post.isBookmarked) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextTertiary,
            modifier = Modifier.size(16.dp),
          )
        }

        // 5. Share
        IconButton(
          onClick = {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
              type = "text/plain"
              putExtra(Intent.EXTRA_SUBJECT, "منشور ${post.author.displayName} على الهڨار")
              putExtra(Intent.EXTRA_TEXT, "${post.author.displayName}: \"${post.contentText}\"\n\nعبر تطبيق الهڨار")
            }
            context.startActivity(Intent.createChooser(shareIntent, "مشاركة المنشور"))
          },
          modifier = Modifier.size(24.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Share,
            contentDescription = "Share",
            tint = HoggarColorTokens.TextTertiary,
            modifier = Modifier.size(15.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun PostImagesGrid(imageUrls: List<String>) {
  when (imageUrls.size) {
    1 -> {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(210.dp)
          .clip(RoundedCornerShape(12.dp))
          .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp)),
      ) {
        AsyncImage(
          model = imageUrls[0],
          contentDescription = "Post Image",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
      }
    }
    2 -> {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .height(160.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        imageUrls.forEach { url ->
          Box(
            modifier = Modifier
              .weight(1f)
              .fillMaxSize()
              .clip(RoundedCornerShape(12.dp))
              .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp)),
          ) {
            AsyncImage(
              model = url,
              contentDescription = "Post Image",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          }
        }
      }
    }
    else -> {
      // 3 or 4 images grid
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(120.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .fillMaxSize()
              .clip(RoundedCornerShape(12.dp))
              .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp)),
          ) {
            AsyncImage(
              model = imageUrls[0],
              contentDescription = "Post Image 1",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          }
          Box(
            modifier = Modifier
              .weight(1f)
              .fillMaxSize()
              .clip(RoundedCornerShape(12.dp))
              .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp)),
          ) {
            AsyncImage(
              model = imageUrls[1],
              contentDescription = "Post Image 2",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          }
        }
        if (imageUrls.size >= 3) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .height(120.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Box(
              modifier = Modifier
                .weight(1f)
                .fillMaxSize()
                .clip(RoundedCornerShape(12.dp))
                .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp)),
            ) {
              AsyncImage(
                model = imageUrls[2],
                contentDescription = "Post Image 3",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
              )
            }
            if (imageUrls.size >= 4) {
              Box(
                modifier = Modifier
                  .weight(1f)
                  .fillMaxSize()
                  .clip(RoundedCornerShape(12.dp))
                  .border(0.5.dp, HoggarColorTokens.BorderSubtle, RoundedCornerShape(12.dp)),
              ) {
                AsyncImage(
                  model = imageUrls[3],
                  contentDescription = "Post Image 4",
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.fillMaxSize(),
                )
              }
            }
          }
        }
      }
    }
  }
}
