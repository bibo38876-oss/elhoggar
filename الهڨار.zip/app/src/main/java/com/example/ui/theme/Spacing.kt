package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Standard 8dp grid spacing system with ergonomic micro-steps
 */
@Immutable
data class HoggarSpacing(
  val none: Dp = 0.dp,
  val xxs: Dp = 2.dp,
  val xs: Dp = 4.dp,
  val sm: Dp = 8.dp,
  val md: Dp = 12.dp,
  val lg: Dp = 16.dp,
  val xl: Dp = 20.dp,
  val xxl: Dp = 24.dp,
  val xxxl: Dp = 32.dp,
  val huge: Dp = 40.dp,
  val massive: Dp = 48.dp,
  val giant: Dp = 64.dp,
)

val LocalHoggarSpacing = staticCompositionLocalOf { HoggarSpacing() }
