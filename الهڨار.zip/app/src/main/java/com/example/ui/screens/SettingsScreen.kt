package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DataUsage
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.auth.AuthRepository
import com.example.localization.AppLanguage
import com.example.localization.LocalLocalization
import com.example.localization.hoggarString
import com.example.ui.components.HoggarButton
import com.example.ui.components.HoggarButtonVariant
import com.example.ui.theme.HoggarColorTokens
import com.example.user.UserProfile
import com.example.user.UserRole
import androidx.compose.material.icons.filled.Shield

@Composable
fun SettingsScreen(
  currentUserProfile: UserProfile?,
  authRepository: AuthRepository,
  onBack: () -> Unit,
  onEditProfile: (UserProfile) -> Unit,
  onLogout: () -> Unit,
  onDeleteAccountConfirmed: (String) -> Unit,
  onOpenDesignSystem: (() -> Unit)? = null,
  onOpenAdmin: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val localization = LocalLocalization.current
  val isArabic = localization.currentLanguage == AppLanguage.Arabic

  // Privacy toggles
  var isPrivateAccount by remember { mutableStateOf(false) }
  val defaultComments = hoggarString("comments_everyone")
  var commentsPermission by remember(defaultComments) { mutableStateOf(defaultComments) }

  // Notifications toggles
  var pushNotificationsEnabled by remember { mutableStateOf(true) }
  var likesNotificationsEnabled by remember { mutableStateOf(true) }
  var commentsNotificationsEnabled by remember { mutableStateOf(true) }

  // Video & Data toggles
  var isDataSaverEnabled by remember { mutableStateOf(false) }
  var cacheClearedMessage by remember { mutableStateOf(false) }

  // Dialog states
  var showLanguageDialog by remember { mutableStateOf(false) }
  var showDeleteAccountDialog by remember { mutableStateOf(false) }
  var deleteConfirmationText by remember { mutableStateOf("") }
  var showChangePasswordDialog by remember { mutableStateOf(false) }
  var newPasswordInput by remember { mutableStateOf("") }
  var passwordChangedSuccess by remember { mutableStateOf(false) }
  var showAboutSheet by remember { mutableStateOf(false) }
  var aboutInitialTab by remember { mutableStateOf(LegalTab.About) }
  var showBlockedAccountsDialog by remember { mutableStateOf(false) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .statusBarsPadding()
      .testTag("settings_screen"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState()),
    ) {
      // Top App Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(onClick = onBack) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = HoggarColorTokens.TextPrimary,
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = hoggarString("settings"),
          color = HoggarColorTokens.TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
        )
      }

      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {

        // 1. Account Section
        SettingsSectionHeader(title = hoggarString("account"))
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.BasaltSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(vertical = 4.dp)) {
            if (currentUserProfile != null) {
              SettingsActionItem(
                icon = Icons.Filled.Person,
                title = currentUserProfile.displayName,
                subtitle = "@${currentUserProfile.username}",
                onClick = { onEditProfile(currentUserProfile) },
              )
              SettingsDivider()
              SettingsActionItem(
                icon = Icons.Filled.Lock,
                title = hoggarString("change_password"),
                onClick = { showChangePasswordDialog = true },
              )
              SettingsDivider()
            }
            SettingsActionItem(
              icon = Icons.Filled.Logout,
              title = hoggarString("logout"),
              titleColor = HoggarColorTokens.TextSecondary,
              onClick = onLogout,
            )
            if (currentUserProfile != null) {
              SettingsDivider()
              SettingsActionItem(
                icon = Icons.Filled.DeleteForever,
                title = hoggarString("account_deletion"),
                titleColor = HoggarColorTokens.ErrorCoral,
                onClick = { showDeleteAccountDialog = true },
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2. Language & Localization
        SettingsSectionHeader(title = hoggarString("language"))
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.BasaltSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(vertical = 4.dp)) {
            SettingsActionItem(
              icon = Icons.Filled.Language,
              title = hoggarString("language"),
              subtitle = localization.currentLanguage.displayName,
              onClick = { showLanguageDialog = true },
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 3. Privacy & Security
        SettingsSectionHeader(title = hoggarString("privacy"))
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.BasaltSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(vertical = 4.dp)) {
            SettingsToggleItem(
              icon = Icons.Filled.Security,
              title = hoggarString("private_account"),
              subtitle = hoggarString("private_account_desc"),
              checked = isPrivateAccount,
              onCheckedChange = { isPrivateAccount = it },
            )
            SettingsDivider()
            SettingsActionItem(
              icon = Icons.Filled.Block,
              title = hoggarString("blocked_accounts"),
              onClick = { showBlockedAccountsDialog = true },
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 4. Notifications
        SettingsSectionHeader(title = hoggarString("notifications"))
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.BasaltSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(vertical = 4.dp)) {
            SettingsToggleItem(
              icon = Icons.Filled.Notifications,
              title = hoggarString("push_notifications"),
              checked = pushNotificationsEnabled,
              onCheckedChange = { pushNotificationsEnabled = it },
            )
            SettingsDivider()
            SettingsToggleItem(
              icon = Icons.Filled.Notifications,
              title = hoggarString("likes"),
              checked = likesNotificationsEnabled,
              onCheckedChange = { likesNotificationsEnabled = it },
            )
            SettingsDivider()
            SettingsToggleItem(
              icon = Icons.Filled.Notifications,
              title = hoggarString("comments"),
              checked = commentsNotificationsEnabled,
              onCheckedChange = { commentsNotificationsEnabled = it },
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 5. Video & Data Management
        SettingsSectionHeader(title = if (isArabic) "الفيديو واستهلاك البيانات" else "Video & Data")
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.BasaltSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(vertical = 4.dp)) {
            SettingsToggleItem(
              icon = Icons.Filled.DataUsage,
              title = hoggarString("data_saver"),
              subtitle = hoggarString("data_saver_desc"),
              checked = isDataSaverEnabled,
              onCheckedChange = { isDataSaverEnabled = it },
            )
            SettingsDivider()
            SettingsActionItem(
              icon = Icons.Filled.CleaningServices,
              title = if (isArabic) "تنظيف الذاكرة المؤقتة (Cache)" else "Clear Cache",
              subtitle = if (cacheClearedMessage) (if (isArabic) "تم تفريغ الذاكرة بنجاح" else "Cache cleared successfully") else "32.4 MB",
              onClick = { cacheClearedMessage = true },
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 6. About, Policies, & Support
        SettingsSectionHeader(title = if (isArabic) "المعلومات والدعم" else "About & Support")
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = HoggarColorTokens.BasaltSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(vertical = 4.dp)) {
            SettingsActionItem(
              icon = Icons.Filled.Info,
              title = hoggarString("about"),
              subtitle = "${hoggarString("version")} 1.0.0",
              onClick = {
                aboutInitialTab = LegalTab.About
                showAboutSheet = true
              },
            )
            SettingsDivider()
            SettingsActionItem(
              icon = Icons.Filled.Policy,
              title = hoggarString("privacy_policy"),
              onClick = {
                aboutInitialTab = LegalTab.Privacy
                showAboutSheet = true
              },
            )
            SettingsDivider()
            SettingsActionItem(
              icon = Icons.Filled.Description,
              title = hoggarString("terms_of_service"),
              onClick = {
                aboutInitialTab = LegalTab.Terms
                showAboutSheet = true
              },
            )
            SettingsDivider()
            SettingsActionItem(
              icon = Icons.Filled.Policy,
              title = hoggarString("community_guidelines"),
              onClick = {
                aboutInitialTab = LegalTab.Community
                showAboutSheet = true
              },
            )
            SettingsDivider()
            SettingsActionItem(
              icon = Icons.Filled.SupportAgent,
              title = hoggarString("support"),
              onClick = {
                aboutInitialTab = LegalTab.Support
                showAboutSheet = true
              },
            )
            if (onOpenDesignSystem != null) {
              SettingsDivider()
              SettingsActionItem(
                icon = Icons.Filled.Info,
                title = if (isArabic) "دليل الهوية ونظام التصميم" else "Design System Specifications",
                onClick = onOpenDesignSystem,
              )
            }
            if (onOpenAdmin != null && (currentUserProfile?.role == UserRole.Admin || currentUserProfile?.username == "tassili_explorer" || currentUserProfile?.username == "admin")) {
              SettingsDivider()
              SettingsActionItem(
                icon = Icons.Filled.Shield,
                title = if (isArabic) "مركز الإشراف والأمان (Admin Hub)" else "Admin & Moderation Hub",
                titleColor = HoggarColorTokens.InteractiveAmber,
                onClick = onOpenAdmin,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(32.dp))
      }
    }

    // Language Selector Dialog
    if (showLanguageDialog) {
      AlertDialog(
        onDismissRequest = { showLanguageDialog = false },
        containerColor = HoggarColorTokens.BasaltSurface,
        title = {
          Text(
            text = hoggarString("select_language"),
            color = HoggarColorTokens.TextPrimary,
            fontWeight = FontWeight.Bold,
          )
        },
        text = {
          Column {
            AppLanguage.entries.forEach { lang ->
              val isSelected = lang == localization.currentLanguage
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSelected) HoggarColorTokens.SlateContainer else Color.Transparent)
                  .clickable {
                    localization.setLanguage(context, lang)
                    showLanguageDialog = false
                  }
                  .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = "${lang.displayName} (${lang.nativeName})",
                  color = if (isSelected) HoggarColorTokens.InteractiveAmber else HoggarColorTokens.TextPrimary,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                )
                if (isSelected) {
                  Text("✓", color = HoggarColorTokens.InteractiveAmber, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        },
        confirmButton = {
          TextButton(onClick = { showLanguageDialog = false }) {
            Text(hoggarString("cancel"), color = HoggarColorTokens.TextSecondary)
          }
        },
      )
    }

    // Account Deletion Dialog with multi-step confirmation
    if (showDeleteAccountDialog && currentUserProfile != null) {
      AlertDialog(
        onDismissRequest = { showDeleteAccountDialog = false },
        containerColor = HoggarColorTokens.BasaltSurface,
        title = {
          Text(
            text = hoggarString("account_deletion"),
            color = HoggarColorTokens.ErrorCoral,
            fontWeight = FontWeight.Bold,
          )
        },
        text = {
          Column {
            Text(
              text = hoggarString("account_deletion_warning"),
              color = HoggarColorTokens.TextSecondary,
              fontSize = 13.sp,
              lineHeight = 20.sp,
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = if (isArabic) "اكتب \"حذف\" لتأكيد العملية:" else "Type \"DELETE\" to confirm:",
              color = HoggarColorTokens.TextPrimary,
              fontSize = 12.sp,
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
              value = deleteConfirmationText,
              onValueChange = { deleteConfirmationText = it },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true,
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = HoggarColorTokens.ErrorCoral,
                unfocusedBorderColor = HoggarColorTokens.SlateContainer,
                focusedTextColor = HoggarColorTokens.TextPrimary,
                unfocusedTextColor = HoggarColorTokens.TextPrimary,
              ),
            )
          }
        },
        confirmButton = {
          val canDelete = deleteConfirmationText.trim().equals("حذف", ignoreCase = true) ||
              deleteConfirmationText.trim().equals("DELETE", ignoreCase = true)
          HoggarButton(
            text = hoggarString("delete"),
            variant = HoggarButtonVariant.PrimaryCopper,
            enabled = canDelete,
            onClick = {
              showDeleteAccountDialog = false
              onDeleteAccountConfirmed(currentUserProfile.id)
            },
          )
        },
        dismissButton = {
          TextButton(onClick = { showDeleteAccountDialog = false }) {
            Text(hoggarString("cancel"), color = HoggarColorTokens.TextSecondary)
          }
        },
      )
    }

    // Change Password Dialog
    if (showChangePasswordDialog) {
      AlertDialog(
        onDismissRequest = { showChangePasswordDialog = false },
        containerColor = HoggarColorTokens.BasaltSurface,
        title = {
          Text(
            text = hoggarString("change_password"),
            color = HoggarColorTokens.TextPrimary,
            fontWeight = FontWeight.Bold,
          )
        },
        text = {
          Column {
            if (passwordChangedSuccess) {
              Text(
                text = if (isArabic) "تم تحديث كلمة المرور بنجاح!" else "Password updated successfully!",
                color = HoggarColorTokens.InteractiveAmber,
                fontWeight = FontWeight.Bold,
              )
            } else {
              OutlinedTextField(
                value = newPasswordInput,
                onValueChange = { newPasswordInput = it },
                label = { Text(if (isArabic) "كلمة المرور الجديدة" else "New Password") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = HoggarColorTokens.InteractiveAmber,
                  unfocusedBorderColor = HoggarColorTokens.SlateContainer,
                  focusedTextColor = HoggarColorTokens.TextPrimary,
                  unfocusedTextColor = HoggarColorTokens.TextPrimary,
                ),
              )
            }
          }
        },
        confirmButton = {
          if (!passwordChangedSuccess) {
            HoggarButton(
              text = if (isArabic) "حفظ" else "Save",
              enabled = newPasswordInput.length >= 6,
              onClick = { passwordChangedSuccess = true },
            )
          } else {
            HoggarButton(
              text = if (isArabic) "إغلاق" else "Close",
              onClick = {
                showChangePasswordDialog = false
                passwordChangedSuccess = false
                newPasswordInput = ""
              },
            )
          }
        },
        dismissButton = {
          if (!passwordChangedSuccess) {
            TextButton(onClick = { showChangePasswordDialog = false }) {
              Text(hoggarString("cancel"), color = HoggarColorTokens.TextSecondary)
            }
          }
        },
      )
    }

    // Blocked Accounts Dialog
    if (showBlockedAccountsDialog) {
      AlertDialog(
        onDismissRequest = { showBlockedAccountsDialog = false },
        containerColor = HoggarColorTokens.BasaltSurface,
        title = {
          Text(
            text = hoggarString("blocked_accounts"),
            color = HoggarColorTokens.TextPrimary,
            fontWeight = FontWeight.Bold,
          )
        },
        text = {
          Text(
            text = hoggarString("no_blocked_accounts"),
            color = HoggarColorTokens.TextSecondary,
            fontSize = 13.sp,
          )
        },
        confirmButton = {
          TextButton(onClick = { showBlockedAccountsDialog = false }) {
            Text(if (isArabic) "حسناً" else "OK", color = HoggarColorTokens.InteractiveAmber)
          }
        },
      )
    }

    // Legal & Support Sheet
    if (showAboutSheet) {
      AboutAndLegalSheet(
        initialTab = aboutInitialTab,
        onDismiss = { showAboutSheet = false },
      )
    }
  }
}

@Composable
private fun SettingsSectionHeader(title: String) {
  Text(
    text = title,
    color = HoggarColorTokens.InteractiveAmber,
    fontSize = 13.sp,
    fontWeight = FontWeight.Bold,
    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
  )
}

@Composable
private fun SettingsActionItem(
  icon: ImageVector,
  title: String,
  subtitle: String? = null,
  titleColor: Color = HoggarColorTokens.TextPrimary,
  onClick: () -> Unit,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(horizontal = 16.dp, vertical = 14.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
      Icon(imageVector = icon, contentDescription = null, tint = titleColor, modifier = Modifier.size(22.dp))
      Spacer(modifier = Modifier.width(14.dp))
      Column {
        Text(text = title, color = titleColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        if (subtitle != null) {
          Text(text = subtitle, color = HoggarColorTokens.TextTertiary, fontSize = 12.sp)
        }
      }
    }
    Icon(
      imageVector = Icons.Filled.ChevronRight,
      contentDescription = null,
      tint = HoggarColorTokens.TextTertiary,
      modifier = Modifier.size(18.dp),
    )
  }
}

@Composable
private fun SettingsToggleItem(
  icon: ImageVector,
  title: String,
  subtitle: String? = null,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
      Icon(imageVector = icon, contentDescription = null, tint = HoggarColorTokens.TextPrimary, modifier = Modifier.size(22.dp))
      Spacer(modifier = Modifier.width(14.dp))
      Column {
        Text(text = title, color = HoggarColorTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        if (subtitle != null) {
          Text(text = subtitle, color = HoggarColorTokens.TextTertiary, fontSize = 11.sp, lineHeight = 16.sp)
        }
      }
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(
        checkedThumbColor = HoggarColorTokens.ObsidianBase,
        checkedTrackColor = HoggarColorTokens.InteractiveAmber,
        uncheckedThumbColor = HoggarColorTokens.TextSecondary,
        uncheckedTrackColor = HoggarColorTokens.SlateContainer,
      ),
    )
  }
}

@Composable
private fun SettingsDivider() {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .height(1.dp)
      .padding(horizontal = 16.dp)
      .background(HoggarColorTokens.SlateContainer.copy(alpha = 0.5f)),
  )
}
