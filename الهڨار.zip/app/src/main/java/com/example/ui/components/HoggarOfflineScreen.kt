package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HoggarColorTokens

@Composable
fun HoggarOfflineScreen(
  onRetry: () -> Unit,
  modifier: Modifier = Modifier,
  customMessage: String? = null,
) {
  Box(
    modifier = modifier
      .fillMaxSize()
      .background(HoggarColorTokens.ObsidianBase)
      .padding(24.dp)
      .testTag("hoggar_offline_screen"),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.widthIn(max = 420.dp),
    ) {
      // Hoggar Tuareg Symbol Emblem with Glow
      HoggarLogoMark(size = 80.dp, showGlow = true)

      Spacer(modifier = Modifier.height(20.dp))

      // Offline Icon Badge
      Box(
        modifier = Modifier
          .size(48.dp)
          .background(HoggarColorTokens.SlateContainer, shape = androidx.compose.foundation.shape.CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.WifiOff,
          contentDescription = "Offline",
          tint = HoggarColorTokens.InteractiveAmber,
          modifier = Modifier.size(24.dp),
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "لا يوجد اتصال بالإنترنت",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = customMessage
          ?: "يرجى التحقق من اتصالك بالشبكة للمتابعة والاستمتاع بمشاهدة مقاطع وتراث الهڨار.",
        color = HoggarColorTokens.TextSecondary,
        fontSize = 13.sp,
        lineHeight = 20.sp,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(24.dp))

      HoggarButton(
        text = "إعادة المحاولة",
        icon = Icons.Filled.Refresh,
        onClick = onRetry,
        variant = HoggarButtonVariant.PrimaryCopper,
        modifier = Modifier.height(48.dp).widthIn(min = 180.dp).testTag("btn_offline_retry"),
      )
    }
  }
}
