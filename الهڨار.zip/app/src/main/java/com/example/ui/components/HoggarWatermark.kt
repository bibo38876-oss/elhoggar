package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HoggarColorTokens

/**
 * Discrete Video Watermark
 * Positioned in the corner of exported or playing clips.
 * Symmetrical, subtle, non-intrusive.
 */
@Composable
fun HoggarWatermark(
  modifier: Modifier = Modifier,
  testTag: String = "hoggar_watermark",
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(Color(0x55000000))
      .padding(horizontal = 8.dp, vertical = 4.dp)
      .alpha(0.85f)
      .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
    ) {
      HoggarLogoMark(size = 14.dp)
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = "الهڨار",
        color = HoggarColorTokens.TextPrimary,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp,
      )
    }
  }
}

/**
 * Camera Creation Crest
 * Used in the center of the bottom navigation or camera recording screen.
 */
@Composable
fun HoggarCameraCrest(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  testTag: String = "hoggar_camera_crest",
) {
  Box(
    modifier = modifier
      .size(52.dp)
      .clip(RoundedCornerShape(14.dp))
      .background(HoggarColorTokens.CopperPrimary)
      .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    HoggarLogoMark(size = 28.dp)
  }
}
