package com.example.security.repository

import com.example.data.repository.VideoRepository
import com.example.interaction.model.ReportReason
import com.example.interaction.model.ReportTargetType
import com.example.model.VideoItem
import com.example.model.VideoModerationStatus
import com.example.security.model.AccountStatus
import com.example.security.model.AuditActionType
import com.example.security.model.AuditLogEntry
import com.example.security.model.EnhancedReportItem
import com.example.security.model.PlatformMetrics
import com.example.security.model.ReportStatus
import com.example.security.model.UserRole
import com.example.security.service.SecurityManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

data class AdminUserEntry(
  val id: String,
  val username: String,
  val displayName: String,
  val role: UserRole,
  val status: AccountStatus,
  val createdAtMs: Long,
  val videoCount: Int,
  val isVerified: Boolean = false,
)

interface AdminRepository {
  fun getReports(): Flow<List<EnhancedReportItem>>
  suspend fun submitReport(report: EnhancedReportItem): Result<String>
  suspend fun updateReportStatus(
    reportId: String,
    newStatus: ReportStatus,
    reviewerId: String,
    reviewerName: String,
    actorRole: UserRole,
    resolutionNote: String,
  ): Result<Unit>

  fun getVideosForModeration(): Flow<List<VideoItem>>
  suspend fun moderateVideo(
    videoId: String,
    newStatus: VideoModerationStatus,
    actorId: String,
    actorName: String,
    actorRole: UserRole,
    reason: String,
  ): Result<Unit>

  suspend fun deleteVideoByAdmin(
    videoId: String,
    actorId: String,
    actorName: String,
    actorRole: UserRole,
    reason: String,
  ): Result<Unit>

  fun getUsers(): Flow<List<AdminUserEntry>>
  suspend fun updateUserStatus(
    targetUserId: String,
    newStatus: AccountStatus,
    actorId: String,
    actorName: String,
    actorRole: UserRole,
    reason: String,
  ): Result<Unit>

  fun getAuditLogs(): Flow<List<AuditLogEntry>>
  fun getPlatformMetrics(): Flow<PlatformMetrics>
}

class InMemoryAdminRepository(
  private val videoRepository: VideoRepository,
  private val securityManager: SecurityManager,
) : AdminRepository {

  // Centralized Reports Store
  private val reportsState = MutableStateFlow<List<EnhancedReportItem>>(
    listOf(
      EnhancedReportItem(
        reportId = "rep_001",
        reporterId = "user_me",
        targetId = "hoggar_004",
        targetType = ReportTargetType.Video,
        reason = ReportReason.InappropriateContent,
        description = "ملاحظة بخصوص جودة الصوت ومطابقة الإرشادات العامة",
        status = ReportStatus.Pending,
        createdAt = System.currentTimeMillis() - 3600_000L * 2,
      ),
      EnhancedReportItem(
        reportId = "rep_002",
        reporterId = "creator_03",
        targetId = "creator_02",
        targetType = ReportTargetType.User,
        reason = ReportReason.Impersonation,
        description = "حساب يستخدم اسم وصور مشابهة لأحد الحرفيين",
        status = ReportStatus.Reviewing,
        createdAt = System.currentTimeMillis() - 3600_000L * 5,
        reviewerId = "admin_super",
      ),
    ),
  )

  // Centralized Audit Log (Append-only)
  private val auditLogsState = MutableStateFlow<List<AuditLogEntry>>(
    listOf(
      AuditLogEntry(
        id = "audit_001",
        actorId = "admin_super",
        actorName = "المشرف العام",
        actorRole = UserRole.SuperAdmin,
        actionType = AuditActionType.SecurityAlert,
        targetId = "system",
        targetType = "System",
        reason = "تهيئة منظومة الإشراف والأمان لمنصة الهڨار",
        timestampMs = System.currentTimeMillis() - 3600_000L * 24,
      ),
    ),
  )

  // Users Directory in Admin Panel
  private val usersState = MutableStateFlow<List<AdminUserEntry>>(
    listOf(
      AdminUserEntry(
        id = "user_me",
        username = "hoggar_admin",
        displayName = "مدير المنصة",
        role = UserRole.SuperAdmin,
        status = AccountStatus.Active,
        createdAtMs = System.currentTimeMillis() - 3600_000L * 24 * 30,
        videoCount = 2,
        isVerified = true,
      ),
      AdminUserEntry(
        id = "creator_01",
        username = "hoggar_explorer",
        displayName = "مستكشف الهڨار",
        role = UserRole.RegularUser,
        status = AccountStatus.Active,
        createdAtMs = System.currentTimeMillis() - 3600_000L * 24 * 25,
        videoCount = 1,
        isVerified = true,
      ),
      AdminUserEntry(
        id = "creator_02",
        username = "tamanrasset_crafts",
        displayName = "حِرَف تمنراست",
        role = UserRole.RegularUser,
        status = AccountStatus.Active,
        createdAtMs = System.currentTimeMillis() - 3600_000L * 24 * 18,
        videoCount = 1,
        isVerified = true,
      ),
      AdminUserEntry(
        id = "creator_03",
        username = "sahara_rhythms",
        displayName = "إيقاعات الصحراء",
        role = UserRole.RegularUser,
        status = AccountStatus.Active,
        createdAtMs = System.currentTimeMillis() - 3600_000L * 24 * 12,
        videoCount = 1,
        isVerified = false,
      ),
      AdminUserEntry(
        id = "creator_04",
        username = "desert_tea",
        displayName = "كأس شاي صحراوي",
        role = UserRole.RegularUser,
        status = AccountStatus.Restricted,
        createdAtMs = System.currentTimeMillis() - 3600_000L * 24 * 5,
        videoCount = 1,
        isVerified = false,
      ),
    ),
  )

  override fun getReports(): Flow<List<EnhancedReportItem>> = reportsState.asStateFlow()

  override suspend fun submitReport(report: EnhancedReportItem): Result<String> {
    // 1. Rate Limit check
    val rateCheck = securityManager.checkRateLimit("report", report.reporterId)
    if (!rateCheck.isAllowed) {
      return Result.failure(IllegalStateException(rateCheck.message))
    }

    // 2. Append report to central queue
    val updated = reportsState.value + report
    reportsState.value = updated
    return Result.success("تم إرسال البلاغ بنجاح إلى فريق الإشراف والأمان.")
  }

  override suspend fun updateReportStatus(
    reportId: String,
    newStatus: ReportStatus,
    reviewerId: String,
    reviewerName: String,
    actorRole: UserRole,
    resolutionNote: String,
  ): Result<Unit> {
    if (!securityManager.hasPermission(actorRole, AuditActionType.ReportStatusUpdated)) {
      return Result.failure(SecurityException("غير مصرح لك باتخاذ إجراء على هذا البلاغ."))
    }

    val current = reportsState.value
    val targetReport = current.firstOrNull { it.reportId == reportId }
      ?: return Result.failure(IllegalArgumentException("البلاغ غير موجود"))

    val updatedList = current.map { item ->
      if (item.reportId == reportId) {
        item.copy(
          status = newStatus,
          reviewedAt = System.currentTimeMillis(),
          reviewerId = reviewerId,
          resolutionNote = resolutionNote,
        )
      } else {
        item
      }
    }
    reportsState.value = updatedList

    // Append to immutable audit log
    appendAuditLog(
      actorId = reviewerId,
      actorName = reviewerName,
      actorRole = actorRole,
      actionType = AuditActionType.ReportStatusUpdated,
      targetId = reportId,
      targetType = targetReport.targetType.name,
      reason = "تحديث حالة البلاغ إلى ${newStatus.labelAr}: $resolutionNote",
    )

    return Result.success(Unit)
  }

  override fun getVideosForModeration(): Flow<List<VideoItem>> {
    return videoRepository.getFeedVideos().map { it.getOrDefault(emptyList()) }
  }

  override suspend fun moderateVideo(
    videoId: String,
    newStatus: VideoModerationStatus,
    actorId: String,
    actorName: String,
    actorRole: UserRole,
    reason: String,
  ): Result<Unit> {
    val auditAction = when (newStatus) {
      VideoModerationStatus.Approved -> AuditActionType.VideoApproved
      VideoModerationStatus.Rejected -> AuditActionType.VideoRejected
      VideoModerationStatus.Restricted -> AuditActionType.VideoRestricted
      VideoModerationStatus.Pending -> AuditActionType.ReportStatusUpdated
    }

    if (!securityManager.hasPermission(actorRole, auditAction)) {
      return Result.failure(SecurityException("صلاحيات دورك لا تسمح بهذا الإجراء الإشرافي."))
    }

    // Append to immutable audit log
    appendAuditLog(
      actorId = actorId,
      actorName = actorName,
      actorRole = actorRole,
      actionType = auditAction,
      targetId = videoId,
      targetType = "Video",
      reason = reason,
    )

    return Result.success(Unit)
  }

  override suspend fun deleteVideoByAdmin(
    videoId: String,
    actorId: String,
    actorName: String,
    actorRole: UserRole,
    reason: String,
  ): Result<Unit> {
    if (actorRole != UserRole.SuperAdmin) {
      return Result.failure(SecurityException("حذف الفيديو نهائياً يتطلب صلاحية مشرف عام (SuperAdmin)."))
    }

    videoRepository.deleteVideo(videoId, actorId)

    appendAuditLog(
      actorId = actorId,
      actorName = actorName,
      actorRole = actorRole,
      actionType = AuditActionType.VideoDeleted,
      targetId = videoId,
      targetType = "Video",
      reason = reason,
    )

    return Result.success(Unit)
  }

  override fun getUsers(): Flow<List<AdminUserEntry>> = usersState.asStateFlow()

  override suspend fun updateUserStatus(
    targetUserId: String,
    newStatus: AccountStatus,
    actorId: String,
    actorName: String,
    actorRole: UserRole,
    reason: String,
  ): Result<Unit> {
    if (actorRole != UserRole.SuperAdmin) {
      return Result.failure(SecurityException("تغيير حالة الحساب (حظر/تقييد) يتطلب صلاحية مشرف عام (SuperAdmin)."))
    }

    val currentUsers = usersState.value
    val updated = currentUsers.map { user ->
      if (user.id == targetUserId) {
        user.copy(status = newStatus)
      } else {
        user
      }
    }
    usersState.value = updated

    val action = when (newStatus) {
      AccountStatus.Active -> AuditActionType.UserUnrestricted
      AccountStatus.Restricted -> AuditActionType.UserRestricted
      AccountStatus.Banned -> AuditActionType.UserBanned
    }

    appendAuditLog(
      actorId = actorId,
      actorName = actorName,
      actorRole = actorRole,
      actionType = action,
      targetId = targetUserId,
      targetType = "User",
      reason = reason,
    )

    return Result.success(Unit)
  }

  override fun getAuditLogs(): Flow<List<AuditLogEntry>> = auditLogsState.asStateFlow()

  override fun getPlatformMetrics(): Flow<PlatformMetrics> {
    return videoRepository.getFeedVideos().map { result ->
      val videos = result.getOrDefault(emptyList())
      val users = usersState.value
      val reports = reportsState.value

      PlatformMetrics(
        totalUsers = users.size.toLong(),
        activeUsers = users.count { it.status == AccountStatus.Active }.toLong(),
        totalVideos = videos.size.toLong(),
        totalViews = videos.sumOf { it.stats.viewsCount },
        pendingReports = reports.count { it.status == ReportStatus.Pending }.toLong(),
        pendingModeration = videos.count { it.moderationStatus == VideoModerationStatus.Pending }.toLong(),
        restrictedUsers = users.count { it.status == AccountStatus.Restricted || it.status == AccountStatus.Banned }.toLong(),
      )
    }
  }

  private fun appendAuditLog(
    actorId: String,
    actorName: String,
    actorRole: UserRole,
    actionType: AuditActionType,
    targetId: String,
    targetType: String,
    reason: String,
  ) {
    val entry = AuditLogEntry(
      id = "audit_" + UUID.randomUUID().toString().take(8),
      actorId = actorId,
      actorName = actorName,
      actorRole = actorRole,
      actionType = actionType,
      targetId = targetId,
      targetType = targetType,
      reason = reason,
      timestampMs = System.currentTimeMillis(),
    )
    auditLogsState.value = listOf(entry) + auditLogsState.value
  }
}
