package com.example.security.model

import com.example.interaction.model.ReportReason
import com.example.interaction.model.ReportTargetType

enum class UserRole(val labelAr: String) {
  SuperAdmin("مشرف عام"),
  Moderator("مراقب محتوى"),
  Support("فريق الدعم"),
  RegularUser("مستخدم عادي"),
}

enum class AccountStatus(val labelAr: String) {
  Active("نشط"),
  Restricted("مقيد النشر والتفاعل"),
  Banned("محظور نهائياً"),
}

enum class ReportStatus(val labelAr: String) {
  Pending("قيد الانتظار"),
  Reviewing("قيد المراجعة"),
  Resolved("تم الإجراء"),
  Dismissed("تم الحفظ / لا مخالفة"),
}

enum class AuditActionType(val labelAr: String) {
  VideoApproved("اعتماد فيديو للعامة"),
  VideoRejected("رفض فيديو مخالف"),
  VideoRestricted("تقييد وصول فيديو"),
  VideoDeleted("حذف فيديو"),
  CommentDeleted("حذف تعليق مخالف"),
  UserRestricted("تقييد حساب مستخدم"),
  UserBanned("حظر حساب مستخدم"),
  UserUnrestricted("رفع التقييد عن حساب"),
  ReportStatusUpdated("تحديث حالة بلاغ"),
  SecurityAlert("تنبيه أمني للنظام"),
}

data class AuditLogEntry(
  val id: String,
  val actorId: String,
  val actorName: String,
  val actorRole: UserRole,
  val actionType: AuditActionType,
  val targetId: String,
  val targetType: String,
  val reason: String = "",
  val timestampMs: Long = System.currentTimeMillis(),
)

data class EnhancedReportItem(
  val reportId: String,
  val reporterId: String,
  val targetId: String,
  val targetType: ReportTargetType,
  val reason: ReportReason,
  val description: String = "",
  val status: ReportStatus = ReportStatus.Pending,
  val createdAt: Long = System.currentTimeMillis(),
  val reviewedAt: Long? = null,
  val reviewerId: String? = null,
  val resolutionNote: String? = null,
)

data class SecureSession(
  val token: String,
  val userId: String,
  val createdAt: Long = System.currentTimeMillis(),
  val expiresAt: Long = System.currentTimeMillis() + (7 * 24 * 60 * 60 * 1000L), // 7 days
  val isValid: Boolean = true,
)

data class RateLimitResult(
  val isAllowed: Boolean,
  val retryAfterSeconds: Long = 0L,
  val message: String = "",
)

data class PlatformMetrics(
  val totalUsers: Long = 0L,
  val activeUsers: Long = 0L,
  val totalVideos: Long = 0L,
  val totalViews: Long = 0L,
  val pendingReports: Long = 0L,
  val pendingModeration: Long = 0L,
  val restrictedUsers: Long = 0L,
)

data class UploadValidationResult(
  val isValid: Boolean,
  val errorMessage: String? = null,
  val secureStorageId: String = "",
  val sanitizedFileName: String = "",
)
