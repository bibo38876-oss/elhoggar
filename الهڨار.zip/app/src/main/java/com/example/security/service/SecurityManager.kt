package com.example.security.service

import com.example.security.model.AuditActionType
import com.example.security.model.RateLimitResult
import com.example.security.model.UploadValidationResult
import com.example.security.model.UserRole
import java.security.MessageDigest
import java.util.UUID

class SecurityManager {

  // User-to-User block relationships: BlockerId -> Set of BlockedUserIds
  private val userBlockMap = mutableMapOf<String, MutableSet<String>>()

  // Rate Limiting records: "action:userId" -> List of timestampsMs
  private val rateLimitHistory = mutableMapOf<String, MutableList<Long>>()

  // Configuration for limits
  companion object {
    private const val MAX_LIKES_PER_MINUTE = 25
    private const val MAX_COMMENTS_PER_MINUTE = 8
    private const val MAX_REPORTS_PER_10_MINUTES = 5
    private const val MAX_UPLOADS_PER_HOUR = 6
    private const val MAX_VIDEO_SIZE_BYTES = 50 * 1024 * 1024L // 50MB
    private const val MAX_VIDEO_DURATION_SECONDS = 60
  }

  /**
   * Enforces Ownership Verification on the server.
   * Prevents a user from modifying or deleting content owned by another user.
   */
  fun verifyOwnership(requestingUserId: String, contentOwnerId: String, role: UserRole): Boolean {
    if (role == UserRole.SuperAdmin || role == UserRole.Moderator) {
      return true // Administrative override
    }
    return requestingUserId == contentOwnerId
  }

  /**
   * Role-Based Access Control (RBAC) permission check.
   */
  fun hasPermission(role: UserRole, action: AuditActionType): Boolean {
    return when (role) {
      UserRole.SuperAdmin -> true
      UserRole.Moderator -> when (action) {
        AuditActionType.VideoApproved,
        AuditActionType.VideoRejected,
        AuditActionType.VideoRestricted,
        AuditActionType.CommentDeleted,
        AuditActionType.ReportStatusUpdated -> true
        else -> false
      }
      UserRole.Support -> when (action) {
        AuditActionType.ReportStatusUpdated -> true
        else -> false
      }
      UserRole.RegularUser -> false
    }
  }

  /**
   * Anti-Spam Rate Limiting engine.
   */
  @Synchronized
  fun checkRateLimit(action: String, userId: String): RateLimitResult {
    val key = "$action:$userId"
    val now = System.currentTimeMillis()
    val history = rateLimitHistory.getOrPut(key) { mutableListOf() }

    val (windowMs, maxCount) = when (action) {
      "like" -> Pair(60_000L, MAX_LIKES_PER_MINUTE)
      "comment" -> Pair(60_000L, MAX_COMMENTS_PER_MINUTE)
      "report" -> Pair(600_000L, MAX_REPORTS_PER_10_MINUTES)
      "upload" -> Pair(3_600_000L, MAX_UPLOADS_PER_HOUR)
      else -> Pair(60_000L, 30)
    }

    // Prune expired entries
    history.removeAll { now - it > windowMs }

    if (history.size >= maxCount) {
      val oldestEntry = history.firstOrNull() ?: now
      val remainingSeconds = (((oldestEntry + windowMs) - now) / 1000).coerceAtLeast(1)
      return RateLimitResult(
        isAllowed = false,
        retryAfterSeconds = remainingSeconds,
        message = "تم تجاوز الحد المسموح لهذه العملية. يرجى المحاولة بعد $remainingSeconds ثانية.",
      )
    }

    history.add(now)
    return RateLimitResult(isAllowed = true)
  }

  /**
   * Validates file upload security (real MIME type, size, duration).
   * Generates unguessable secure storage identifiers.
   */
  fun validateUploadFile(
    fileName: String,
    mimeType: String,
    fileSizeBytes: Long,
    durationSeconds: Int,
  ): UploadValidationResult {
    val sanitized = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")

    val isMimeValid = mimeType.startsWith("video/") ||
      sanitized.endsWith(".mp4", ignoreCase = true) ||
      sanitized.endsWith(".webm", ignoreCase = true)

    if (!isMimeValid) {
      return UploadValidationResult(
        isValid = false,
        errorMessage = "صيغة الملف غير مدعومة. المنصة تدعم ملفات الفيديو فقط (MP4/WebM).",
      )
    }

    if (fileSizeBytes > MAX_VIDEO_SIZE_BYTES) {
      return UploadValidationResult(
        isValid = false,
        errorMessage = "حجم الملف يتجاوز الحد المسموح به (50 ميجابايت كحد أقصى).",
      )
    }

    if (durationSeconds > MAX_VIDEO_DURATION_SECONDS) {
      return UploadValidationResult(
        isValid = false,
        errorMessage = "مدة الفيديو تتجاوز 60 ثانية المسموح بها في منصة الهڨار.",
      )
    }

    val secureStorageId = "sec_media_" + UUID.randomUUID().toString().replace("-", "")

    return UploadValidationResult(
      isValid = true,
      secureStorageId = secureStorageId,
      sanitizedFileName = sanitized,
    )
  }

  /**
   * User-to-User blocking.
   */
  @Synchronized
  fun blockUser(blockerId: String, targetUserId: String) {
    userBlockMap.getOrPut(blockerId) { mutableSetOf() }.add(targetUserId)
  }

  @Synchronized
  fun unblockUser(blockerId: String, targetUserId: String) {
    userBlockMap[blockerId]?.remove(targetUserId)
  }

  fun isUserBlocked(userA: String, userB: String): Boolean {
    val aBlockedB = userBlockMap[userA]?.contains(userB) ?: false
    val bBlockedA = userBlockMap[userB]?.contains(userA) ?: false
    return aBlockedB || bBlockedA
  }

  fun getBlockedUserIds(userId: String): Set<String> {
    return userBlockMap[userId] ?: emptySet()
  }

  /**
   * Simulates salted SHA-256 password hashing.
   */
  fun hashPassword(plainText: String, salt: String): String {
    val bytes = "$salt:$plainText:$salt".toByteArray()
    val md = MessageDigest.getInstance("SHA-256")
    val digest = md.digest(bytes)
    return digest.fold("") { str, it -> str + "%02x".format(it) }
  }
}
