package com.example.recommendation.model

import com.example.model.VideoItem

enum class NetworkQuality {
  High,
  Medium,
  Low,
  Offline,
}

enum class FeedItemReason(val labelAr: String) {
  Trending("رائج في الهڨار"),
  FollowedCreator("من صُنّاع تتابعهم"),
  TopicMatch("يناسب اهتماماتك"),
  SoundAffinity("مبني على الموسيقى المفضلة لديك"),
  ReplayAffinity("لأنك تعيد مشاهدة محتوى مشابه"),
  ViralVelocity("يتصدر التفاعل الآن في الهڨار"),
  SharedTasteCollaborative("أعجب مستخدمين يشاركونك نفس الذوق"),
  ExplorationNewCreator("مبدع صاعد يستحق الاكتشاف"),
}

data class FeedItem(
  val video: VideoItem,
  val score: Double = 1.0,
  val reason: FeedItemReason = FeedItemReason.Trending,
  val matchedTags: List<String> = emptyList(),
)

data class RecommendationContext(
  val preferredTags: List<String> = emptyList(),
  val networkQuality: NetworkQuality = NetworkQuality.High,
  val recentWatchedIds: List<String> = emptyList(),
  val followingCreatorIds: Set<String> = emptySet(),
  val preferredSoundIds: List<String> = emptyList(),
  val sessionDurationMinutes: Int = 0,
)

data class FeedRequest(
  val userId: String?,
  val cursor: String? = null,
  val pageSize: Int = 5,
  val context: RecommendationContext = RecommendationContext(),
)

data class FeedCursor(
  val nextCursor: String? = null,
  val hasMore: Boolean = false,
)

data class FeedPageResult(
  val items: List<FeedItem>,
  val cursor: FeedCursor,
)

data class WatchEvent(
  val videoId: String,
  val watchDurationMs: Long,
  val completionRate: Float,
  val isSkippedQuickly: Boolean,
  val isReplayed: Boolean,
  val videoTags: List<String> = emptyList(),
  val creatorId: String = "",
  val soundTitle: String = "",
  val timestampMs: Long = System.currentTimeMillis(),
)

data class TrendingSound(
  val id: String,
  val title: String,
  val artist: String,
  val usageCount: Long,
  val isTrending: Boolean = true,
  val coverUrl: String = "",
)

data class CreatorSuggestion(
  val creator: com.example.model.CreatorModel,
  val reasonAr: String,
  val matchScore: Float = 0.85f,
  val sharedTags: List<String> = emptyList(),
)

data class UserRecommendationProfile(
  val topicAffinities: Map<String, Float> = emptyMap(),
  val creatorAffinities: Map<String, Float> = emptyMap(),
  val soundAffinities: Map<String, Float> = emptyMap(),
  val totalVideosCompleted: Int = 0,
  val totalVideosReplayed: Int = 0,
  val totalVideosSkipped: Int = 0,
  val totalLikesGiven: Int = 0,
  val totalBookmarksSaved: Int = 0,
)

data class RelatedVideosResult(
  val targetVideoId: String,
  val similarVideos: List<VideoItem>,
  val moreFromCreator: List<VideoItem>,
)

data class HashtagDetail(
  val tag: String,
  val count: Long,
  val totalViews: Long,
  val description: String,
  val videos: List<VideoItem>,
)

data class SearchResult(
  val query: String,
  val matchedCreators: List<com.example.model.CreatorModel> = emptyList(),
  val matchedVideos: List<VideoItem> = emptyList(),
  val matchedHashtags: List<Pair<String, Long>> = emptyList(),
)
