package com.example.recommendation.repository

import com.example.data.repository.VideoRepository
import com.example.follow.FollowRepository
import com.example.model.CreatorModel
import com.example.model.VideoItem
import com.example.recommendation.engine.HoggarRecommendationEngine
import com.example.recommendation.engine.InteractionSignal
import com.example.recommendation.model.CreatorSuggestion
import com.example.recommendation.model.FeedCursor
import com.example.recommendation.model.FeedItem
import com.example.recommendation.model.FeedPageResult
import com.example.recommendation.model.FeedRequest
import com.example.recommendation.model.HashtagDetail
import com.example.recommendation.model.NetworkQuality
import com.example.recommendation.model.RelatedVideosResult
import com.example.recommendation.model.SearchResult
import com.example.recommendation.model.TrendingSound
import com.example.recommendation.model.UserRecommendationProfile
import com.example.recommendation.model.WatchEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow

interface RecommendationRepository {
  fun getFeedPage(request: FeedRequest): Flow<Result<FeedPageResult>>
  fun getFollowingFeed(currentUserId: String): Flow<List<VideoItem>>
  fun recordWatchEvent(event: WatchEvent)
  fun recordInteraction(videoId: String, type: InteractionSignal, tags: List<String>, creatorId: String)
  fun searchAll(query: String): Flow<SearchResult>
  fun getHashtagDetail(tag: String): Flow<HashtagDetail>
  fun getSuggestedCreators(): Flow<List<CreatorModel>>
  fun getSuggestedCreatorDetails(currentUserId: String = "user_me"): Flow<List<CreatorSuggestion>>
  fun getTrendingSounds(): Flow<List<TrendingSound>>
  fun getVideosBySound(soundTitle: String): Flow<List<VideoItem>>
  fun getRelatedVideos(targetVideoId: String): Flow<RelatedVideosResult?>
  fun getTrendingHashtags(): Flow<List<Pair<String, Long>>>
  fun setNetworkQuality(quality: NetworkQuality)
  fun getUserProfileSnapshot(): UserRecommendationProfile
  val networkQuality: StateFlow<NetworkQuality>
}

class InMemoryRecommendationRepository(
  private val videoRepository: VideoRepository,
  private val followRepository: FollowRepository? = null,
  val engine: HoggarRecommendationEngine = HoggarRecommendationEngine(),
) : RecommendationRepository {

  private val _networkQuality = MutableStateFlow(NetworkQuality.High)
  override val networkQuality: StateFlow<NetworkQuality> = _networkQuality.asStateFlow()

  override fun setNetworkQuality(quality: NetworkQuality) {
    _networkQuality.value = quality
  }

  override fun recordWatchEvent(event: WatchEvent) {
    // Process through the multi-objective dynamic recommendation engine
    // Engine automatically updates tag, creator, and sound affinities with time-decay
    val allVideos = videoRepository.getFeedVideos()
    // Trigger lightweight processing
    engine.processWatchEvent(event, null)
  }

  override fun recordInteraction(videoId: String, type: InteractionSignal, tags: List<String>, creatorId: String) {
    engine.recordInteraction(videoId, type, tags, creatorId)
  }

  override fun getFeedPage(request: FeedRequest): Flow<Result<FeedPageResult>> = flow {
    if (_networkQuality.value == NetworkQuality.Offline) {
      emit(Result.failure(IllegalStateException("لا يوجد اتصال بالإنترنت. يرجى التحقق من الشبكة وإعادة المحاولة.")))
      return@flow
    }

    val allVideos = videoRepository.getFeedVideos().first().getOrDefault(emptyList())

    if (allVideos.isEmpty()) {
      emit(Result.success(FeedPageResult(emptyList(), FeedCursor(null, false))))
      return@flow
    }

    // Populate followed creator IDs if not provided in context
    val activeFollowedIds = if (request.context.followingCreatorIds.isNotEmpty()) {
      request.context.followingCreatorIds
    } else {
      followRepository?.getFollowingIds(request.userId ?: "user_me") ?: emptySet()
    }

    val enrichedContext = request.context.copy(followingCreatorIds = activeFollowedIds)
    val enrichedRequest = request.copy(context = enrichedContext)

    // Execute multi-tier candidate generation and ranking via HoggarRecommendationEngine
    val result = engine.rankForYouFeed(allVideos, enrichedRequest)
    emit(Result.success(result))
  }

  override fun getFollowingFeed(currentUserId: String): Flow<List<VideoItem>> = flow {
    val allVideos = videoRepository.getFeedVideos().first().getOrDefault(emptyList())
    val followedIds = followRepository?.getFollowingIds(currentUserId) ?: emptySet()
    val ranked = engine.rankFollowingFeed(allVideos, followedIds)
    emit(ranked)
  }

  override fun getSuggestedCreators(): Flow<List<CreatorModel>> = flow {
    val allVideos = videoRepository.getFeedVideos().first().getOrDefault(emptyList())
    val suggestions = engine.getSuggestedCreators(allVideos, "user_me").map { it.creator }
    emit(suggestions)
  }

  override fun getSuggestedCreatorDetails(currentUserId: String): Flow<List<CreatorSuggestion>> = flow {
    val allVideos = videoRepository.getFeedVideos().first().getOrDefault(emptyList())
    val suggestions = engine.getSuggestedCreators(allVideos, currentUserId)
    emit(suggestions)
  }

  override fun getTrendingSounds(): Flow<List<TrendingSound>> = flow {
    val allVideos = videoRepository.getFeedVideos().first().getOrDefault(emptyList())
    val sounds = engine.getTrendingSounds(allVideos)
    emit(sounds)
  }

  override fun getVideosBySound(soundTitle: String): Flow<List<VideoItem>> = flow {
    val allVideos = videoRepository.getFeedVideos().first().getOrDefault(emptyList())
    val matching = allVideos.filter {
      it.soundTitle.contains(soundTitle, ignoreCase = true) || soundTitle.contains(it.soundTitle, ignoreCase = true)
    }
    emit(if (matching.isNotEmpty()) matching else allVideos)
  }

  override fun getRelatedVideos(targetVideoId: String): Flow<RelatedVideosResult?> = flow {
    val allVideos = videoRepository.getFeedVideos().first().getOrDefault(emptyList())
    val target = allVideos.firstOrNull { it.id == targetVideoId }
    if (target != null) {
      val related = engine.computeRelatedVideos(target, allVideos)
      emit(related)
    } else {
      emit(null)
    }
  }

  override fun getTrendingHashtags(): Flow<List<Pair<String, Long>>> = flow {
    val allVideos = videoRepository.getFeedVideos().first().getOrDefault(emptyList())
    val tagStats = mutableMapOf<String, Long>()
    allVideos.forEach { video ->
      val weight = video.stats.viewsCount + (video.stats.likesCount * 3) + (video.stats.sharesCount * 5)
      video.tags.forEach { tag ->
        tagStats[tag] = (tagStats[tag] ?: 0L) + weight
      }
    }
    val sorted = tagStats.toList().sortedByDescending { it.second }
    emit(sorted)
  }

  override fun searchAll(query: String): Flow<SearchResult> = flow {
    val clean = query.trim()
    if (clean.isEmpty()) {
      emit(SearchResult(query = ""))
      return@flow
    }

    val allVideos = videoRepository.getFeedVideos().first().getOrDefault(emptyList())
    val searchRaw = clean.removePrefix("@").removePrefix("#").lowercase()

    // 1. Matched Creators with Relevance Scoring
    val matchedCreators = allVideos
      .map { it.creator }
      .distinctBy { it.id }
      .filter {
        it.username.lowercase().contains(searchRaw) ||
          it.displayName.lowercase().contains(searchRaw) ||
          it.bio.lowercase().contains(searchRaw)
      }
      .sortedWith(
        compareByDescending<CreatorModel> { it.isVerified }
          .thenByDescending { it.followersCount }
      )

    // 2. Matched Videos with Multi-attribute relevance
    val matchedVideos = allVideos
      .filter {
        it.title.lowercase().contains(searchRaw) ||
          it.description.lowercase().contains(searchRaw) ||
          it.tags.any { tag -> tag.lowercase().contains(searchRaw) } ||
          it.soundTitle.lowercase().contains(searchRaw)
      }
      .sortedByDescending { it.stats.likesCount }

    // 3. Matched Hashtags with Volume
    val tagCounts = mutableMapOf<String, Long>()
    allVideos.forEach { video ->
      video.tags.forEach { tag ->
        tagCounts[tag] = (tagCounts[tag] ?: 0L) + 1L
      }
    }
    val matchedHashtags = tagCounts
      .filter { (tag, _) -> tag.lowercase().contains(searchRaw) }
      .toList()
      .sortedByDescending { it.second }

    emit(
      SearchResult(
        query = clean,
        matchedCreators = matchedCreators,
        matchedVideos = matchedVideos,
        matchedHashtags = matchedHashtags,
      ),
    )
  }

  override fun getHashtagDetail(tag: String): Flow<HashtagDetail> = flow {
    val normalized = if (tag.startsWith("#")) tag else "#$tag"
    val allVideos = videoRepository.getFeedVideos().first().getOrDefault(emptyList())

    val tagVideos = allVideos.filter { it.tags.any { t -> t.equals(normalized, ignoreCase = true) } }
    val totalViews = tagVideos.sumOf { it.stats.viewsCount }

    emit(
      HashtagDetail(
        tag = normalized,
        count = tagVideos.size.toLong().coerceAtLeast(1L),
        totalViews = totalViews,
        description = "فيديوهات ولحظات عمودية موثقة في أعماق الهڨار بوسم $normalized.",
        videos = tagVideos,
      ),
    )
  }

  override fun getUserProfileSnapshot(): UserRecommendationProfile {
    return engine.getUserProfileSnapshot()
  }
}
