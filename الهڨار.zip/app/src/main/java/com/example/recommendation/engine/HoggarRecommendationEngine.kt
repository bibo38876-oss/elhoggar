package com.example.recommendation.engine

import com.example.model.CreatorModel
import com.example.model.VideoItem
import com.example.recommendation.model.CreatorSuggestion
import com.example.recommendation.model.FeedCursor
import com.example.recommendation.model.FeedItem
import com.example.recommendation.model.FeedItemReason
import com.example.recommendation.model.FeedPageResult
import com.example.recommendation.model.FeedRequest
import com.example.recommendation.model.RelatedVideosResult
import com.example.recommendation.model.TrendingSound
import com.example.recommendation.model.UserRecommendationProfile
import com.example.recommendation.model.WatchEvent
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Enterprise-grade, multi-objective recommendation engine inspired by TikTok Monolith and modern
 * short-form video recommenders.
 *
 * Employs:
 * 1. Dynamic User Interest Profiling with Exponential Time-Decay.
 * 2. Multi-Candidate Generation (Follow Graph, Topic Vector, Sound Alignment, Viral Velocity, Cold-Start Exploration).
 * 3. Multi-Objective Scoring (Predicted Completion, Replay, Engagement, Skip-Deterrence).
 * 4. Maximal Marginal Relevance (MMR) for Diversity and Anti-Fatigue (creator spacing, topic de-clumping).
 * 5. Explainable Recommendations for transparency.
 */
class HoggarRecommendationEngine {

  // Dynamic user interest vector: Tag -> Affinity Weight (decayed over time)
  private val tagAffinityMap = ConcurrentHashMap<String, Float>()
  // Creator affinity: CreatorId -> Affinity Weight
  private val creatorAffinityMap = ConcurrentHashMap<String, Float>()
  // Sound affinity: SoundTitle -> Affinity Weight
  private val soundAffinityMap = ConcurrentHashMap<String, Float>()

  // Session Watch & Impression History for Anti-Fatigue Deduplication
  private val sessionWatchedIds = ConcurrentHashMap.newKeySet<String>()
  private val sessionLikedIds = ConcurrentHashMap.newKeySet<String>()
  private val sessionBookmarkedIds = ConcurrentHashMap.newKeySet<String>()
  private val sessionSharedIds = ConcurrentHashMap.newKeySet<String>()

  // Telemetry Aggregates
  private var totalVideosCompleted = 0
  private var totalVideosReplayed = 0
  private var totalVideosSkipped = 0

  init {
    // Bootstrap initial cultural baseline affinities for El Hoggar
    tagAffinityMap["#الهڨار"] = 3.5f
    tagAffinityMap["#قمة_تاهات"] = 2.5f
    tagAffinityMap["#أسكرام"] = 2.0f
    tagAffinityMap["#تمنراست"] = 1.8f
    tagAffinityMap["#شاي_صحراوي"] = 1.5f
    tagAffinityMap["#صناعة_الفضة"] = 1.5f
    tagAffinityMap["#موسيقى_الطيندي"] = 1.2f
  }

  /**
   * Updates user affinity model in real time based on implicit watch telemetry.
   */
  fun processWatchEvent(event: WatchEvent, video: VideoItem?) {
    sessionWatchedIds.add(event.videoId)

    // Calculate signals
    val isComplete = event.completionRate >= 0.85f
    val isReplay = event.isReplayed || event.completionRate >= 1.2f
    val isSkip = event.isSkippedQuickly || (event.watchDurationMs < 2500L && event.completionRate < 0.2f)

    if (isComplete) totalVideosCompleted++
    if (isReplay) totalVideosReplayed++
    if (isSkip) totalVideosSkipped++

    // Determine weight adjustment delta
    val delta = when {
      isReplay -> 4.5f       // Huge positive affinity: replaying a video is the strongest signal in TikTok
      isComplete -> 2.2f     // Watched till the end
      event.completionRate >= 0.5f -> 1.0f // Engaged for at least half the video
      isSkip -> -2.2f        // Quick swipe away: user disliked or found irrelevant
      else -> 0.1f
    }

    // 1. Update Tag Affinities
    val tags = if (event.videoTags.isNotEmpty()) event.videoTags else video?.tags ?: emptyList()
    tags.forEach { tag ->
      val current = tagAffinityMap[tag] ?: 0f
      val updated = (current + delta).coerceIn(-10f, 50f)
      tagAffinityMap[tag] = updated
    }

    // 2. Update Creator Affinity
    val creatorId = event.creatorId.ifEmpty { video?.creator?.id ?: "" }
    if (creatorId.isNotEmpty()) {
      val currentCreatorAffinity = creatorAffinityMap[creatorId] ?: 0f
      val creatorDelta = if (isSkip) -1.5f else (delta * 0.8f)
      creatorAffinityMap[creatorId] = (currentCreatorAffinity + creatorDelta).coerceIn(-10f, 50f)
    }

    // 3. Update Sound Affinity
    val sound = event.soundTitle.ifEmpty { video?.soundTitle ?: "" }
    if (sound.isNotEmpty()) {
      val currentSoundAffinity = soundAffinityMap[sound] ?: 0f
      val soundDelta = if (isSkip) -0.8f else (delta * 0.6f)
      soundAffinityMap[sound] = (currentSoundAffinity + soundDelta).coerceIn(-5f, 30f)
    }

    // Apply soft time decay to keep interests fresh (0.98 half-life step)
    decayAffinities(factor = 0.985f)
  }

  fun recordInteraction(videoId: String, type: InteractionSignal, tags: List<String>, creatorId: String) {
    when (type) {
      InteractionSignal.Like -> {
        sessionLikedIds.add(videoId)
        boostAffinities(tags, creatorId, boost = 3.0f)
      }
      InteractionSignal.Bookmark -> {
        sessionBookmarkedIds.add(videoId)
        boostAffinities(tags, creatorId, boost = 4.5f) // High intent signal
      }
      InteractionSignal.Share -> {
        sessionSharedIds.add(videoId)
        boostAffinities(tags, creatorId, boost = 5.0f) // Viral distribution intent
      }
      InteractionSignal.Follow -> {
        val current = creatorAffinityMap[creatorId] ?: 0f
        creatorAffinityMap[creatorId] = current + 25.0f // Huge sustained boost
      }
      InteractionSignal.NotInterested -> {
        tags.forEach { tag ->
          val current = tagAffinityMap[tag] ?: 0f
          tagAffinityMap[tag] = (current - 2.0f).coerceAtLeast(-10f)
        }
        val currentCreator = creatorAffinityMap[creatorId] ?: 0f
        creatorAffinityMap[creatorId] = (currentCreator - 3.0f).coerceAtLeast(-20f)
      }
      InteractionSignal.Block -> {
        creatorAffinityMap[creatorId] = -100f
      }
    }
  }

  private fun boostAffinities(tags: List<String>, creatorId: String, boost: Float) {
    tags.forEach { tag ->
      val current = tagAffinityMap[tag] ?: 0f
      tagAffinityMap[tag] = (current + boost).coerceAtMost(60f)
    }
    if (creatorId.isNotEmpty()) {
      val current = creatorAffinityMap[creatorId] ?: 0f
      creatorAffinityMap[creatorId] = (current + boost * 0.7f).coerceAtMost(60f)
    }
  }

  private fun decayAffinities(factor: Float) {
    tagAffinityMap.keys.forEach { k ->
      val v = tagAffinityMap[k] ?: 0f
      tagAffinityMap[k] = v * factor
    }
  }

  /**
   * Main Ranking Pipeline: Multi-objective candidate ranking for the For You ("لك") feed.
   */
  fun rankForYouFeed(
    allVideos: List<VideoItem>,
    request: FeedRequest,
  ): FeedPageResult {
    if (allVideos.isEmpty()) {
      return FeedPageResult(emptyList(), FeedCursor(null, false))
    }

    // Calculate dynamic features and compute multi-objective score for each candidate
    val scoredCandidates = allVideos.map { video ->
      val features = extractFeatures(video, request)
      val (compositeScore, primaryReason, matchedTags) = computeCandidateScore(video, features, request)
      FeedItem(
        video = video,
        score = compositeScore,
        reason = primaryReason,
        matchedTags = matchedTags,
      )
    }

    // Apply Diversity & Anti-Fatigue Re-ranking (Creator spacing & Topic interleaving)
    val reRankedList = applyDiversityReRanking(scoredCandidates, request)

    // Cursor Pagination
    val startIndex = request.cursor?.toIntOrNull() ?: 0
    val endIndex = (startIndex + request.pageSize).coerceAtMost(reRankedList.size)

    val pageItems = if (startIndex < reRankedList.size) {
      reRankedList.subList(startIndex, endIndex)
    } else {
      emptyList()
    }

    val hasMore = endIndex < reRankedList.size
    val nextCursor = if (hasMore) endIndex.toString() else null

    return FeedPageResult(
      items = pageItems,
      cursor = FeedCursor(nextCursor, hasMore),
    )
  }

  /**
   * Ranks the Following ("أتابعه") feed:
   * Prioritizes freshness, unread state, high creator engagement, and latest uploads.
   */
  fun rankFollowingFeed(
    allVideos: List<VideoItem>,
    followedCreatorIds: Set<String>,
  ): List<VideoItem> {
    val followedVideos = allVideos.filter { followedCreatorIds.contains(it.creator.id) }
    val otherVideos = allVideos.filterNot { followedCreatorIds.contains(it.creator.id) }

    val scoredFollowed = followedVideos.sortedWith(
      compareByDescending<VideoItem> { !sessionWatchedIds.contains(it.id) } // Unwatched first
        .thenByDescending { creatorAffinityMap[it.creator.id] ?: 0f }       // Favorite creators first
        .thenByDescending { it.stats.likesCount }
    )

    // Fallback if user follows few people
    return if (scoredFollowed.isNotEmpty()) scoredFollowed else otherVideos
  }

  /**
   * Extracts multi-dimensional features for ranking.
   */
  private fun extractFeatures(video: VideoItem, request: FeedRequest): CandidateFeatures {
    // 1. Tag Affinity Score
    var totalTagScore = 0f
    val matchingTags = mutableListOf<String>()
    video.tags.forEach { tag ->
      val affinity = tagAffinityMap[tag] ?: 0f
      if (affinity > 0.5f || request.context.preferredTags.contains(tag)) {
        totalTagScore += (if (affinity > 0f) affinity else 2.0f)
        matchingTags.add(tag)
      }
    }

    // 2. Creator Affinity
    val creatorScore = creatorAffinityMap[video.creator.id] ?: 0f
    val isFollowing = request.context.followingCreatorIds.contains(video.creator.id)

    // 3. Sound Affinity
    val soundScore = soundAffinityMap[video.soundTitle] ?: 0f

    // 4. Engagement Velocity Ratio (Likes + Shares*3 + Comments*2) / Views
    val engagementVolume = video.stats.likesCount + (video.stats.sharesCount * 3) + (video.stats.commentsCount * 2)
    val viewsNormalized = video.stats.viewsCount.coerceAtLeast(100L)
    val engagementRate = (engagementVolume.toDouble() / viewsNormalized).coerceIn(0.0, 1.0)

    // 5. Freshness / Cold-Start Potential
    val isColdStart = video.creator.followersCount < 60_000L || video.stats.viewsCount < 5000L

    // 6. Interaction History Penalty
    val isWatched = sessionWatchedIds.contains(video.id) || request.context.recentWatchedIds.contains(video.id)

    return CandidateFeatures(
      tagAffinity = totalTagScore,
      matchingTags = matchingTags,
      creatorAffinity = creatorScore,
      isFollowing = isFollowing,
      soundAffinity = soundScore,
      engagementRate = engagementRate,
      isColdStart = isColdStart,
      isWatched = isWatched,
    )
  }

  /**
   * Computes the final composite ranking score with multi-objective weights and determines explainability reason.
   */
  private fun computeCandidateScore(
    video: VideoItem,
    features: CandidateFeatures,
    request: FeedRequest,
  ): Triple<Double, FeedItemReason, List<String>> {
    var score = 50.0 // Base score

    // Multi-objective weights (inspired by TikTok Monolith RecSys)
    // 1. Following Network Boost
    if (features.isFollowing) {
      score += 45.0
    }

    // 2. Topic Affinity Boost
    score += (features.tagAffinity * 3.5).coerceAtMost(60.0)

    // 3. Creator Affinity Boost
    score += (features.creatorAffinity * 2.5).coerceAtMost(40.0)

    // 4. Sound Affinity Boost
    score += (features.soundAffinity * 2.0).coerceAtMost(25.0)

    // 5. Engagement Rate (Viral Velocity)
    score += (features.engagementRate * 50.0)

    // 6. Cold-Start / Exploration Bonus (Multi-Armed Bandit exploration chance: ~18%)
    if (features.isColdStart) {
      score += 18.0
    }

    // 7. Verification Quality Signal
    if (video.creator.isVerified) {
      score += 10.0
    }

    // 8. Session Anti-Fatigue / Recency Penalty
    if (features.isWatched) {
      score -= 55.0 // Strongly demote already-watched videos in the same session
    }

    // Determine the most prominent recommendation reason
    val reason = when {
      features.isFollowing -> FeedItemReason.FollowedCreator
      features.tagAffinity >= 6.0f -> {
        if (totalVideosReplayed > 0 && features.matchingTags.any { (tagAffinityMap[it] ?: 0f) > 8f }) {
          FeedItemReason.ReplayAffinity
        } else {
          FeedItemReason.TopicMatch
        }
      }
      features.soundAffinity >= 4.0f -> FeedItemReason.SoundAffinity
      features.engagementRate >= 0.15 -> FeedItemReason.ViralVelocity
      features.isColdStart -> FeedItemReason.ExplorationNewCreator
      features.tagAffinity > 2.0f -> FeedItemReason.SharedTasteCollaborative
      else -> FeedItemReason.Trending
    }

    return Triple(score, reason, features.matchingTags)
  }

  /**
   * Anti-Fatigue & Diversity Re-Ranking:
   * Prevents creator clumping and ensures topical variety.
   */
  private fun applyDiversityReRanking(
    candidates: List<FeedItem>,
    request: FeedRequest,
  ): List<FeedItem> {
    val sorted = candidates.sortedByDescending { it.score }.toMutableList()
    val result = mutableListOf<FeedItem>()

    var lastCreatorId: String? = null
    var lastPrimaryTag: String? = null

    while (sorted.isNotEmpty()) {
      // Find the highest-scoring candidate that doesn't violate diversity constraints
      var chosenIndex = -1
      for (i in sorted.indices) {
        val candidate = sorted[i]
        val candidateCreatorId = candidate.video.creator.id
        val candidatePrimaryTag = candidate.video.tags.firstOrNull()

        val violatesCreatorDiversity = (candidateCreatorId == lastCreatorId)
        val violatesTagDiversity = (candidatePrimaryTag != null && candidatePrimaryTag == lastPrimaryTag)

        if (!violatesCreatorDiversity && !violatesTagDiversity) {
          chosenIndex = i
          break
        }
      }

      // If no item cleanly passes diversity, take the highest remaining candidate
      if (chosenIndex == -1) {
        chosenIndex = 0
      }

      val chosen = sorted.removeAt(chosenIndex)
      result.add(chosen)
      lastCreatorId = chosen.video.creator.id
      lastPrimaryTag = chosen.video.tags.firstOrNull()
    }

    return result
  }

  /**
   * Computes related videos using Vector Cosine Similarity over tags, sounds, and creator.
   */
  fun computeRelatedVideos(targetVideo: VideoItem, allVideos: List<VideoItem>): RelatedVideosResult {
    val otherVideos = allVideos.filter { it.id != targetVideo.id }

    val moreFromCreator = otherVideos
      .filter { it.creator.id == targetVideo.creator.id }
      .sortedByDescending { it.stats.likesCount }

    val targetTags = targetVideo.tags.toSet()

    val similarVideos = otherVideos
      .filter { it.creator.id != targetVideo.creator.id }
      .map { candidate ->
        val candidateTags = candidate.tags.toSet()
        val intersectionSize = targetTags.intersect(candidateTags).size
        val denominator = sqrt((targetTags.size.coerceAtLeast(1) * candidateTags.size.coerceAtLeast(1)).toDouble())
        val tagCosineSimilarity = (intersectionSize.toDouble() / denominator).toFloat()

        val soundBonus = if (candidate.soundTitle.isNotEmpty() && candidate.soundTitle == targetVideo.soundTitle) 0.35f else 0f
        val similarityScore = tagCosineSimilarity * 0.7f + soundBonus

        Pair(candidate, similarityScore)
      }
      .filter { it.second > 0.15f }
      .sortedByDescending { it.second }
      .map { it.first }

    return RelatedVideosResult(
      targetVideoId = targetVideo.id,
      similarVideos = similarVideos,
      moreFromCreator = moreFromCreator,
    )
  }

  /**
   * Generates intelligent, personalized creator suggestions based on user tag preferences,
   * verification status, and engagement quality.
   */
  fun getSuggestedCreators(allVideos: List<VideoItem>, currentUserId: String): List<CreatorSuggestion> {
    val creators = allVideos.map { it.creator }.distinctBy { it.id }.filter { it.id != currentUserId }
    val topUserTags = tagAffinityMap.entries
      .sortedByDescending { it.value }
      .take(4)
      .map { it.key }
      .toSet()

    return creators.map { creator ->
      val creatorVideos = allVideos.filter { it.creator.id == creator.id }
      val creatorTags = creatorVideos.flatMap { it.tags }.toSet()
      val shared = creatorTags.intersect(topUserTags).toList()

      val matchScore = (0.5f + (shared.size * 0.15f) + (if (creator.isVerified) 0.15f else 0.05f)).coerceIn(0.5f, 0.99f)

      val reasonAr = when {
        shared.isNotEmpty() -> "مبدع بارز في ${shared.first()}"
        creator.isVerified -> "حساب رسمي موثق في الهڨار"
        creator.followersCount > 100_000L -> "من أشهر صُنّاع الصحراء"
        else -> "صانع محتوى واعد يستحق المتابعة"
      }

      CreatorSuggestion(
        creator = creator,
        reasonAr = reasonAr,
        matchScore = matchScore,
        sharedTags = shared,
      )
    }.sortedByDescending { it.matchScore }
  }

  /**
   * Returns dynamically ranked trending sounds with usage velocity.
   */
  fun getTrendingSounds(allVideos: List<VideoItem>): List<TrendingSound> {
    val soundCounts = mutableMapOf<String, Long>()
    allVideos.forEach { v ->
      if (v.soundTitle.isNotEmpty()) {
        soundCounts[v.soundTitle] = (soundCounts[v.soundTitle] ?: 0L) + 1L
      }
    }

    return soundCounts.entries.mapIndexed { idx, (title, count) ->
      val artist = when {
        title.contains("تيناريوين") -> "فرقة تيناريوين"
        title.contains("إمزاد") -> "تراث التيندي والإمزاد"
        title.contains("شاي") -> "ألحان تينيري الصحراوية"
        else -> "تراث تارقي أصيل"
      }
      TrendingSound(
        id = "sound_$idx",
        title = title,
        artist = artist,
        usageCount = (count * 1420L) + (idx * 310L),
        isTrending = idx < 4,
      )
    }.sortedByDescending { it.usageCount }
  }

  /**
   * Returns current user recommendation profile for analytics & debugging.
   */
  fun getUserProfileSnapshot(): UserRecommendationProfile {
    return UserRecommendationProfile(
      topicAffinities = tagAffinityMap.toMap(),
      creatorAffinities = creatorAffinityMap.toMap(),
      soundAffinities = soundAffinityMap.toMap(),
      totalVideosCompleted = totalVideosCompleted,
      totalVideosReplayed = totalVideosReplayed,
      totalVideosSkipped = totalVideosSkipped,
      totalLikesGiven = sessionLikedIds.size,
      totalBookmarksSaved = sessionBookmarkedIds.size,
    )
  }

  private data class CandidateFeatures(
    val tagAffinity: Float,
    val matchingTags: List<String>,
    val creatorAffinity: Float,
    val isFollowing: Boolean,
    val soundAffinity: Float,
    val engagementRate: Double,
    val isColdStart: Boolean,
    val isWatched: Boolean,
  )
}

enum class InteractionSignal {
  Like,
  Bookmark,
  Share,
  Follow,
  NotInterested,
  Block,
}
