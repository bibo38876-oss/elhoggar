package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.ChatBubble
import androidx.compose.material.icons.outlined.DynamicFeed
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Top-level Navigation Destinations for El Hoggar
 */
enum class NavigationTab(
  val route: String,
  val labelAr: String,
  val labelEn: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
) {
  Home(
    route = "home",
    labelAr = "الرئيسية",
    labelEn = "Home",
    selectedIcon = Icons.Filled.Home,
    unselectedIcon = Icons.Outlined.Home,
  ),
  Posts(
    route = "posts",
    labelAr = "المنشورات",
    labelEn = "Posts",
    selectedIcon = Icons.Filled.DynamicFeed,
    unselectedIcon = Icons.Outlined.DynamicFeed,
  ),
  Discover(
    route = "discover",
    labelAr = "البحث",
    labelEn = "Discover",
    selectedIcon = Icons.Filled.Search,
    unselectedIcon = Icons.Outlined.Search,
  ),
  Create(
    route = "create",
    labelAr = "إنشاء",
    labelEn = "Create",
    selectedIcon = Icons.Filled.Home, // Rendered via custom HoggarCameraCrest
    unselectedIcon = Icons.Outlined.Home,
  ),
  Activity(
    route = "activity",
    labelAr = "النشاط",
    labelEn = "Activity",
    selectedIcon = Icons.Filled.Notifications,
    unselectedIcon = Icons.Outlined.Notifications,
  ),
  Profile(
    route = "profile",
    labelAr = "الملف",
    labelEn = "Profile",
    selectedIcon = Icons.Filled.Person,
    unselectedIcon = Icons.Outlined.Person,
  ),
}
