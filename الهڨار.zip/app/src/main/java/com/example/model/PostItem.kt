package com.example.model

/**
 * Represents a post on El Hoggar created by a creator or user.
 * Supports text posts, multimedia with attached images, hashtags, and social engagement (Twitter/X style).
 */
data class PostItem(
  val id: String,
  val author: CreatorModel,
  val contentText: String,
  val imageUrls: List<String> = emptyList(),
  val tags: List<String> = emptyList(),
  val timestampMs: Long = System.currentTimeMillis(),
  val likesCount: Long = 0L,
  val repostsCount: Long = 0L,
  val repliesCount: Long = 0L,
  val viewsCount: Long = 0L,
  val isLiked: Boolean = false,
  val isReposted: Boolean = false,
  val isBookmarked: Boolean = false,
  val pollOptions: List<String> = emptyList(),
  val pollVotes: List<Int> = emptyList(),
)
