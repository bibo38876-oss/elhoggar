package com.example.model

enum class VideoVisibility {
  Public,
  Private
}

enum class VideoModerationStatus(val labelAr: String) {
  Pending("قيد المراجعة"),
  Approved("معتمد للعامة"),
  Rejected("مرفوض"),
  Restricted("مقيد الوصول"),
}

enum class VideoProcessingStatus {
  Idle,
  Uploading,
  Validating,
  Transcoding,
  GeneratingThumbnail,
  Moderating,
  Published,
  Failed
}

/**
 * Creator Profile Model
 */
data class CreatorModel(
  val id: String,
  val username: String,
  val displayName: String,
  val avatarUrl: String,
  val isVerified: Boolean = false,
  val bio: String = "",
  val followersCount: Long = 0L,
)

/**
 * Video Interaction Statistics
 */
data class VideoStats(
  val likesCount: Long = 0L,
  val commentsCount: Long = 0L,
  val sharesCount: Long = 0L,
  val viewsCount: Long = 0L,
)

/**
 * Core Video Item Model
 * Scalable for production with metadata, tags, audio info, visibility, and pipeline processing status.
 */
data class VideoItem(
  val id: String,
  val videoUrl: String,
  val thumbnailUrl: String = "",
  val title: String,
  val description: String,
  val tags: List<String> = emptyList(),
  val durationSeconds: Int = 60,
  val creator: CreatorModel,
  val ownerId: String = creator.id,
  val stats: VideoStats = VideoStats(),
  val soundTitle: String = "الصوت الأصلي",
  val soundAuthor: String = "",
  val visibility: VideoVisibility = VideoVisibility.Public,
  val processingStatus: VideoProcessingStatus = VideoProcessingStatus.Published,
  val isLiked: Boolean = false,
  val isBookmarked: Boolean = false,
  val isFollowing: Boolean = false,
  val timestampMs: Long = System.currentTimeMillis(),
  val isAudioMuted: Boolean = false,
  val trimStartSeconds: Int = 0,
  val trimEndSeconds: Int = durationSeconds,
  val moderationStatus: VideoModerationStatus = VideoModerationStatus.Approved,
)
