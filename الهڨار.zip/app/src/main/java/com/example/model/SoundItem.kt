package com.example.model

/**
 * Sound / Audio track extracted from videos or uploaded to the El Hoggar Sound Vault.
 * Every video published on El Hoggar automatically has its audio extracted and indexed
 * here, allowing any creator to reuse it for their own videos.
 */
data class SoundItem(
  val id: String,
  val title: String,
  val authorName: String,
  val authorUsername: String = "",
  val soundUrl: String = "",
  val coverUrl: String = "",
  val durationSeconds: Int = 60,
  val originalVideoId: String = "",
  val usageCount: Long = 1L,
  val isTrending: Boolean = false,
  val isExtractedFromVideo: Boolean = true,
  val timestampMs: Long = System.currentTimeMillis(),
)
