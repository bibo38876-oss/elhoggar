package com.example.production.featureflag

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Feature Flags System
 * Allows enabling/disabling features remotely or locally, testing features on subsets of users,
 * and performing zero-downtime rollbacks without requiring new store releases.
 */
data class FeatureFlags(
  val enableHlsStreaming: Boolean = true,
  val enableResumableUpload: Boolean = true,
  val enableQualitySelector: Boolean = true,
  val enableStrictModeration: Boolean = true,
  val enableDataSaverByDefault: Boolean = false,
  val maxFeedBatchSize: Int = 10,
  val uploadChunkSizeBytes: Int = 1024 * 1024, // 1MB chunks
)

class FeatureFlagManager(
  initialFlags: FeatureFlags = FeatureFlags(),
) {
  private val _flags = MutableStateFlow(initialFlags)
  val flags: StateFlow<FeatureFlags> = _flags.asStateFlow()

  fun updateFlags(newFlags: FeatureFlags) {
    _flags.value = newFlags
  }

  fun setHlsStreaming(enabled: Boolean) {
    _flags.value = _flags.value.copy(enableHlsStreaming = enabled)
  }

  fun setResumableUpload(enabled: Boolean) {
    _flags.value = _flags.value.copy(enableResumableUpload = enabled)
  }

  companion object {
    val instance: FeatureFlagManager by lazy { FeatureFlagManager() }
  }
}
