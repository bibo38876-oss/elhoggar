package com.example.production.monitoring

import android.os.Build
import java.util.UUID

/**
 * Crash and Error Diagnostic Reporting Service
 * Captures operational error contexts without leaking technical stack traces to end users.
 */
data class CrashReport(
  val reportId: String = UUID.randomUUID().toString(),
  val appVersion: String = "1.0.0-prod",
  val deviceModel: String = "${Build.MANUFACTURER} ${Build.MODEL}",
  val osVersion: String = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
  val exceptionClass: String,
  val errorMessage: String,
  val breadcrumbs: List<String>,
  val timestampMs: Long = System.currentTimeMillis(),
)

class CrashReportingService(
  private val logger: HoggarLogger = HoggarLogger(),
) {
  private val breadcrumbs = mutableListOf<String>()
  private val reports = mutableListOf<CrashReport>()

  fun addBreadcrumb(action: String) {
    if (breadcrumbs.size >= 50) {
      breadcrumbs.removeAt(0)
    }
    breadcrumbs.add("${System.currentTimeMillis()}: $action")
  }

  fun recordException(throwable: Throwable, contextTag: String = "App") {
    val report = CrashReport(
      exceptionClass = throwable.javaClass.simpleName,
      errorMessage = throwable.message ?: "Unknown runtime exception",
      breadcrumbs = breadcrumbs.toList(),
    )
    reports.add(report)
    logger.error(
      "CrashReport",
      "Recorded non-fatal exception [${report.reportId}] in $contextTag: ${report.errorMessage}",
      mapOf("reportId" to report.reportId, "exception" to report.exceptionClass),
    )
  }

  fun getRecentReports(): List<CrashReport> = reports.toList()

  companion object {
    val instance: CrashReportingService by lazy { CrashReportingService() }
  }
}
