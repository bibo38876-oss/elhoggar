package com.example.production.env

/**
 * Platform Environment Configuration
 * Decouples Development, Staging, and Production targets to prevent testing in Production.
 */
enum class EnvironmentType(val labelAr: String) {
  Development("بيئة التطوير (Dev)"),
  Staging("بيئة الاختبار والتكامل (Staging)"),
  Production("بيئة الإنتاج الحية (Production)"),
}

data class EnvironmentConfig(
  val type: EnvironmentType,
  val apiBaseUrl: String,
  val cdnBaseUrl: String,
  val objectStorageEndpoint: String,
  val requestTimeoutMs: Long,
  val rateLimitPerMinute: Int,
  val enableDebugLogs: Boolean,
) {
  companion object {
    val Development = EnvironmentConfig(
      type = EnvironmentType.Development,
      apiBaseUrl = "https://dev-api.elhoggar.dz/v1",
      cdnBaseUrl = "https://dev-cdn.elhoggar.dz",
      objectStorageEndpoint = "https://dev-storage.elhoggar.dz/raw-media",
      requestTimeoutMs = 15000L,
      rateLimitPerMinute = 120,
      enableDebugLogs = true,
    )

    val Staging = EnvironmentConfig(
      type = EnvironmentType.Staging,
      apiBaseUrl = "https://staging-api.elhoggar.dz/v1",
      cdnBaseUrl = "https://staging-cdn.elhoggar.dz",
      objectStorageEndpoint = "https://staging-storage.elhoggar.dz/raw-media",
      requestTimeoutMs = 12000L,
      rateLimitPerMinute = 60,
      enableDebugLogs = true,
    )

    val Production = EnvironmentConfig(
      type = EnvironmentType.Production,
      apiBaseUrl = "https://api.elhoggar.dz/v1",
      cdnBaseUrl = "https://cdn.elhoggar.dz",
      objectStorageEndpoint = "https://storage.elhoggar.dz/media-vault",
      requestTimeoutMs = 8000L,
      rateLimitPerMinute = 45,
      enableDebugLogs = false,
    )

    var current: EnvironmentConfig = Production
  }
}
