package com.example.production.api

import java.util.UUID

/**
 * Standard Production API Response Wrapper
 * Ensures consistent serialization, error contracts, and tracing correlation across all microservices.
 */
sealed class ApiResponse<out T> {
  data class Success<out T>(
    val data: T,
    val meta: ApiMeta = ApiMeta(),
  ) : ApiResponse<T>()

  data class Error(
    val code: String,
    val message: String,
    val correlationId: String = UUID.randomUUID().toString(),
    val httpStatus: Int = 400,
  ) : ApiResponse<Nothing>()
}

data class ApiMeta(
  val serverTimeMs: Long = System.currentTimeMillis(),
  val apiVersion: String = "v1",
  val cursor: String? = null,
  val nextCursor: String? = null,
  val hasMore: Boolean = false,
  val totalCount: Long? = null,
)

data class PaginatedResult<T>(
  val items: List<T>,
  val nextCursor: String?,
  val hasMore: Boolean,
)
