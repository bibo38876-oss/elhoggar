package com.example.production.database

/**
 * Production Database Architecture Specification
 * Documents schemas, primary keys, relationships, and composite indexes designed for
 * sub-millisecond retrieval at scale without unbounded table scans.
 */
object DatabaseSchemaSpec {

  val COLLECTIONS_AND_INDEXES = mapOf(
    "users" to listOf(
      "PK: id (UUID)",
      "INDEX: email (Unique)",
      "INDEX: phone (Sparse Unique)",
      "INDEX: status (Active, Banned, Restricted)",
    ),
    "profiles" to listOf(
      "PK: userId (FK -> users.id)",
      "INDEX: username (Unique Lowercase)",
      "INDEX: displayName (Trigram text search)",
    ),
    "videos" to listOf(
      "PK: id (Unguessable Secure Storage UUID)",
      "INDEX: creatorId + createdAt DESC (Creator feed pagination)",
      "INDEX: moderationStatus + createdAt DESC (Public discoverability)",
      "INDEX: visibility + createdAt DESC",
    ),
    "follows" to listOf(
      "COMPOSITE PK: (followerId, followedId)",
      "INDEX: followerId (Following list)",
      "INDEX: followedId (Followers list)",
    ),
    "likes" to listOf(
      "COMPOSITE PK: (userId, videoId)",
      "INDEX: videoId + createdAt DESC (Video likers)",
      "INDEX: userId + createdAt DESC (User liked videos)",
    ),
    "comments" to listOf(
      "PK: id",
      "INDEX: videoId + createdAt DESC (Video comment stream)",
      "INDEX: authorId (User comments)",
    ),
    "replies" to listOf(
      "PK: id",
      "INDEX: parentCommentId + createdAt ASC (Thread ordering)",
    ),
    "views" to listOf(
      "PK: id",
      "INDEX: videoId + timestampMs DESC (Aggregated analytics)",
      "INDEX: viewerId + videoId (Unique view de-duplication)",
    ),
    "shares" to listOf(
      "PK: id",
      "INDEX: videoId + timestampMs DESC",
    ),
    "hashtags" to listOf(
      "PK: tag (Unique normalized)",
      "INDEX: trendingScore DESC (Discovery rank)",
    ),
    "notifications" to listOf(
      "PK: id",
      "INDEX: recipientId + isRead + createdAt DESC (Unread notifications query)",
    ),
    "reports" to listOf(
      "PK: id",
      "INDEX: status + createdAt DESC (Admin triage queue)",
    ),
    "moderation_actions" to listOf(
      "PK: id",
      "INDEX: targetId + timestampMs DESC",
    ),
    "audit_logs" to listOf(
      "PK: id",
      "INDEX: timestampMs DESC (Immutable regulatory timeline)",
      "INDEX: adminId + timestampMs DESC",
    ),
  )
}
