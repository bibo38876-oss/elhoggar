package com.example.production.analytics

import com.example.production.monitoring.HoggarLogger

/**
 * Privacy-First Production Telemetry
 * Captures operational and performance signals strictly without storing personal identifiables (PII).
 */
data class OperationalMetrics(
  val appOpensCount: Long = 0,
  val videoStartsCount: Long = 0,
  val totalWatchDurationSecs: Long = 0,
  val completedVideosCount: Long = 0,
  val uploadSuccessCount: Long = 0,
  val uploadFailureCount: Long = 0,
  val averageApiLatencyMs: Long = 0,
)

class HoggarAnalyticsTracker(
  private val logger: HoggarLogger = HoggarLogger(),
) {
  private var appOpens: Long = 0
  private var videoStarts: Long = 0
  private var totalWatchDuration: Long = 0
  private var completedVideos: Long = 0
  private var uploadSuccess: Long = 0
  private var uploadFailure: Long = 0
  private var totalLatency: Long = 0
  private var latencyRequestsCount: Long = 0

  @Synchronized
  fun trackAppOpen() {
    appOpens++
    logger.info("Telemetry", "App opened", mapOf("count" to appOpens))
  }

  @Synchronized
  fun trackVideoStart(videoId: String) {
    videoStarts++
    logger.info("Telemetry", "Video playback initiated", mapOf("videoId" to videoId))
  }

  @Synchronized
  fun trackWatchSession(videoId: String, durationSecs: Long, isCompleted: Boolean) {
    totalWatchDuration += durationSecs
    if (isCompleted) {
      completedVideos++
    }
    logger.info(
      "Telemetry",
      "Watch session completed",
      mapOf(
        "videoId" to videoId,
        "durationSecs" to durationSecs,
        "isCompleted" to isCompleted,
      ),
    )
  }

  @Synchronized
  fun trackUploadResult(isSuccess: Boolean, latencyMs: Long) {
    if (isSuccess) {
      uploadSuccess++
    } else {
      uploadFailure++
    }
    logger.info("Telemetry", "Upload outcome logged", mapOf("success" to isSuccess, "latencyMs" to latencyMs))
  }

  @Synchronized
  fun trackApiLatency(latencyMs: Long) {
    totalLatency += latencyMs
    latencyRequestsCount++
  }

  @Synchronized
  fun getSnapshot(): OperationalMetrics {
    val avgLatency = if (latencyRequestsCount > 0) totalLatency / latencyRequestsCount else 0L
    return OperationalMetrics(
      appOpensCount = appOpens,
      videoStartsCount = videoStarts,
      totalWatchDurationSecs = totalWatchDuration,
      completedVideosCount = completedVideos,
      uploadSuccessCount = uploadSuccess,
      uploadFailureCount = uploadFailure,
      averageApiLatencyMs = avgLatency,
    )
  }

  companion object {
    val instance: HoggarAnalyticsTracker by lazy { HoggarAnalyticsTracker() }
  }
}
