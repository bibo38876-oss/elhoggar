package com.example.production.feed

import com.example.model.VideoItem
import com.example.production.cache.CacheTtlConfig
import com.example.production.cache.MultiLevelCacheManager

data class PaginatedFeedResponse(
  val items: List<VideoItem>,
  val nextCursor: String?,
  val hasMore: Boolean,
  val isFromCache: Boolean = false,
)

/**
 * Scalable Decoupled Feed Service
 * Pre-computes candidate sets asynchronously and serves feeds via deterministic cursor pagination,
 * keeping database load predictable at massive concurrency.
 */
class ScalableFeedService(
  private val cacheManager: MultiLevelCacheManager = MultiLevelCacheManager.instance,
) {
  private val precomputedFeedPool = mutableListOf<VideoItem>()

  fun seedPrecomputedPool(videos: List<VideoItem>) {
    precomputedFeedPool.clear()
    precomputedFeedPool.addAll(videos)
  }

  /**
   * Fetches paginated feed page with cursor and multi-level caching.
   */
  fun getFeedPage(
    userId: String,
    cursor: String?,
    pageSize: Int = 10,
  ): PaginatedFeedResponse {
    val cacheKey = "feed_${userId}_${cursor ?: "head"}"
    val cached: PaginatedFeedResponse? = cacheManager.get(cacheKey)
    if (cached != null) {
      return cached.copy(isFromCache = true)
    }

    val startIndex = if (cursor != null) {
      val foundIndex = precomputedFeedPool.indexOfFirst { it.id == cursor }
      if (foundIndex != -1) foundIndex + 1 else 0
    } else {
      0
    }

    val endIndex = (startIndex + pageSize).coerceAtMost(precomputedFeedPool.size)
    val pageItems = if (startIndex < precomputedFeedPool.size) {
      precomputedFeedPool.subList(startIndex, endIndex)
    } else {
      emptyList()
    }

    val hasMore = endIndex < precomputedFeedPool.size
    val nextCursor = if (hasMore && pageItems.isNotEmpty()) pageItems.last().id else null

    val response = PaginatedFeedResponse(
      items = pageItems,
      nextCursor = nextCursor,
      hasMore = hasMore,
      isFromCache = false,
    )

    // Store in cache for 3 minutes
    cacheManager.put(cacheKey, response, CacheTtlConfig.FEED_TTL_MS)

    return response
  }
}
