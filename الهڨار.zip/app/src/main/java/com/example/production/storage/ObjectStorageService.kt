package com.example.production.storage

import com.example.production.env.EnvironmentConfig

/**
 * Multi-Variant Video Representation
 * In modern video architectures, raw media is stored in Object Storage while optimized variants
 * (720p, 480p, HLS/DASH manifests) and thumbnails are served globally via CDN.
 */
data class VideoVariantSet(
  val originalStorageKey: String,
  val processedMp4Key: String,
  val streamingHlsKey: String,
  val thumbnailKey: String,
  val durationSeconds: Int,
  val width: Int = 720,
  val height: Int = 1280,
)

class CdnResolver(
  private val config: EnvironmentConfig = EnvironmentConfig.current,
) {
  fun resolveVideoUrl(storageKey: String): String {
    // If it's a local asset or external mockup, return as is
    if (storageKey.startsWith("asset://") || storageKey.startsWith("http")) {
      return storageKey
    }
    return "${config.cdnBaseUrl}/videos/$storageKey"
  }

  fun resolveThumbnailUrl(thumbnailKey: String): String {
    if (thumbnailKey.startsWith("asset://") || thumbnailKey.startsWith("http")) {
      return thumbnailKey
    }
    return "${config.cdnBaseUrl}/thumbnails/$thumbnailKey"
  }

  fun resolveStreamingManifestUrl(hlsKey: String): String {
    if (hlsKey.startsWith("http")) {
      return hlsKey
    }
    return "${config.cdnBaseUrl}/hls/$hlsKey/master.m3u8"
  }
}

class ObjectStorageService(
  private val config: EnvironmentConfig = EnvironmentConfig.current,
) {
  private val storageVault = mutableMapOf<String, ByteArray>()

  fun storeRawMedia(key: String, data: ByteArray): String {
    storageVault[key] = data
    return "${config.objectStorageEndpoint}/$key"
  }

  fun getRawMedia(key: String): ByteArray? {
    return storageVault[key]
  }

  fun deleteRawMedia(key: String): Boolean {
    return storageVault.remove(key) != null
  }
}
