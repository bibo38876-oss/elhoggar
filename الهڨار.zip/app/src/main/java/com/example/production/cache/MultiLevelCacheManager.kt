package com.example.production.cache

data class CacheEntry<T>(
  val value: T,
  val createdAtMs: Long,
  val expiresAtMs: Long,
) {
  val isExpired: Boolean
    get() = System.currentTimeMillis() > expiresAtMs
}

/**
 * Standard TTL Presets (Time-To-Live)
 * Prevents showing stale data while optimizing API and network hits.
 */
object CacheTtlConfig {
  const val FEED_TTL_MS = 3 * 60 * 1000L // 3 minutes
  const val USER_PROFILE_TTL_MS = 10 * 60 * 1000L // 10 minutes
  const val METADATA_TTL_MS = 60 * 60 * 1000L // 1 hour
  const val STATIC_ASSET_TTL_MS = 24 * 60 * 60 * 1000L // 24 hours
}

class MultiLevelCacheManager(
  private val maxEntries: Int = 150,
) {
  private val memoryStore = LinkedHashMap<String, CacheEntry<Any>>(maxEntries, 0.75f, true)

  @Synchronized
  fun <T : Any> put(key: String, value: T, ttlMs: Long = CacheTtlConfig.FEED_TTL_MS) {
    // LRU eviction if capacity exceeded
    if (memoryStore.size >= maxEntries) {
      val eldestKey = memoryStore.keys.firstOrNull()
      eldestKey?.let { memoryStore.remove(it) }
    }

    val now = System.currentTimeMillis()
    memoryStore[key] = CacheEntry(
      value = value,
      createdAtMs = now,
      expiresAtMs = now + ttlMs,
    )
  }

  @Suppress("UNCHECKED_CAST")
  @Synchronized
  fun <T : Any> get(key: String): T? {
    val entry = memoryStore[key] ?: return null
    if (entry.isExpired) {
      memoryStore.remove(key)
      return null
    }
    return entry.value as? T
  }

  @Synchronized
  fun invalidate(key: String) {
    memoryStore.remove(key)
  }

  @Synchronized
  fun invalidatePrefix(prefix: String) {
    val keysToRemove = memoryStore.keys.filter { it.startsWith(prefix) }
    keysToRemove.forEach { memoryStore.remove(it) }
  }

  @Synchronized
  fun purgeExpired() {
    val now = System.currentTimeMillis()
    memoryStore.entries.removeIf { it.value.expiresAtMs < now }
  }

  @Synchronized
  fun clearAll() {
    memoryStore.clear()
  }

  @Synchronized
  fun getEstimatedSizeEntries(): Int = memoryStore.size

  companion object {
    val instance: MultiLevelCacheManager by lazy { MultiLevelCacheManager() }
  }
}
