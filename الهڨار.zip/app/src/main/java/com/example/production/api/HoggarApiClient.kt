package com.example.production.api

import com.example.production.env.EnvironmentConfig
import com.example.production.monitoring.HoggarLogger
import java.util.UUID

/**
 * Production API Client Architecture
 * Replaces direct database calls with isolated, authenticated, versioned, and rate-limited HTTP/REST contracts.
 */
class HoggarApiClient(
  private val config: EnvironmentConfig = EnvironmentConfig.current,
  private val logger: HoggarLogger = HoggarLogger(),
) {
  private val rateLimitTracker = mutableMapOf<String, MutableList<Long>>()

  /**
   * Executes an authenticated request with validation and rate limiting.
   */
  fun <T> executeRequest(
    endpoint: String,
    authToken: String?,
    userId: String? = null,
    body: Any? = null,
    action: () -> T,
  ): ApiResponse<T> {
    val correlationId = "req_${UUID.randomUUID().toString().take(8)}"
    val startTime = System.currentTimeMillis()

    // 1. Authentication Check
    if (authToken.isNullOrEmpty() && endpointRequiresAuth(endpoint)) {
      logger.warn("API", "Unauthorized request rejected", mapOf("endpoint" to endpoint, "traceId" to correlationId))
      return ApiResponse.Error(
        code = "UNAUTHORIZED",
        message = "يجب تسجيل الدخول للوصول إلى هذه الخدمة",
        correlationId = correlationId,
        httpStatus = 401,
      )
    }

    // 2. Server-side Rate Limiting
    val clientKey = userId ?: "anonymous"
    if (!checkRateLimit(clientKey)) {
      logger.warn("API", "Rate limit exceeded", mapOf("client" to clientKey, "endpoint" to endpoint))
      return ApiResponse.Error(
        code = "RATE_LIMIT_EXCEEDED",
        message = "تم تجاوز الحد المسموح من الطلبات. يرجى الانتظار قليلاً.",
        correlationId = correlationId,
        httpStatus = 429,
      )
    }

    // 3. Execution with Latency Tracking
    return try {
      val result = action()
      val durationMs = System.currentTimeMillis() - startTime
      logger.info(
        "API",
        "Request successful",
        mapOf("endpoint" to endpoint, "durationMs" to durationMs, "traceId" to correlationId),
      )
      ApiResponse.Success(result)
    } catch (e: Exception) {
      val durationMs = System.currentTimeMillis() - startTime
      logger.error(
        "API",
        "Request failed: ${e.message}",
        mapOf("endpoint" to endpoint, "durationMs" to durationMs, "traceId" to correlationId),
      )
      ApiResponse.Error(
        code = "SERVER_ERROR",
        message = "حدث خطأ غير متوقع. يرجى إعادة المحاولة لاحقاً.",
        correlationId = correlationId,
        httpStatus = 500,
      )
    }
  }

  private fun endpointRequiresAuth(endpoint: String): Boolean {
    return endpoint.startsWith("/videos/upload") ||
      endpoint.startsWith("/interactions") ||
      endpoint.startsWith("/admin") ||
      endpoint.startsWith("/profile/edit")
  }

  private fun checkRateLimit(clientKey: String): Boolean {
    val now = System.currentTimeMillis()
    val timestamps = rateLimitTracker.getOrPut(clientKey) { mutableListOf() }
    timestamps.removeAll { now - it > 60_000L }

    if (timestamps.size >= config.rateLimitPerMinute) {
      return false
    }
    timestamps.add(now)
    return true
  }
}
