package com.example.production.monitoring

import android.util.Log

/**
 * Production Structured Logger
 * Emits JSON-structured event logs with Correlation IDs and strictly sanitizes/masks sensitive data
 * (passwords, auth tokens, secrets) before writing.
 */
class HoggarLogger(
  private val tagPrefix: String = "ElHoggar",
) {
  fun info(component: String, message: String, metadata: Map<String, Any> = emptyMap()) {
    val sanitized = sanitizeMetadata(metadata)
    val formatted = buildLogString("INFO", message, sanitized)
    try {
      Log.i("$tagPrefix-$component", formatted)
    } catch (_: Throwable) {
      println("[$tagPrefix-$component] $formatted")
    }
  }

  fun warn(component: String, message: String, metadata: Map<String, Any> = emptyMap()) {
    val sanitized = sanitizeMetadata(metadata)
    val formatted = buildLogString("WARN", message, sanitized)
    try {
      Log.w("$tagPrefix-$component", formatted)
    } catch (_: Throwable) {
      println("[$tagPrefix-$component] $formatted")
    }
  }

  fun error(component: String, message: String, metadata: Map<String, Any> = emptyMap(), throwable: Throwable? = null) {
    val sanitized = sanitizeMetadata(metadata)
    val formatted = buildLogString("ERROR", message, sanitized)
    try {
      Log.e("$tagPrefix-$component", formatted, throwable)
    } catch (_: Throwable) {
      println("[$tagPrefix-$component] $formatted ${throwable?.message ?: ""}")
    }
  }

  private fun sanitizeMetadata(metadata: Map<String, Any>): Map<String, Any> {
    val sensitiveKeys = listOf("password", "token", "auth", "secret", "bearer", "authorization")
    return metadata.mapValues { (key, value) ->
      if (sensitiveKeys.any { key.lowercase().contains(it) }) {
        "***MASKED***"
      } else {
        value
      }
    }
  }

  private fun buildLogString(level: String, message: String, metadata: Map<String, Any>): String {
    val metaString = if (metadata.isNotEmpty()) " | data=$metadata" else ""
    return "[$level] $message$metaString"
  }
}
