package com.example.production.upload

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.UUID

enum class UploadSessionStatus {
  Initiated,
  Uploading,
  Paused,
  Completed,
  Failed,
}

data class ResumableUploadSession(
  val sessionId: String,
  val fileName: String,
  val totalBytes: Long,
  val chunkSize: Int,
  val totalChunks: Int,
  var uploadedChunks: Int = 0,
  var status: UploadSessionStatus = UploadSessionStatus.Initiated,
  var lastError: String? = null,
) {
  val progress: Float
    get() = if (totalChunks > 0) uploadedChunks.toFloat() / totalChunks.toFloat() else 0f
}

data class UploadProgressEvent(
  val sessionId: String,
  val progressPercent: Int,
  val currentChunk: Int,
  val totalChunks: Int,
  val status: UploadSessionStatus,
  val isComplete: Boolean = false,
  val error: String? = null,
)

class ResumableUploadManager(
  private val defaultChunkSize: Int = 1024 * 1024, // 1MB chunks
) {
  private val activeSessions = mutableMapOf<String, ResumableUploadSession>()

  fun createSession(fileName: String, totalBytes: Long): ResumableUploadSession {
    val totalChunks = ((totalBytes + defaultChunkSize - 1) / defaultChunkSize).toInt().coerceAtLeast(1)
    val session = ResumableUploadSession(
      sessionId = "upload_${UUID.randomUUID().toString().take(10)}",
      fileName = fileName,
      totalBytes = totalBytes,
      chunkSize = defaultChunkSize,
      totalChunks = totalChunks,
    )
    activeSessions[session.sessionId] = session
    return session
  }

  fun getSession(sessionId: String): ResumableUploadSession? {
    return activeSessions[sessionId]
  }

  /**
   * Resumes or starts an upload session stream.
   * If interrupted, starts directly from `session.uploadedChunks` instead of chunk 0!
   */
  fun startOrResumeUpload(sessionId: String, simulateNetworkDrop: Boolean = false): Flow<UploadProgressEvent> = flow {
    val session = activeSessions[sessionId]
      ?: throw IllegalArgumentException("Upload session $sessionId not found")

    session.status = UploadSessionStatus.Uploading

    val startChunk = session.uploadedChunks
    val total = session.totalChunks

    for (chunkIndex in startChunk until total) {
      // Simulate network pause/drop condition if specified
      if (simulateNetworkDrop && chunkIndex == total / 2 && session.uploadedChunks == total / 2) {
        session.status = UploadSessionStatus.Paused
        session.lastError = "تم انقطاع الاتصال مؤقتاً، الرفع محفوظ ويمكن استئنافه."
        emit(
          UploadProgressEvent(
            sessionId = sessionId,
            progressPercent = (session.progress * 100).toInt(),
            currentChunk = session.uploadedChunks,
            totalChunks = total,
            status = UploadSessionStatus.Paused,
            error = session.lastError,
          ),
        )
        return@flow
      }

      // Simulate chunk upload processing time
      delay(80)
      session.uploadedChunks = chunkIndex + 1

      val percent = (session.progress * 100).toInt()
      emit(
        UploadProgressEvent(
          sessionId = sessionId,
          progressPercent = percent,
          currentChunk = session.uploadedChunks,
          totalChunks = total,
          status = UploadSessionStatus.Uploading,
        ),
      )
    }

    session.status = UploadSessionStatus.Completed
    emit(
      UploadProgressEvent(
        sessionId = sessionId,
        progressPercent = 100,
        currentChunk = total,
        totalChunks = total,
        status = UploadSessionStatus.Completed,
        isComplete = true,
      ),
    )
  }
}
