package com.example.interaction.repository

import com.example.interaction.model.CommentItem
import com.example.model.CreatorModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

interface CommentRepository {
  fun getComments(videoId: String): Flow<List<CommentItem>>
  suspend fun addComment(videoId: String, author: CreatorModel, text: String, parentCommentId: String? = null): Result<CommentItem>
  suspend fun deleteComment(commentId: String, currentUserId: String, videoOwnerId: String): Result<Boolean>
  suspend fun togglePinComment(commentId: String, currentUserId: String, videoOwnerId: String): Result<Boolean>
  suspend fun toggleLikeComment(commentId: String, currentUserId: String): Result<Boolean>
}

class InMemoryCommentRepository(
  private val onNotificationDispatch: ((recipientUserId: String, actor: CreatorModel, text: String, isReply: Boolean) -> Unit)? = null,
) : CommentRepository {

  // Map of videoId -> List of top-level comments
  private val commentsMap = mutableMapOf<String, MutableList<CommentItem>>()
  private val updatesFlow = MutableStateFlow(Unit)

  // Anti-spam sliding window: userId -> lastCommentTimestampMs
  private val rateLimitMap = mutableMapOf<String, Long>()

  init {
    seedInitialComments()
  }

  private fun seedInitialComments() {
    val initial = mutableListOf(
      CommentItem(
        id = "comment_01",
        videoId = "hoggar_001",
        author = CreatorModel(
          id = "creator_02",
          username = "tamanrasset_crafts",
          displayName = "حِرَف تمنراست",
          avatarUrl = "https://picsum.photos/seed/avatar2/200/200",
          isVerified = true,
        ),
        text = "قمة تاهات وقت الغروب أعظم مشهد يمكن أن تراه في الصحراء الكبرى! تصوير استثنائي.",
        timestampMs = System.currentTimeMillis() - 3600000L,
        likesCount = 284L,
        isPinned = true,
        repliesCount = 2,
        replies = listOf(
          CommentItem(
            id = "reply_01",
            videoId = "hoggar_001",
            author = CreatorModel(
              id = "creator_01",
              username = "hoggar_explorer",
              displayName = "مستكشف الهڨار",
              avatarUrl = "https://picsum.photos/seed/avatar1/200/200",
              isVerified = true,
            ),
            text = "شكرًا أخي العزيز، الهواء هناك نقي ولهيبة المكان سحر لا يوصف.",
            timestampMs = System.currentTimeMillis() - 1800000L,
            likesCount = 45L,
            parentCommentId = "comment_01",
          ),
        ),
      ),
      CommentItem(
        id = "comment_02",
        videoId = "hoggar_001",
        author = CreatorModel(
          id = "creator_03",
          username = "sahara_rhythms",
          displayName = "إيقاعات الصحراء",
          avatarUrl = "https://picsum.photos/seed/avatar3/200/200",
          isVerified = false,
        ),
        text = "سبحان الخالق، تكوينات الغرانيت البازلتية كأنها قلاع طبيعية تحرس الرمال.",
        timestampMs = System.currentTimeMillis() - 7200000L,
        likesCount = 112L,
        repliesCount = 0,
      ),
      CommentItem(
        id = "comment_03",
        videoId = "hoggar_001",
        author = CreatorModel(
          id = "creator_04",
          username = "desert_tea",
          displayName = "كأس شاي صحراوي",
          avatarUrl = "https://picsum.photos/seed/avatar4/200/200",
          isVerified = false,
        ),
        text = "ما أجمل هذا المنظر مع كأس شاي على جمر السمر في أسكرام.",
        timestampMs = System.currentTimeMillis() - 14400000L,
        likesCount = 98L,
        repliesCount = 0,
      ),
    )
    commentsMap["hoggar_001"] = initial
  }

  override fun getComments(videoId: String): Flow<List<CommentItem>> = kotlinx.coroutines.flow.flow {
    updatesFlow.collect {
      val list = commentsMap[videoId]?.toList() ?: emptyList()
      // Always put pinned comment first, then latest
      val sorted = list.sortedWith(
        compareByDescending<CommentItem> { it.isPinned }
          .thenByDescending { it.timestampMs },
      )
      emit(sorted)
    }
  }

  override suspend fun addComment(
    videoId: String,
    author: CreatorModel,
    text: String,
    parentCommentId: String?,
  ): Result<CommentItem> {
    val clean = text.trim()
    if (clean.isEmpty()) {
      return Result.failure(IllegalArgumentException("لا يمكن نشر تعليق فارغ"))
    }
    if (clean.length > 500) {
      return Result.failure(IllegalArgumentException("التعليق يتجاوز الحد الأقصى (500 حرف)"))
    }

    // Rate Limiting Protection (Minimum 1.5 seconds between comments)
    val now = System.currentTimeMillis()
    val lastPost = rateLimitMap[author.id] ?: 0L
    if (now - lastPost < 1500L) {
      return Result.failure(IllegalStateException("يرجى الانتظار لحظة قبل كتابة تعليق آخر"))
    }
    rateLimitMap[author.id] = now

    val newComment = CommentItem(
      id = "com_${UUID.randomUUID().toString().take(8)}",
      videoId = videoId,
      author = author,
      text = clean,
      timestampMs = now,
      likesCount = 0L,
      isLiked = false,
      isPinned = false,
      repliesCount = 0,
      parentCommentId = parentCommentId,
    )

    val list = commentsMap.getOrPut(videoId) { mutableListOf() }

    if (parentCommentId != null) {
      // It's a reply to an existing top-level comment
      val parentIndex = list.indexOfFirst { it.id == parentCommentId }
      if (parentIndex != -1) {
        val parent = list[parentIndex]
        val updatedReplies = parent.replies + newComment
        list[parentIndex] = parent.copy(
          replies = updatedReplies,
          repliesCount = updatedReplies.size,
        )
        onNotificationDispatch?.invoke(parent.author.id, author, clean, true)
      } else {
        list.add(0, newComment)
      }
    } else {
      // Top level comment
      list.add(0, newComment)
    }

    updatesFlow.value = Unit
    return Result.success(newComment)
  }

  override suspend fun deleteComment(commentId: String, currentUserId: String, videoOwnerId: String): Result<Boolean> {
    var deleted = false
    commentsMap.forEach { (_, list) ->
      // Try finding as top-level comment
      val index = list.indexOfFirst { it.id == commentId }
      if (index != -1) {
        val c = list[index]
        // Authorized if comment author OR video owner
        if (c.author.id == currentUserId || currentUserId == videoOwnerId) {
          list.removeAt(index)
          deleted = true
        } else {
          return Result.failure(IllegalAccessException("غير مصرح لك بحذف هذا التعليق"))
        }
      } else {
        // Try finding inside replies
        for (i in list.indices) {
          val parent = list[i]
          val replyIndex = parent.replies.indexOfFirst { it.id == commentId }
          if (replyIndex != -1) {
            val reply = parent.replies[replyIndex]
            if (reply.author.id == currentUserId || currentUserId == videoOwnerId) {
              val newReplies = parent.replies.toMutableList().apply { removeAt(replyIndex) }
              list[i] = parent.copy(replies = newReplies, repliesCount = newReplies.size)
              deleted = true
              break
            } else {
              return Result.failure(IllegalAccessException("غير مصرح لك بحذف هذا التعليق"))
            }
          }
        }
      }
    }

    if (deleted) {
      updatesFlow.value = Unit
      return Result.success(true)
    }
    return Result.failure(NoSuchElementException("التعليق غير موجود"))
  }

  override suspend fun togglePinComment(commentId: String, currentUserId: String, videoOwnerId: String): Result<Boolean> {
    // Only video owner can pin/unpin comments
    if (currentUserId != videoOwnerId) {
      return Result.failure(IllegalAccessException("صاحب الفيديو فقط يمكنه تثبيت التعليقات"))
    }

    var newState = false
    commentsMap.forEach { (_, list) ->
      val targetIndex = list.indexOfFirst { it.id == commentId }
      if (targetIndex != -1) {
        val target = list[targetIndex]
        newState = !target.isPinned

        // Unpin any previously pinned comment on this video!
        for (i in list.indices) {
          if (list[i].isPinned) {
            list[i] = list[i].copy(isPinned = false)
          }
        }

        // Apply new pinned state
        list[targetIndex] = target.copy(isPinned = newState)
      }
    }

    updatesFlow.value = Unit
    return Result.success(newState)
  }

  override suspend fun toggleLikeComment(commentId: String, currentUserId: String): Result<Boolean> {
    var newState = false
    commentsMap.forEach { (_, list) ->
      val index = list.indexOfFirst { it.id == commentId }
      if (index != -1) {
        val c = list[index]
        newState = !c.isLiked
        val newCount = if (newState) c.likesCount + 1 else (c.likesCount - 1).coerceAtLeast(0)
        list[index] = c.copy(isLiked = newState, likesCount = newCount)
      }
    }
    updatesFlow.value = Unit
    return Result.success(newState)
  }
}
