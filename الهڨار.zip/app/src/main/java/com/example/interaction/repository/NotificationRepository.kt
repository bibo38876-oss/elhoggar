package com.example.interaction.repository

import com.example.interaction.model.NotificationItem
import com.example.interaction.model.NotificationPreferences
import com.example.interaction.model.NotificationType
import com.example.model.CreatorModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import java.util.UUID

interface NotificationRepository {
  fun getNotifications(userId: String): Flow<List<NotificationItem>>
  fun dispatchNotification(
    recipientUserId: String,
    actor: CreatorModel?,
    type: NotificationType,
    targetVideoId: String? = null,
    targetThumbnailUrl: String? = null,
    title: String = "",
    previewText: String = "",
  )
  fun markAsRead(notificationId: String, userId: String)
  fun markAllAsRead(userId: String)
  fun getPreferences(userId: String): Flow<NotificationPreferences>
  fun updatePreferences(userId: String, preferences: NotificationPreferences)
}

class InMemoryNotificationRepository : NotificationRepository {

  private val notificationsMap = mutableMapOf<String, MutableList<NotificationItem>>()
  private val preferencesMap = mutableMapOf<String, NotificationPreferences>()
  private val _updates = MutableStateFlow(Unit)
  private val _prefUpdates = MutableStateFlow(Unit)

  init {
    seedInitialNotifications()
  }

  private fun seedInitialNotifications() {
    val sampleForUserMe = mutableListOf(
      NotificationItem(
        id = "notif_sys_01",
        recipientUserId = "user_me",
        actor = null,
        type = NotificationType.System,
        title = "فريق أمان الهڨار",
        previewText = "أهلاً بك في منصة الهڨار! تم تفعيل حسابك وفق أعلى معايير الخصوصية والأمان.",
        timestampMs = System.currentTimeMillis() - 180000L,
        isRead = false,
      ),
      NotificationItem(
        id = "notif_content_01",
        recipientUserId = "user_me",
        actor = null,
        type = NotificationType.Content,
        targetVideoId = "hoggar_001",
        targetThumbnailUrl = "https://picsum.photos/seed/hoggar_tahat/720/1280",
        title = "موافقة الإشراف",
        previewText = "تم اعتماد ونشر مقطعك 'غروب الشمس فوق قمم الهڨار' في الخلاصة العامة.",
        timestampMs = System.currentTimeMillis() - 3600000L,
        isRead = false,
      ),
      NotificationItem(
        id = "notif_01",
        recipientUserId = "user_me",
        actor = CreatorModel(
          id = "creator_01",
          username = "hoggar_explorer",
          displayName = "مستكشف الهڨار",
          avatarUrl = "https://picsum.photos/seed/avatar1/200/200",
          isVerified = true,
        ),
        type = NotificationType.Like,
        targetVideoId = "hoggar_001",
        targetThumbnailUrl = "https://picsum.photos/seed/hoggar_tahat/720/1280",
        title = "إعجاب بمحتواك",
        previewText = "أعجب مستكشف الهڨار و 3 آخرون بفيديوك",
        timestampMs = System.currentTimeMillis() - 7200000L,
        isRead = true,
        batchCount = 4,
      ),
      NotificationItem(
        id = "notif_02",
        recipientUserId = "user_me",
        actor = CreatorModel(
          id = "creator_02",
          username = "tamanrasset_crafts",
          displayName = "حِرَف تمنراست",
          avatarUrl = "https://picsum.photos/seed/avatar2/200/200",
          isVerified = true,
        ),
        type = NotificationType.Comment,
        targetVideoId = "hoggar_001",
        targetThumbnailUrl = "https://picsum.photos/seed/hoggar_tahat/720/1280",
        title = "تعليق جديد",
        previewText = "علق: قمة تاهات وقت الغروب أعظم مشهد بالجزائر...",
        timestampMs = System.currentTimeMillis() - 14400000L,
        isRead = true,
      ),
      NotificationItem(
        id = "notif_03",
        recipientUserId = "user_me",
        actor = CreatorModel(
          id = "official_elhoggar",
          username = "elhoggar",
          displayName = "الهڨار الرسمي",
          avatarUrl = "",
          isVerified = true,
        ),
        type = NotificationType.Follow,
        title = "متابعة جديدة",
        previewText = "بدأ الحساب الرسمي لمنصة الهڨار بمتابعتك",
        timestampMs = System.currentTimeMillis() - 86400000L,
        isRead = true,
      ),
    )
    notificationsMap["user_me"] = sampleForUserMe
    preferencesMap["user_me"] = NotificationPreferences()
  }

  override fun getNotifications(userId: String): Flow<List<NotificationItem>> = flow {
    _updates.collect {
      val list = notificationsMap[userId]?.toList() ?: emptyList()
      emit(list.sortedByDescending { it.timestampMs })
    }
  }

  override fun dispatchNotification(
    recipientUserId: String,
    actor: CreatorModel?,
    type: NotificationType,
    targetVideoId: String?,
    targetThumbnailUrl: String?,
    title: String,
    previewText: String,
  ) {
    // 1. Do NOT notify user for their own actions
    if (actor != null && recipientUserId == actor.id) {
      return
    }

    // 2. Check user notification preferences on the server
    val prefs = preferencesMap[recipientUserId] ?: NotificationPreferences()
    val isEnabled = when (type) {
      NotificationType.Like -> prefs.likesEnabled
      NotificationType.Comment -> prefs.commentsEnabled
      NotificationType.Reply -> prefs.repliesEnabled
      NotificationType.Follow -> prefs.followsEnabled
      NotificationType.Content -> prefs.contentEnabled
      NotificationType.System -> prefs.systemEnabled
    }
    if (!isEnabled) {
      return
    }

    val userList = notificationsMap.getOrPut(recipientUserId) { mutableListOf() }
    val now = System.currentTimeMillis()

    // 3. Smart Anti-Spam Batching: Group consecutive similar notifications for same target
    if (type == NotificationType.Like && targetVideoId != null) {
      val existingRecentLike = userList.indexOfFirst {
        it.type == NotificationType.Like &&
          it.targetVideoId == targetVideoId &&
          (now - it.timestampMs < 30 * 60 * 1000L) // 30-minute batch window
      }
      if (existingRecentLike != -1) {
        val existing = userList[existingRecentLike]
        val newCount = existing.batchCount + 1
        userList[existingRecentLike] = existing.copy(
          batchCount = newCount,
          previewText = if (actor != null) "أعجب ${actor.displayName} و ${newCount - 1} آخرون بفيديوك" else "أعجب $newCount مستخدمين بمحتواك",
          timestampMs = now,
          isRead = false,
        )
        _updates.value = Unit
        return
      }
    }

    val item = NotificationItem(
      id = "notif_${UUID.randomUUID().toString().take(8)}",
      recipientUserId = recipientUserId,
      actor = actor,
      type = type,
      targetVideoId = targetVideoId,
      targetThumbnailUrl = targetThumbnailUrl,
      title = title.ifEmpty { type.labelAr },
      previewText = previewText,
      timestampMs = now,
      isRead = false,
      batchCount = 1,
    )

    userList.add(0, item)
    _updates.value = Unit
  }

  override fun markAsRead(notificationId: String, userId: String) {
    notificationsMap[userId]?.let { list ->
      val index = list.indexOfFirst { it.id == notificationId }
      if (index != -1) {
        list[index] = list[index].copy(isRead = true)
        _updates.value = Unit
      }
    }
  }

  override fun markAllAsRead(userId: String) {
    notificationsMap[userId]?.let { list ->
      for (i in list.indices) {
        list[i] = list[i].copy(isRead = true)
      }
      _updates.value = Unit
    }
  }

  override fun getPreferences(userId: String): Flow<NotificationPreferences> = flow {
    _prefUpdates.collect {
      emit(preferencesMap[userId] ?: NotificationPreferences())
    }
  }

  override fun updatePreferences(userId: String, preferences: NotificationPreferences) {
    preferencesMap[userId] = preferences
    _prefUpdates.value = Unit
  }
}
