package com.example.interaction.repository

import com.example.interaction.model.ReportItem
import kotlinx.coroutines.delay
import java.util.UUID

interface ReportRepository {
  suspend fun submitReport(report: ReportItem): Result<String>
  fun getReports(): List<ReportItem>
}

class InMemoryReportRepository : ReportRepository {
  private val reportsList = mutableListOf<ReportItem>()

  override suspend fun submitReport(report: ReportItem): Result<String> {
    delay(200) // Simulating network submit
    reportsList.add(report)
    return Result.success("تم إرسال بلاغك بنجاح وسيقوم فريق مراجعة الهڨار بالتدقيق في المحتوى.")
  }

  override fun getReports(): List<ReportItem> = reportsList.toList()
}
