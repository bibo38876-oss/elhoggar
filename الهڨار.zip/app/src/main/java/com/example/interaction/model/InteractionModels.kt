package com.example.interaction.model

import com.example.model.CreatorModel

/**
 * Core Comment Model supporting nesting (replies) and pinning.
 */
data class CommentItem(
  val id: String,
  val videoId: String,
  val author: CreatorModel,
  val text: String,
  val timestampMs: Long = System.currentTimeMillis(),
  val likesCount: Long = 0L,
  val isLiked: Boolean = false,
  val isPinned: Boolean = false,
  val repliesCount: Int = 0,
  val parentCommentId: String? = null,
  val replies: List<CommentItem> = emptyList(),
)

/**
 * Report Target Types
 */
enum class ReportTargetType {
  Video,
  Comment,
  User,
}

/**
 * Structured Reporting Reasons
 */
enum class ReportReason(val labelAr: String) {
  InappropriateContent("محتوى غير مناسب"),
  Harassment("إساءة أو مضايقة"),
  Impersonation("انتحال شخصية"),
  RulesViolation("محتوى مخالف للقواعد"),
  Copyright("انتهاك حقوق الملكية"),
  Other("سبب آخر"),
}

/**
 * Report Log Entity
 */
data class ReportItem(
  val id: String,
  val targetType: ReportTargetType,
  val targetId: String,
  val reporterId: String,
  val reason: ReportReason,
  val details: String = "",
  val timestampMs: Long = System.currentTimeMillis(),
)

/**
 * Notification Types
 */
enum class NotificationType(val labelAr: String) {
  Like("إعجاب"),
  Comment("تعليق"),
  Reply("رد"),
  Follow("متابعة"),
  Content("محتوى"),
  System("النظام"),
}

/**
 * Social & System Interaction Notification Entity
 */
data class NotificationItem(
  val id: String,
  val recipientUserId: String,
  val actor: CreatorModel? = null,
  val type: NotificationType,
  val targetVideoId: String? = null,
  val targetThumbnailUrl: String? = null,
  val title: String = "",
  val previewText: String = "",
  val timestampMs: Long = System.currentTimeMillis(),
  val isRead: Boolean = false,
  val batchCount: Int = 1,
)

/**
 * User Notification Delivery Preferences
 */
data class NotificationPreferences(
  val likesEnabled: Boolean = true,
  val commentsEnabled: Boolean = true,
  val repliesEnabled: Boolean = true,
  val followsEnabled: Boolean = true,
  val contentEnabled: Boolean = true,
  val systemEnabled: Boolean = true,
)
