package com.example.interaction.repository

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

interface InteractionRepository {
  fun recordView(videoId: String, viewerUserId: String?, continuousPlaybackSeconds: Float): Boolean
  fun recordShare(videoId: String): Long
  fun getVideoShareUrl(videoId: String): String
  fun canLike(userId: String, videoId: String): Boolean
  fun recordLikeAction(userId: String, videoId: String)
}

class InMemoryInteractionRepository : InteractionRepository {

  // Map of videoId -> Set of viewer keys (session deduplication)
  private val recordedViewsMap = mutableMapOf<String, MutableSet<String>>()
  // Map of videoId -> shares count
  private val sharesCountMap = mutableMapOf<String, Long>()

  // Rate Limiting on Likes: userId -> lastLikeTimestampMs
  private val likeRateLimitMap = mutableMapOf<String, Long>()

  override fun recordView(videoId: String, viewerUserId: String?, continuousPlaybackSeconds: Float): Boolean {
    // 1. Minimum watch threshold requirement (3.0 seconds continuous playback)
    if (continuousPlaybackSeconds < 3.0f) {
      return false
    }

    // 2. Prevent duplicate count within same session
    val viewerKey = viewerUserId ?: "anon_session"
    val viewers = recordedViewsMap.getOrPut(videoId) { mutableSetOf() }
    if (viewers.contains(viewerKey)) {
      return false
    }

    viewers.add(viewerKey)
    return true
  }

  override fun recordShare(videoId: String): Long {
    val current = sharesCountMap[videoId] ?: 0L
    val newCount = current + 1
    sharesCountMap[videoId] = newCount
    return newCount
  }

  override fun getVideoShareUrl(videoId: String): String {
    // Deep Link URL format ready for external handling
    return "https://elhoggar.dz/v/$videoId"
  }

  override fun canLike(userId: String, videoId: String): Boolean {
    val lastLike = likeRateLimitMap[userId] ?: 0L
    val now = System.currentTimeMillis()
    // Anti-Spam: Minimum 300ms between like taps
    return (now - lastLike) >= 300L
  }

  override fun recordLikeAction(userId: String, videoId: String) {
    likeRateLimitMap[userId] = System.currentTimeMillis()
  }
}
