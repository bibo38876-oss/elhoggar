package com.example.follow

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

interface FollowRepository {
  fun isFollowing(currentUserId: String, targetUserId: String): Boolean
  suspend fun follow(currentUserId: String, targetUserId: String): Result<Boolean>
  suspend fun unfollow(currentUserId: String, targetUserId: String): Result<Boolean>
  fun getFollowingIds(userId: String): Set<String>
  fun getFollowersCount(userId: String): Long
  fun getFollowingCount(userId: String): Long
  val updatesFlow: Flow<Unit>
}

class InMemoryFollowRepository : FollowRepository {
  // Map of userId -> Set of userIds they are following
  private val followingMap = mutableMapOf<String, MutableSet<String>>()
  // Map of userId -> Set of userIds who follow them
  private val followersMap = mutableMapOf<String, MutableSet<String>>()

  private val _updates = MutableStateFlow(Unit)
  override val updatesFlow: Flow<Unit> = _updates.asStateFlow()

  init {
    // Initial sample seed follows
    seedFollow("user_me", "official_elhoggar")
    seedFollow("user_me", "creator_01")
    seedFollow("creator_01", "official_elhoggar")
  }

  private fun seedFollow(from: String, to: String) {
    followingMap.getOrPut(from) { mutableSetOf() }.add(to)
    followersMap.getOrPut(to) { mutableSetOf() }.add(from)
  }

  override fun isFollowing(currentUserId: String, targetUserId: String): Boolean {
    return followingMap[currentUserId]?.contains(targetUserId) == true
  }

  override suspend fun follow(currentUserId: String, targetUserId: String): Result<Boolean> {
    if (currentUserId == targetUserId) {
      return Result.failure(IllegalArgumentException("لا يمكنك متابعة نفسك"))
    }
    followingMap.getOrPut(currentUserId) { mutableSetOf() }.add(targetUserId)
    followersMap.getOrPut(targetUserId) { mutableSetOf() }.add(currentUserId)
    _updates.value = Unit
    return Result.success(true)
  }

  override suspend fun unfollow(currentUserId: String, targetUserId: String): Result<Boolean> {
    followingMap[currentUserId]?.remove(targetUserId)
    followersMap[targetUserId]?.remove(currentUserId)
    _updates.value = Unit
    return Result.success(false)
  }

  override fun getFollowingIds(userId: String): Set<String> {
    return followingMap[userId]?.toSet() ?: emptySet()
  }

  override fun getFollowersCount(userId: String): Long {
    val dynamicCount = followersMap[userId]?.size?.toLong() ?: 0L
    // Add base counts for prominent creators
    val base = when (userId) {
      "official_elhoggar" -> 125000L
      "creator_01" -> 42800L
      "creator_02" -> 19500L
      "creator_03" -> 28900L
      "creator_04" -> 14300L
      "creator_05" -> 89400L
      else -> 120L
    }
    return base + dynamicCount
  }

  override fun getFollowingCount(userId: String): Long {
    val dynamicCount = followingMap[userId]?.size?.toLong() ?: 0L
    val base = when (userId) {
      "official_elhoggar" -> 12L
      "user_me" -> 24L
      else -> 48L
    }
    return base + dynamicCount
  }
}
